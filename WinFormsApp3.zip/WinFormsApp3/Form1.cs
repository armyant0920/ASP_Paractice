using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

using test_Library1;
namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            FileSystemWatcher watcher = new FileSystemWatcher();

            watcher.Path = @"C:\temp";
            watcher.Filter = "*.txt";
            watcher.EnableRaisingEvents = true;
            watcher.IncludeSubdirectories = false;
            watcher.Created += watch_Created;
        }


        void watch_Created(object sender, FileSystemEventArgs e)
        {
            string DirectPath = e.FullPath;
            //�p�G�����쬰�ɮסA�h�̸��|�惡��Ƨ����ɮ׳B�z

            if (IsFilePath(DirectPath))
            {
                string fileFormat = "{0}-{1}.txt"; //�ɦW�榡
                //string FileDate = DateTime.Today.ToShortDateString();
                string FileDate = DateTime.Today.ToString("yyyy_MM_dd");
                string CreateAlbum = NewAlbum + @"\" + FileDate;

                string DirectoryName = Path.GetDirectoryName(e.FullPath); //���ɮת���Ƨ��W��
                var files = Directory.GetFiles(CreateAlbum, @"*.txt"); //���o�ؼи�Ƨ��Ҧ�txt�ɮ�

                //�ˬd�ؼи�Ƨ��O�_�s�b
                if (System.IO.Directory.Exists(CreateAlbum))
                {
                       
                    /*foreach(var file in Directory.GetFiles(CreateAlbum, @"*.txt")) {
                        
                        
                    }*/
                }
                else
                {
                    System.IO.Directory.CreateDirectory(CreateAlbum);
                }

                int i = files.Count();

                Debug.WriteLine("task:" + e.FullPath);

                //Console.WriteLine(Md5fromFile(e.FullPath));
                //Debug.WriteLine(Md5fromFile(e.FullPath));
                string s = test_Library1.Class1.Md5fromFile(e.FullPath);

                Debug.WriteLine(s);
                //�̶��ǧ��ɦW
                System.IO.Directory.CreateDirectory(DirectoryName);
                string fileCount = (++i).ToString("D3");
                string newFileName = System.IO.Path.Combine(CreateAlbum, string.Format(fileFormat, FileDate, fileCount));
                //�h��ReName�᪺�ɮ�
                System.IO.File.Move(e.FullPath, newFileName);



                /*foreach (string f in files)
                {
                    Console.WriteLine("task:" + f);
                    Debug.WriteLine("task:" + f);

                    Console.WriteLine(Md5fromFile(f));
                    Debug.WriteLine(Md5fromFile(f));
                    //�̶��ǧ��ɦW
                    System.IO.Directory.CreateDirectory(DirectoryName);
                    string fileCount = (++i).ToString("D3");
                    string newFileName = System.IO.Path.Combine(CreateAlbum, string.Format(fileFormat, FileDate, fileCount));
                    //�h��ReName�᪺�ɮ�
                    System.IO.File.Move(f, newFileName);
                }*/
            }

        }


        bool IsFilePath(string path)
        {

            return File.Exists(path);

        }


        static string Md5fromFile(string path)
        {

            
            string result = "";
            if (File.Exists(path))
            {


                try
                {
                    FileStream fs = new FileStream(path, FileMode.Open);

                    
                    MD5 mD5 = MD5.Create();
                    byte[] buffer = mD5.ComputeHash(fs);
                    fs.Close();

                    StringBuilder sb = new StringBuilder();

                    for (int i = 0; i < buffer.Length; i++) { 
                        sb.Append(buffer[i].ToString("X2"));
                    
                    }

                    result = sb.ToString();
                    Debug.WriteLine(result);
                    
                    return (result != null) ? result : "";

                }


                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());

                }


            }
            else {
                throw new FileNotFoundException();
                
            }


            return (result != null) ? result : "";


        }




    }
}