﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTP_TEST4.VaildTest
{
    internal class StringLengthAttribute : Attribute
    {
        private int _maximumLength;
        private string[] _invailds;
        public StringLengthAttribute(int maximumLength, string[] invailds)
        {
            _maximumLength = maximumLength;
            _invailds = invailds;

        }



        public int MaximumLength
        {
            get { return _maximumLength; }
        }

        public string[] Invaild_words {
            get { return _invailds; }    
        }
    }
  
}
