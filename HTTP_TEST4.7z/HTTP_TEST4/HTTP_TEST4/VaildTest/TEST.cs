﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTP_TEST4.VaildTest
{
    internal class TEST
    {


        private static void Main(string[] args)
        {
            var people = new People()
            {
                Name = "qweasdzxcasdqweasdzxc",
                Description = "description"
            };
            try
            {
                new ValidationModel().Validate(people);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
