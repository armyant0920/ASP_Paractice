﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTP_TEST4.VaildTest
{
    internal class People
    {
        [StringLength(8,new string[] {"aa","we","xc" })]
        public string Name { get; set; }

        [StringLength(15,new string[] { })]
        public string Description { get; set; }
    }
}

