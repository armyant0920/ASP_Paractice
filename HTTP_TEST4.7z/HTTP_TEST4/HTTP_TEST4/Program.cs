﻿

namespace HTTP_TEST4
{
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            getResponse1();
            Console.WriteLine("end");

        }


        static async void getResponse1() {

            string result = string.Empty;
            string url = "https://api.kcg.gov.tw/api/service/get/28efe4b3-b653-45fa-bbe8-e5514fc18292";

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "post";
                request.ContentType = "application/json";
                
                
                //request.Accept = "*/*";
                //request.UserAgent = "Mozillz/4.0 (compatiable;MSIE 6.0; Window NT 5.1;SV1)";

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream rs = response.GetResponseStream();
                StreamReader reader = new StreamReader(rs, System.Text.Encoding.UTF8);
                result = reader.ReadToEnd();
                
                reader.Close();
                rs.Close();
                response.Close();
                Console.WriteLine(result);

            }

            catch (Exception ex)
            {

                Console.WriteLine("occur exception:{0}\n{1}", ex.Message, ex.StackTrace);

            }



            //return result;



        }

        static async Task getResponse() {
            using var client = new HttpClient();
            
            var response = await client.GetAsync("https://api.kcg.gov.tw/api/service/get/28efe4b3-b653-45fa-bbe8-e5514fc18292");
            var body = await response.Content.ReadAsStringAsync();
            Console.WriteLine(body);
            

        }
    }
}