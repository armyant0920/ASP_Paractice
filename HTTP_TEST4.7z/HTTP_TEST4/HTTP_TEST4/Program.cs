﻿

namespace HTTP_TEST4
{
    using Newtonsoft.Json.Linq;
    using RestSharp;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            //getResponse1();
            getResponse2();
            Console.WriteLine("end");

        }

        static async void getResponse2() {
            var client = new RestClient("https://api.openai.com/v1/completions");
            var options = new RestClientOptions("https://api.openai.com/v1/completions")
            {
                ThrowOnAnyError = true,
                Timeout = 1000

            };
            client.Options.Timeout = -1;
           
            var request = new RestRequest();
            request.Method = Method.Post;

            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", "Bearer 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");
            var body = @"{
                " + "\n" +
                            @"    ""prompt"":""how to go through black hole"",
                " + "\n" +
                            @"    ""model"":""text-davinci-003"",
                " + "\n" +
                            @"    ""temperature"":0.8,
                " + "\n" +
                            @"    ""max_tokens"":2048
                " + "\n" +
                            @"
                " + "\n" +
                            @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            RestResponse
             response = client.Execute(request);//IRestResponse
            //Console.WriteLine(response.Content);
            JObject json = JObject.Parse(response.Content);
            Console.WriteLine("result={0}", json["choices"][0]["text"].ToString());



        }
        static async void getResponse1() {

            string result = string.Empty;
            string url = "https://api.kcg.gov.tw/api/service/get/28efe4b3-b653-45fa-bbe8-e5514fc18292";

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "post";
                request.ContentType = "application/json";
                
                
                
                //request.Accept = "*/*";
                //request.UserAgent = "Mozillz/4.0 (compatiable;MSIE 6.0; Window NT 5.1;SV1)";

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream rs = response.GetResponseStream();
                StreamReader reader = new StreamReader(rs, System.Text.Encoding.UTF8);
                result = reader.ReadToEnd();
                
                reader.Close();
                rs.Close();
                response.Close();
                Console.WriteLine(result);

            }

            catch (Exception ex)
            {

                Console.WriteLine("occur exception:{0}\n{1}", ex.Message, ex.StackTrace);

            }



            //return result;



        }

        static async Task getResponse() {
            using var client = new HttpClient();
            
            var response = await client.GetAsync("https://api.kcg.gov.tw/api/service/get/28efe4b3-b653-45fa-bbe8-e5514fc18292");
            var body = await response.Content.ReadAsStringAsync();
            Console.WriteLine(body);
            

        }
    }
}