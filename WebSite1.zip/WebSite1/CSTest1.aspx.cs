﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Collections;


public partial class CSTest1 : System.Web.UI.Page
{

    //public class ExUser { 
    
    //}
    string[] str = {"abc","ade","batabc","detgabc","asghj","jabc3" };
    string text = "<p>這是段文字,<h1>就是段文字</h1></p>";
    
    ArrayList list=new ArrayList();
    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Response.Write("first in<br>");
            ExUser user1 = new ExUser();
            Response.Write(user1.getInfo() + "<br>");

            ExUser user2 = new ExUser();

            user2.setName("user2");
            user2.user_id = 100;
            user2.user_age = 10;
            Response.Write(user2.getInfo() + "<br>");
            ExUser user3 = new ExxUser(name: "user3", id: 200, email: "yahoo@", age: 18);

            Response.Write(user3.getInfo() + "<br>");
            Response.Write(((ExxUser)user3).getInfo() + "<br>");

            List<ExUser> userList = new List<ExUser>();
            user1.setName("user1");
            userList.Add(user1);
            userList.Add(user2);
            userList.Add(user3);

            //SqlDataSource1 
            //string connectStr = System.Configuration.ConfigurationManager.AppSettings.Get("conn");
            /*string connectStr = "Data source=WWEISYTNCST2;Initial Catalog=AdventureWorks;Integrated Security=SSPI";
            Response.Write(connectStr);
            SqlConnection conn=new SqlConnection(connectStr);
            SqlCommand sql =new SqlCommand("select * from fweb_user_login_m where user_level='s'",conn);
            DataSet TempDS=new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter(sql);
            adapter.Fill(TempDS);
            foreach (DataRow row in TempDS.Tables[0].Rows) {

                ExxUser user = new ExxUser();
                user.setName(row["user_name"].ToString())  ;
                userList.Add(user);

            
            }*/

            foreach (ExUser u in userList)
            {

                Response.Write(u.user_name + "<br>");
            }

            var result = from s in str where s.Contains("abc") && s.Length >= 5 select s;

            foreach (var r in result)
            {

                Response.Write(r + "<br>");
            }

            Response.Write("================<br>");
            result = from s in str orderby s.Length select s;

            foreach (var s in result)
            {
                Response.Write(s + "<br>");
            }

            Response.Write("================<br>");

            var users = from u in userList orderby u.user_age descending select u;

            foreach (var u in users)
            {
                Response.Write(u.getInfo() + "<br>");
            }

            Response.Write("================<br>");
            var users2 = from u in userList orderby u.user_age ascending group u by u.user_age;
            //用group 分群時,回傳的是IGrouping<TKey,TElement>,所以沒有select 子句
            //要查找內部元素時要寫迴圈


            foreach (var element in users2)
            {

                foreach (ExUser u in element)
                {
                    Response.Write(u.getInfo() + "<br>");
                }
            }
            Response.Write("================<br>");
            var users3 = from user in userList group user by user.user_age into u select u;
            foreach (var element in users3)
            {
                foreach (ExUser u in element)
                {
                    Response.Write(u.getInfo() + "<br>");
                }

            }

            Response.Write("================<br>");
            var testArr = str.Where(s => !s.Contains("abc"));
            foreach (var s in testArr)
            {

                Response.Write(s + "<br>");
            }

            Response.Write("================<br>");

            var selectTest = str.Select(data => data);
            foreach (var s in selectTest)
            {

                Response.Write(s + "<br>");
            }

        }
        else { 
        
        
        
        
        
        }
        
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        computer.Text = Server.MachineName;
    }
    protected void SaveCookie_Click(object sender, EventArgs e)
    {
        HttpCookie cookie = new HttpCookie("cookie");
        cookie.Value = "這是塊餅乾,只能是字串的餅乾";
        //cookie.Expires = DateTime.Now.AddMinutes(1);
        cookie.Expires = DateTime.Now.AddSeconds(10);
        Response.Cookies.Add(cookie);
    }
    protected void LoadCookie_Click(object sender, EventArgs e)
    {
        if (Request.Cookies["cookie"] != null)
        {
            cookieInfo.Text=Server.HtmlEncode(Request.Cookies["cookie"].Value);
            //Response.Write(Server.HtmlEncode(Request.Cookies["cookie"].Value));              
        }
        else {
            cookieInfo.Text="nocookie";
            //Response.Write("沒有cookie了");
        }

        if (Request.Cookies["cookie"] != null)
        {
            HttpCookie aCookie = Request.Cookies["cookie"];
            //Response.Write(Server.HtmlEncode(aCookie.Value));
            cookieInfo.Text=Server.HtmlEncode(aCookie.Value);
        }
        else {
            //Response.Write("沒有cookie了");
            cookieInfo.Text="nocookie";
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        textLabel.Text =
        "<br>" + text
        + "<br>" + Server.HtmlEncode(text);
    }
    protected void ViewState_Click(object sender, EventArgs e)
    {
        if (ViewState["myView"] == null)
        {
            for (int i = 0; i < 4; i++)
            {
                list.Add("index of" + i);
            }
            ViewState.Add("myView", list);
            vsBTN.Text = "有資料了";

        }
        else {
            ArrayList list2 = (ArrayList)ViewState["myView"];
            ListBox1.DataSource = list2;
            ListBox1.DataBind();
        
        }
    }
}