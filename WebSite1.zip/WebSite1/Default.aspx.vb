﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Write("<div>hello world</div>")




    End Sub

    Function test(ByVal weight As Integer, ByVal height As Integer)
        Return weight * height

    End Function



End Class
