﻿
Partial Class Default4
    Inherits System.Web.UI.Page

#Region "事件區塊"

    Protected Sub Page_Load() Handles Me.Load
        Dim x As New Class1
        x.param1Prop = "AAA"
        x.param2Prop = 100
        Response.Write(x.getInfo)

        Dim user1 As New User

        Response.Write(user1.showUserInfo)

        Dim user2 As New User
        user2.user_name = "user2"
        user2.password = "A1234"
        user2.user_id = 1234

        Response.Write(user2.showUserInfo)
        Dim user3 As New User
        Response.Write(user3.showUserInfo)


    End Sub

#End Region






    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        resultBox.Text = Str(Rentagle(Convert.ToInt32(widthBox.Text), Convert.ToInt32(heightBox.Text)))





    End Sub

    Function Rentagle(ByVal width As Integer, ByVal height As Integer) As Integer
        Return width * height

    End Function



End Class


