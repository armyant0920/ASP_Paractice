﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

public partial class Controller : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        string path = Server.UrlDecode(Request.QueryString["path"]);
        switch (path)
            {//嘗試以switch回傳多種需求

                case "Computer":
                    Response.Write(Server.MachineName);


                

                    break;

                default:
                   
                    break;
            


        /*if (!IsPostBack) {

            Response.ContentType = "image/Jpeg";//這一段會將頁面變成呈現JPEG

            Response.Clear();
            Response.BufferOutput = true;//是否緩衝輸出並在處理完整頁後才發送
            Font rectFont = new Font("隸書", 30, FontStyle.Bold);
            int height = 120, width = 500;
            Bitmap bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            Graphics g = Graphics.FromImage(bmp);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.Black);
            g.DrawRectangle(Pens.Red, 0, 0, width - 1, height - 1);
            //g.DrawString("Hello World", rectFont, SystemBrushes.WindowText, new PointF(10, 40));
            SolidBrush brush = new SolidBrush(Color.Red);
            g.DrawString("Hello World", rectFont, brush, new PointF(10, 40));
            bmp.Save(Response.OutputStream, ImageFormat.Jpeg);
            g.Dispose();
            bmp.Dispose();
            Response.Flush();

            */
            /*string path = Server.UrlDecode(Request.QueryString["path"]);//靠居然是方括號

            switch (path)
            {//嘗試以switch回傳多種需求

                case "Draw":
                    Response.ContentType = "image/Jpeg";
                    Response.Clear();
                    Response.BufferOutput = true;//是否緩衝輸出並在處理完整頁後才發送
                    Font rectFont = new Font("隸書", 30, FontStyle.Bold);
                    int height = 120, width = 500;
                    Bitmap bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);
                    Graphics g = Graphics.FromImage(bmp);
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.Clear(Color.Black);
                    g.DrawRectangle(Pens.Red,0,0,width-1,height-1 );
                    g.DrawString("Hello World",rectFont,SystemBrushes.WindowText,new PointF(10,40));
                
                    bmp.Save(Response.OutputStream, ImageFormat.Jpeg);
                    g.Dispose();
                    bmp.Dispose();
                    Response.Flush();


                    end();

                    break;

                default:
                    end();
                    break;
            }*/
        
        
        
        
        }
        end();

        


    }
    /// <summary>
    /// 還不清楚結束段有那些共同事件可以處理,
    /// 但應該會需要擴充,故先拉出來為一個method
    /// </summary>
    private void end()
    {
        Response.End();
    }
    
}