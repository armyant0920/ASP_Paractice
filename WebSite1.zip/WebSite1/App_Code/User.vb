﻿Imports Microsoft.VisualBasic

Public Class User
    '使用
    Public user_name As String = "noname"

    Public Property user_id As Integer = 0
    Public Property password As String = "fweb"
    Private Property guid As Guid = Guid.NewGuid() '設為private 使之無法修改



    Function showUserInfo() As String

        Dim info As String = "user_name:{0},<br>user_id:{1},<br>password:{2},<br>guid:{3}<br>"
        Return String.Format(info, user_name, user_id, password, guid)

    End Function


End Class
