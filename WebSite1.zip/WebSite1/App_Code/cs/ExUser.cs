﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

/// <summary>
/// ExUser 我自訂的user物件
/// </summary>
public class ExUser
{
    /// <summary>
    /// user_name的set設為protected,避免直接公開set,但讓子類ExxUser可以設定
    /// </summary>
    public string user_name { get; protected set;}//沒辦法在後面直接 =XXX,好像是C#6.0後才可以

    public int? user_id { get; set; }//加上?以設定為可空類別

    public int user_age { get; set; }//刻意不加上?,所以如果用預設建構式,age會抓到int的預設值0




    public void setName(string name) {
        this.user_name = name;
    }

	public ExUser()
	{

		//
		// 由於此版本不支援直接在getter&setter後賦值,改在這裡初始化
		// 也就是說如果使用者沒有用含建構式的方式建立物件,設為以下的值
        this.user_name = "null";
        

	}

    public ExUser(string name, int id,int age)
    {
        this.user_name = name;
        this.user_id = id;
        this.user_age = age;

    }




    public virtual string getInfo() {

        StringBuilder sb = new StringBuilder();

        sb.Append(String.Format("userinfo: user_name={0},user_id={1},user_age={2}",user_name,user_id,user_age));
        //字元差補功能6.0後才有,該死!
        //sb.Append(String.Format($"userinfo: user_name={user_name},user_id={user_id},user_age={user_age}");

        
        return sb.ToString();

        
    }
}