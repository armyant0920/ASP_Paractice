﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

/// <summary>
/// ExxUser 的摘要描述
/// 繼承ExUser,加上email屬性
/// </summary>
public class ExxUser:ExUser
{
    public string email { get; set; }

    
	public ExxUser()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
	}

    public ExxUser(string name,int id,int age,string email) {
        
        this.user_id = id;
        this.user_name = name;
        this.user_age = age;
        this.email = email;


    
    }

    public string getInfo() {

        StringBuilder sb = new StringBuilder();

        sb.Append(String.Format("userinfo: user_name={0},user_id={1},user_age={2},e_mail={3}", user_name, user_id, user_age,email));
        return sb.ToString();
    }
}