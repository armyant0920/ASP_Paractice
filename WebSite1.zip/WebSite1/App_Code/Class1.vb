﻿Imports Microsoft.VisualBasic
Imports System.Runtime.InteropServices

Public Class Class1


    'Dim oExcel As New Excel.Application
    Dim paramA As String
    Dim paramB As Integer



    Private param1 As String
    Private param2 As Integer
    Public Property param1Prop() As String
        Get
            Return param1

        End Get
        Set(ByVal value As String)
            param1 = value

        End Set
    End Property

    Public Property param2Prop() As Integer
        Get
            Return param2

        End Get
        Set(ByVal value As Integer)
            param2 = value
        End Set
    End Property

    Public Function getInfo() As String
        Return "param1=" + param1 + "param2=" + Convert.ToString(param2)
    End Function






End Class
