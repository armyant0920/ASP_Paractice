﻿Imports System.Data
Imports System.Data.OleDb

Namespace FR

    Public Module db
        Public OLEDBCONN As New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("conn").ToString())
        Public OLEDBCONN1 As New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("ncst1_conn").ToString())

        Sub ExecuteSQL(ByVal SQL As String)
            Dim Comm As New OleDbCommand(SQL, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                Comm.ExecuteNonQuery()
            Catch ex As Exception
                Throw ex
            Finally
                Comm.Dispose()
                OLEDBCONN.Close()
            End Try
        End Sub

        Sub ExecuteSQL(ByVal conn As OleDbConnection, ByVal SQL As String)
            Dim Comm As New OleDbCommand(SQL, conn)
            Try
                If conn.State = ConnectionState.Closed Then conn.Open()
                Comm.ExecuteNonQuery()
            Catch ex As Exception
                Throw ex
            Finally
                Comm.Dispose()
                conn.Close()
            End Try
        End Sub

        Function Get_ExecuteSQL_Result(ByVal SQL As String) As Integer
            Dim Comm As New OleDbCommand(SQL, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                Return Comm.ExecuteNonQuery()
            Catch ex As Exception
                Throw ex
            Finally
                Comm.Dispose()
                OLEDBCONN.Close()
            End Try
        End Function

        Function GetExecuteScalar(ByVal sqlstr As String) As Object
            Dim comm As New OleDbCommand(sqlstr, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                GetExecuteScalar = comm.ExecuteScalar
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                OLEDBCONN.Close()
            End Try
        End Function

        Function GetExecuteScalar(ByVal conn As OleDbConnection, ByVal sqlstr As String) As Object
            Dim comm As New OleDbCommand(sqlstr, conn)
            Try
                If conn.State = ConnectionState.Closed Then conn.Open()
                GetExecuteScalar = comm.ExecuteScalar
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                conn.Close()
            End Try
        End Function

        'Function FillDataSet(ByVal sql As String, ByVal tablename As String) As DataSet
        '    Try
        '        Dim ds As New DataSet
        '        Dim da As New OleDbDataAdapter(sql, OLEDBCONN)
        '        da.Fill(ds, tablename)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        OLEDBCONN.Close()
        '    End Try
        'End Function

        'Function FillDataSet(ByVal sql As String, ByVal tablename As String, ByVal ds As DataSet) As DataSet
        '    Try
        '        Dim da As New OleDbDataAdapter(sql, OLEDBCONN)
        '        da.Fill(ds, tablename)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        OLEDBCONN.Close()
        '    End Try
        'End Function


        Function FillDataSet(ByVal SQL As String) As DataSet
            Dim ds As New DataSet
            Dim da As New OleDbDataAdapter(SQL, OLEDBCONN)
            Try
                da.Fill(ds)
                Return ds
            Catch ex As Exception
                Throw ex
            Finally
                OLEDBCONN.Close()
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
        End Function

        Function FillDataSet(ByVal sql As String, ByVal IntConnectType As Integer) As DataSet
            Dim ds As New DataSet
            Try
                Select Case IntConnectType
                    Case 1  'NCST1
                        Dim da As New OleDbDataAdapter(sql, OLEDBCONN1)
                        da.Fill(ds)
                        da.Dispose()
                    Case 2  'NCST2
                        Dim da As New OleDbDataAdapter(sql, OLEDBCONN)
                        da.Fill(ds)
                        da.Dispose()
                End Select
                Return ds
            Catch ex As Exception
                Throw ex
            Finally
                Select Case 1
                    Case 1
                        OLEDBCONN1.Close()
                    Case 2
                        OLEDBCONN.Close()
                End Select
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
        End Function

        'Function FillDataSet(ByVal conn As OleDbConnection, ByVal sql As String) As DataSet
        '    Try
        '        Dim ds As New DataSet
        '        Dim da As New OleDbDataAdapter(sql, conn)
        '        da.Fill(ds)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        conn.Close()
        '    End Try
        'End Function

        'Function FillDataSet(ByVal conn As OleDbConnection, ByVal sql As String, ByVal tablename As String) As DataSet
        '    Try
        '        Dim ds As New DataSet
        '        Dim da As New OleDbDataAdapter(sql, conn)
        '        da.Fill(ds, tablename)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        conn.Close()
        '    End Try
        'End Function

        Sub GetDataReader(ByRef dr As OleDbDataReader, ByVal sqlstr As String)         '調用datareader,請切記使用byref 引用方式()
            Dim comm As New OleDbCommand(sqlstr, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                dr = comm.ExecuteReader
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                'OLEDBCONN.Close()
            End Try
        End Sub

        Sub GetDataReader(ByVal conn As OleDbConnection, ByRef dr As OleDbDataReader, ByVal sqlstr As String)        '調用datareader,請切記使用byref 引用方式()
            Dim comm As New OleDbCommand(sqlstr, conn)
            Try
                If conn.State = ConnectionState.Closed Then conn.Open()
                dr = comm.ExecuteReader
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                conn.Close()
            End Try
        End Sub

        Public Function GetDataReader(ByVal SQLText As String, ByVal Num As Integer) As String
            Dim myCMD As OleDbCommand = New OleDbCommand(SQLText, OLEDBCONN)
            Dim str As String = ""
            If OLEDBCONN.State = ConnectionState.Closed Then
                OLEDBCONN.Open()
            End If
            Dim myReader As OleDbDataReader = myCMD.ExecuteReader()
            Do While myReader.Read()
                str = myReader.GetString(Num)
            Loop
            myReader.Close()
            OLEDBCONN.Close()
            myCMD.Dispose()
            Return str
        End Function

        Sub CloseConn()
            If OLEDBCONN.State <> ConnectionState.Closed Then OLEDBCONN.Close()
        End Sub

        Sub CloseConn(ByVal conn As OleDbConnection)
            If conn.State <> ConnectionState.Closed Then conn.Close()
        End Sub

    End Module

End Namespace

