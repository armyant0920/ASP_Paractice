﻿Imports Microsoft.VisualBasic

Public Class SysUser



End Class
