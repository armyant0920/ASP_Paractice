﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



                                                                                                                                                                                                                                                                                        

public partial class Default3 : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        var str = "";
        str += "<div><p>hihihihihihhihihihi</p>";
        str += "<table id='mytable' name='mytable'>";
        for (int i = 2; i <= 9; i++) {
            
            for (int j = 2; j <= 9; j++) {
                if (j == 2) str += "<tr>";
                str += "<td>"+i+"*"+j+"="+i*j+"</td>";
                if (j == 9) str += "</tr>";          
            
            
            }
        }
        str += "</table>";



            Response.Write(str);


            


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Text="tttt";
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        Button1.Text = TextBox1.Text;
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {
        if (Value1.Text != "" && Value2.Text != "") {

            Result.Text = Convert.ToString(Int32.Parse(Value1.Text) + int.Parse(Value2.Text));
        }
        //Result.Text = Convert.ToString(Int32.Parse(Value1.Text) + int.Parse(Value2.Text));
        //Result.Text = "1111";
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        if (!IsPostBack) { 
        
            
        }
    }
}