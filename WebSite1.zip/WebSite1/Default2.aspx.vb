﻿Imports System.Data
Imports System.Data.OleDb

Partial Class Default2
    Inherits System.Web.UI.Page


    Public OLEDBCONN As New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("conn").ToString())

    Dim debug As String

    Protected Sub Page_init() Handles Me.Init 'Me 繼承了Web.UI.Page類,因此可以呼叫相關事件
        'Response.Write("<p>" + DateTime.Today.ToString("MM/dd/yyyy hh:mm:ss.fff") + " init </p>")
        Response.Write("<p>" + Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + " init </p>")
    End Sub
    Protected Sub Page_LoadComplete() Handles Me.DataBinding
        Console.WriteLine("Load Complete")

    End Sub




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.Write("<p>" + Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + " load </p>")
        '嘗試顯示Web.config資訊
        Dim connect As String
        connect = System.Configuration.ConfigurationManager.AppSettings("conn").ToString()
        Response.Write(connect + "<br>")

        Dim TempDS As New DataSet
        Dim sqlstr As String
        Dim dv As New DataView


        sqlstr = "SELECT distinct ORG 編號,ORG_NAME 名稱 FROM UCCST_ORG_T ORDER BY ORG"
        TempDS = FillDataSet(sqlstr)
        dv = TempDS.Tables(0).DefaultView
        dg.DataSource = dv
        dg.DataBind()


        Dim index As Integer
        index = 4

        Select Case index
            Case 1
                Response.Write("hi everyone<br>")

            Case 2
                Response.Write("bye everyone<br>")

            Case Else
                Response.Write("ELSE<br>")
        End Select

        Dim sum As Integer
        'from 1~10
        For I = 1 To 10
            sum = sum + I
        Next

        Response.Write(sum.ToString() + "<br>")

        Dim sb As New StringBuilder


        For J = 1 To 10
            sb.Append("<br>" & J.ToString() & "<br>")


        Next

        Response.Write(sb.ToString)


        If (Button1.Text = "Button") Then
            Button1.Text = "1"
        Else
            Button1.Text = Val(Button1.Text) + 1

        End If

        Dim num As Integer = 0
        Dim result As String

        'result = IIf(num <> 0, 50 / 0, 50)
        result = IIf(num <> 0, A(), B())



        Response.Write(result + "<br>")

        result = If(num = 0, A(), B())
        Response.Write(result + "<br>")





    End Sub

    Function A() As String
        Response.Write("A()")
        Return "A"




    End Function
    Function B() As String

        Response.Write("B()")
        Return "B"
    End Function
    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        'If (Button1.Text = "Button") Then
        'Button1.Text = "1"
        'Else
        'Button1.Text = Val(Button1.Text) + 1

        ' End If




    End Sub

    Function FillDataSet(ByVal SQL As String) As DataSet
        Dim ds As New DataSet
        Dim da As New OleDbDataAdapter(SQL, OLEDBCONN)
        Try
            da.Fill(ds)
            Return ds
        Catch ex As Exception
            Throw ex
        Finally
            OLEDBCONN.Close()
            If Not ds Is Nothing Then
                ds.Dispose()
            End If
        End Try
    End Function



    Protected Sub SqlDataSource1_Selecting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs) Handles SqlDataSource1.Selecting

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        SqlDataSource1.Dispose()
        Dim rnd As New Random()
        Dim sql As String
        sql = "select * from fweb_user_login_m where rownum<=" + Str(rnd.Next(10, 20))

        SqlDataSource1.SelectCommand = sql

        GridView1.DataBind()








    End Sub
End Class
