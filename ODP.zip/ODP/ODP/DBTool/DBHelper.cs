﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;

namespace R12.DBTool
{
    interface DBHelper
    {

        DataTable queryDT(string sql);

        DataTable queryDT(DbCommand cmd);
        DbConnection getDBConn();

        DataTable queryDT(string commandtext,Dictionary<string,string>param);

        DataSet queryAD(string commandtext,Dictionary<string,string>param);
        void close();
    }
}
