﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;

namespace R12.DBTool
{
    class WMINV
    {

        DBHelper helper;

        public WMINV(DBHelper h) {

            helper = h;
        
        }

        public DataTable query_machine_code()
        {
            
            string sql = @"select distinct machine_code from WMINV_CONTAINER_M";
         
            
            return helper.queryDT(sql,null);
        
        }

        public DataSet query_machine() {

            string sql = @"select * from WMINV_CONTAINER_M where machine_code=:code and rownum<=10";
            Dictionary<string, string> param = new Dictionary<string, string>();

            param.Add("code", "0012");
            return helper.queryAD(sql, param);


        }

        public int update_WMINV_CONTAINER() {

            int num = 0;


            return num;

            string sql="update WMINV_CONTAINER_M" 
                       +"set Order_no = decode(length(:Order_no),0,Order_no,:Order_no2),"
                       +"Order_Seq = decode(length(:Order_Seq),0,Order_Seq,:Order_Seq2),"
                       +"Invoice_no = decode(length(:Invoice_no),0,Invoice_no,:Invoice_no2),"
                       +"Ship_Mark = decode(length(:Ship_Mark),0,Ship_Mark,:Ship_Mark2),"
                       +"updated_by = :USERNAME,"
                       +"updated_date = sysdate"
                       +" where nvl(DEL_FLAG,'N') <> 'Y' and "
                       +" DELIVERY_NO = :DELIVERY_NO and "
                       +" ORG_ID = :ORG_ID";

        
        }



    }
}
