﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.Common;
using System.Data;

namespace R12.DBTool
{
    class OleDB : DBHelper
    {
        private OleDbConnection conn = null;
        private OleDbDataAdapter da = null;

        public OleDB()
        {
            string s = System.Configuration.ConfigurationManager.AppSettings["oledb"].ToString();
            Console.WriteLine("oledb={0}", s);
            conn = new OleDbConnection(s);
            Console.WriteLine("this is oledb");

        }

        public DbConnection getDBConn()
        {
            return conn;

        }

        public void close()
        {
            conn.Close();
        }

        public DataTable queryDT(string sql)
        {
            DataTable dt = new DataTable();
            da = new OleDbDataAdapter(sql, conn);
            da.Fill(dt);
            return dt;
        }

        public DataTable queryDT(DbCommand cmd)
        {

            conn.Open();
            using (conn)
            {
                //setInfo(conn);
                System.Data.DataTable dt = new DataTable();
                //強轉為Oledbcommand
                OleDbCommand command = (OleDbCommand)cmd;

                Console.WriteLine("cmdtxt={0}", command.CommandText);

                //Console.WriteLine("cmdparam name={0},value={1}", cmd.Parameters[0].SourceColumn,cmd.Parameters[0].Value);

                da = new OleDbDataAdapter(command.CommandText, conn);

                foreach (OleDbParameter p in command.Parameters)
                {

                    Console.WriteLine("param name={0},value={1}", p.ParameterName, p.Value);
                    da.SelectCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                    //da.SelectCommand.Parameters.Add(p.ParameterName, p.Value);

                }
                //da.SelectCommand.Parameters.Add(new OracleParameter("code", Oracle.ManagedDataAccess.Client.OracleDbType.NVarchar2,2));
                //da.SelectCommand.Parameters[0].Value = "A%";
                da.Fill(dt);
                Console.WriteLine("dt rows={0}", dt.Rows.Count.ToString());
                close();
                return dt;

            }

        }

        public DataTable queryDT(string commandtext, Dictionary<string, string> param)
        {
            conn.Open();
            using (conn)
            {
                
                System.Data.DataTable dt = new DataTable();
                OleDbCommand command = new OleDbCommand(commandtext);
                Console.WriteLine("cmdtxt={0}", command.CommandText);
                //Console.WriteLine("cmdparam name={0},value={1}", cmd.Parameters[0].SourceColumn,cmd.Parameters[0].Value);
                da = new OleDbDataAdapter(command.CommandText, conn);

                if (param!=null && param.Count>0) { 
                    foreach (string key in param.Keys)
                    {

                        Console.WriteLine("param key={0},value={1}", key, param[key]);
                        da.SelectCommand.Parameters.AddWithValue(key, param[key]);

                    }
                }
                //da.SelectCommand.Parameters.Add(new OracleParameter("code", Oracle.ManagedDataAccess.Client.OracleDbType.NVarchar2,2));
                //da.SelectCommand.Parameters[0].Value = "A%";
                da.Fill(dt);
                Console.WriteLine("dt rows={0}", dt.Rows.Count.ToString());
                close();
                return dt;
            }
        }


        public DataSet queryAD(string commandtext, Dictionary<string, string> param)
        {
            DataSet ds = new DataSet();
            conn.Open();
            using (conn)
            {                
                OleDbCommand command = new OleDbCommand(commandtext);
                Console.WriteLine("cmdtxt={0}", command.CommandText);
                //Console.WriteLine("cmdparam name={0},value={1}", cmd.Parameters[0].SourceColumn,cmd.Parameters[0].Value);
                da = new OleDbDataAdapter(command.CommandText, conn);

                if (param != null && param.Count > 0)
                {
                    foreach (string key in param.Keys)
                    {

                        Console.WriteLine("param key={0},value={1}", key, param[key]);
                        da.SelectCommand.Parameters.AddWithValue(key, param[key]);

                    }
                }
                da.Fill(ds);

                Console.WriteLine("DataSet Contain dt nums:{0}", ds.Tables.Count.ToString());
                close();
                return ds;
            }
        }


    }
}
