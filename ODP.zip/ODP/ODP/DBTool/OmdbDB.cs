﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.ManagedDataAccess.Client;
using System.Data.Common;
using System.Data;

namespace R12.DBTool
{
    class OmdbDB:DBHelper
    {

        private OracleConnection conn = null;
        private OracleDataAdapter da = null;

        private string nlsLang = "American_America.ZHT16big5";

        private void setInfo(OracleConnection conn) {

            OracleGlobalization info = conn.GetSessionInfo();
            var arr = nlsLang.Split('_');
            string language = arr[0];
            arr = arr[1].Split('.');
            string territory = arr[0];
            string characterSet = arr[1];
            info.Language = language;
            info.Territory = territory;
            info.NumericCharacters = characterSet;
            conn.SetSessionInfo(info);  

        }
        
        public OmdbDB() {
            
            string s = System.Configuration.ConfigurationManager.AppSettings["omdb"].ToString();
            Console.WriteLine("omdb={0}", s);
            conn = new OracleConnection(System.Configuration.ConfigurationManager.AppSettings["omdb"].ToString());                       
            Console.WriteLine("this is oracle");
        }
        public DbConnection getDBConn()
        {
            return conn;

        }
        public void close()
        {
            conn.Close();
        }

        public DataTable queryDT(string sql)
        {
            DataTable dt = new DataTable();
            da = new OracleDataAdapter(sql, conn);
            da.Fill(dt);
            return dt;
        }

        public DataTable queryDT(string commandtext,Dictionary<string,string>param)
        {
            conn.Open();
            using (conn)
            {
                setInfo(conn);
                System.Data.DataTable dt = new DataTable();
                OracleCommand command = new OracleCommand(commandtext);
                Console.WriteLine("cmdtxt={0}", command.CommandText);
                //Console.WriteLine("cmdparam name={0},value={1}", cmd.Parameters[0].SourceColumn,cmd.Parameters[0].Value);
                da = new OracleDataAdapter(command.CommandText, conn);

                if (param!=null &&param.Count>0) {
                    foreach (string key in param.Keys)
                    {

                        Console.WriteLine("param key={0},value={1}", key, param[key]);
                        da.SelectCommand.Parameters.Add(key, param[key]);

                    }
                
                }
               
                //da.SelectCommand.Parameters.Add(new OracleParameter("code", Oracle.ManagedDataAccess.Client.OracleDbType.NVarchar2,2));
                //da.SelectCommand.Parameters[0].Value = "A%";
                da.Fill(dt);
                Console.WriteLine("dt rows={0}", dt.Rows.Count.ToString());
                close();
                return dt;
            }
        }

        public DataTable queryDT(DbCommand cmd)
        {           
            conn.Open();
            using (conn) {
                setInfo(conn);
                System.Data.DataTable dt = new DataTable();
                OracleCommand command = (OracleCommand)cmd;
                Console.WriteLine("cmdtxt={0}", command.CommandText);
                //Console.WriteLine("cmdparam name={0},value={1}", cmd.Parameters[0].SourceColumn,cmd.Parameters[0].Value);
                da = new OracleDataAdapter(command.CommandText, conn);
                foreach (OracleParameter p in command.Parameters)
                {

                    Console.WriteLine("param name={0},value={1}", p.ParameterName, p.Value);
                    da.SelectCommand.Parameters.Add(p.ParameterName, p.Value);
                    
                }
                //da.SelectCommand.Parameters.Add(new OracleParameter("code", Oracle.ManagedDataAccess.Client.OracleDbType.NVarchar2,2));
                //da.SelectCommand.Parameters[0].Value = "A%";
                da.Fill(dt);
                Console.WriteLine("dt rows={0}", dt.Rows.Count.ToString());
                close();
                return dt;                      
            }
        }


        public DataSet queryAD(string commandtext,Dictionary<string,string>param)
        {
            DataSet ds = new DataSet();
            conn.Open();
            using (conn)
            {
                setInfo(conn);
             
                OracleCommand command = new OracleCommand(commandtext);
                Console.WriteLine("cmdtxt={0}", command.CommandText);
                //Console.WriteLine("cmdparam name={0},value={1}", cmd.Parameters[0].SourceColumn,cmd.Parameters[0].Value);
                da = new OracleDataAdapter(command.CommandText, conn);

                if (param != null && param.Count > 0)
                {
                    foreach (string key in param.Keys)
                    {

                        Console.WriteLine("param key={0},value={1}", key, param[key]);
                        da.SelectCommand.Parameters.Add(key, param[key]);
                    }
                }
                da.Fill(ds);
                Console.WriteLine("DataSet Contain dt nums:{0}",ds.Tables.Count.ToString());
                close();
                return ds;
            }
        }

    }
}
