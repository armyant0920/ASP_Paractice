﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace R12.LogTool
{
    public static class MyLog
    {
        StringBuilder sb;
        string file_path;

        static bool writeFile() {

            bool success = false;
            return success;
        }

        static void append() { 
        
        
        }
    }
}
