﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace R12.LogTool
{
    public static class LogWriter:IDisposable
    {
        private FileStream fs;
        private StreamWriter sw;

        private readonly TextWriter consoleOut;
        private readonly TextWriter fileOut;

        void setPath(string path) { 
            
        
        
        }
        

        private class DoubleWriter : TextWriter
        {
            private TextWriter writer1;
            private TextWriter writer2;
        
        }
    }
}
