﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
//using System.Data.OracleClient;
using System.Data;
using R12.DBTool;
using System.Data.OleDb;
using System.Threading;

namespace R12
{
    public partial class Form1 : Form
    {
        DBHelper dbHelper;
        
        
        
        public Form1()
        {
            InitializeComponent();
            setEvent();
            //Thread.Sleep(5000);
            //MessageBox.Show("start");
            dbHelper = new OmdbDB();

        }

        private void setEvent() {

            foreach (Control c in this.Controls) {
                Console.WriteLine("name={0}", c.Name);
                
                c.Click += new EventHandler(event_catch);
                
            }
            
            MouseMove += new MouseEventHandler(MouseEvent);
            
        
        
        }

        private void MouseEvent(object sender,EventArgs e) {
            Console.WriteLine("mouse at:{0}",Form1.MousePosition.ToString());
            //Console.WriteLine("sender name:{0},event={1}", sender.ToString(), e.ToString());
        }

        private void event_catch(object sender,EventArgs e) {

            Console.WriteLine("sender name:{0},event={1}",sender.ToString(),e.ToString());
        
        }


        private void button1_Click(object sender, EventArgs e)
        {
            
            DBHelper helper = new OmdbDB();
            DBHelper helper2 = new OleDB();
            string cmdtxt = @"select organization_code , name from wwei_orgs where organization_code like :code";
            OracleCommand cmd = new OracleCommand(cmdtxt);
            
            //cmd.CommandText = cmdtxt;
            OracleParameter param = new OracleParameter("code", Oracle.ManagedDataAccess.Client.OracleDbType.NVarchar2,2);
            param.Value = "A%";
            cmd.Parameters.Add(param);
            //DataTable dt=helper.query(new OleDbCommand(cmdtxt));
            DataTable dt = helper.queryDT(cmd);
            Console.WriteLine("dt Row={0}", dt.Rows.Count.ToString());
            gv_org.DataSource = dt;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            DBHelper helper2 = new OleDB();
            string cmdtxt = @"select organization_code , name from wwei_orgs where organization_code like ?";
            OleDbCommand cmd = new OleDbCommand(cmdtxt);

            //cmd.CommandText = cmdtxt;
            OleDbParameter param = new OleDbParameter("code", OleDbType.VarChar, 2);
            param.Value = "7%";
            cmd.Parameters.Add(param);
            //DataTable dt=helper.query(new OleDbCommand(cmdtxt));
            DataTable dt = helper2.queryDT(cmd);
            Console.WriteLine("dt Row={0}", dt.Rows.Count.ToString());
            gv_org.DataSource = dt;


        }

        private void button3_Click(object sender, EventArgs e)
        {
            DBHelper helper = new OmdbDB();
            DataTable dt = new WMINV(helper).query_machine_code();
            foreach (DataRow row in dt.Rows) {
                foreach (DataColumn col in dt.Columns) {
                    Console.Write(row[col.ColumnName] + "\t");
                
                }
                Console.WriteLine();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DataTable dt = new WMINV(dbHelper).query_machine().Tables[0];
            

            foreach (DataRow row in dt.Rows)
            {
                foreach (DataColumn col in dt.Columns)
                {
                    Console.Write(row[col.ColumnName] + "\t");

                }
                Console.WriteLine();
            }


        }
    }
}
