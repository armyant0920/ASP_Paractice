Namespace FR

Partial Class FWEB_LOGIN_SYSTEM
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not Page.IsPostBack Then
            viewstate("strquery") = "SELECT PROJ_NO,PROJ_NAME,FUNC_NO,FUNC_NAME,FUNC_PATH,MUSER,to_char(MDATE,'yyyy/MM/dd') as MDATE FROM  FWEB_SYSTEM order by PROJ_NO"
            Button1.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_PROJ.aspx?type=a", 640, 480))
            Button2.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_FUNC.aspx?type=a", 640, 480))
            bind_data()
            btn_state(0)
        End If
    End Sub

    Private Sub BN_QUR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_QUR.Click
        btn_state(0)
        Dim PROJ_NO As String, FUNC_NO As String
        PROJ_NO = Trim(Text1.Value)
        FUNC_NO = Trim(TextBox1.Text)
        bind_dg_query(PROJ_NO, FUNC_NO)
    End Sub

    Private Sub BN_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_ADD.Click
        btn_state(1)
        Text1.Value = ""
        Text2.Value = ""
        TextBox1.Text = ""
        Text3.Value = ""
        Text4.Value = ""
        DataGrid1.Columns(0).Visible = False
        DataGrid1.Columns(1).Visible = False
    End Sub

    Private Sub BN_SAV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SAV.Click
        Dim strsql As String
        label()
        If check_text() = False Then
            Exit Sub
        End If
        If TextBox1.ReadOnly = True Then
                strsql = String.Format("update FWEB_SYSTEM set PROJ_NAME='{0}',FUNC_NAME='{1}',FUNC_PATH='{2}',mdate=sysdate where PROJ_NO='{3}' and FUNC_NO='{4}'", Trim(Text2.Value), Trim(Text3.Value), Trim(Text4.Value), Trim(Text1.Value), Trim(TextBox1.Text))
        Else
            If check_data(Trim(Text1.Value), Trim(TextBox1.Text)) = False Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ӰO���w�s�b!');</script>")
                Exit Sub
            End If
                strsql = String.Format("insert into  FWEB_SYSTEM(SYST_NO,SYST_NAME,PROJ_NO,PROJ_NAME,FUNC_NO,FUNC_NAME,FUNC_PATH,MDATE) values('FWEB','�]�ȳ���','{0}','{1}','{2}','{3}','{4}',sysdate)", Trim(Text1.Value), Trim(Text2.Value), Trim(TextBox1.Text), Trim(Text3.Value), Trim(Text4.Value))
        End If
        db.ExecuteSQL(strsql)
        cancel()
    End Sub

    Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CAN.Click
        cancel()
    End Sub
    Sub bind_data()
        With db.FillDataSet(viewstate("strquery")).Tables(0)
            DataGrid1.DataSource = .DefaultView
            DataGrid1.DataBind()
            DataGrid1.Height = Unit.Pixel(1)
            Aspnetpager1.RecordCount = .Rows.Count
            Aspnetpager1.CustomInfoText = GetPageInfo(Aspnetpager1)
        End With
    End Sub
    Function GetPageInfo(ByRef p As Wuqi.Webdiyer.AspNetPager) As String
        Return String.Format _
        ("��<font color=red><b>{0}</b></font>��&nbsp&nbsp�@<font color=blue><b>{1}</b></font>��<font color=blue><b>{2}</b></font>��", p.CurrentPageIndex.ToString, p.PageCount.ToString, p.RecordCount.ToString)
    End Function
    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�D�s�説�A
            BN_QUR.Enabled = True
            BN_ADD.Enabled = True
            BN_SAV.Enabled = False
            BN_CAN.Enabled = False
        Else                                   '�s�説�A
            BN_QUR.Enabled = False
            BN_ADD.Enabled = False
            BN_SAV.Enabled = True
            BN_CAN.Enabled = True
        End If
    End Sub
    Private Sub DataGrid1_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R���ӱ��O����?');")
        End If
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub
    Private Sub DataGrid1_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.ItemCommand
        If e.CommandName = "delete" Then
            Dim str As String = "delete from FWEB_SYSTEM where PROJ_NO='" + e.Item.Cells(2).Text + "' and FUNC_NO='" + e.Item.Cells(4).Text + "'"
            Try
                db.ExecuteSQL(str)
            Catch ex As Exception
                Throw ex

            Finally
                cancel()
            End Try
        Else
            TextBox1.Enabled = False
            TextBox1.ReadOnly = True
            Text1.Disabled = True
            Button1.Disabled = True
            Button2.Disabled = True
            bindtext(e.Item.Cells(2).Text, e.Item.Cells(4).Text)
            btn_state(1)
            DataGrid1.Columns(0).Visible = False
            DataGrid1.Columns(1).Visible = False
        End If
    End Sub
    Sub bindtext(ByVal PROJ_NO As String, ByVal FUNC_NO As String)
        Dim strsql As String
        strsql = "SELECT PROJ_NO,PROJ_NAME,FUNC_NO,FUNC_NAME,FUNC_PATH FROM  FWEB_SYSTEM where PROJ_NO='" + PROJ_NO + "' and FUNC_NO='" + FUNC_NO + "'"
        Dim ds As DataSet
        ds = db.FillDataSet(strsql)
        Text1.Value = ds.Tables(0).Rows(0).Item("PROJ_NO")
        Text2.Value = ds.Tables(0).Rows(0).Item("PROJ_NAME")
        TextBox1.Text = ds.Tables(0).Rows(0).Item("FUNC_NO")
        Text3.Value = ds.Tables(0).Rows(0).Item("FUNC_NAME")
        Text4.Value = ds.Tables(0).Rows(0).Item("FUNC_PATH")
    End Sub
    Sub bind_dg_query(ByVal PROJ_NO As String, ByVal FUNC_NO As String)
        Dim strsql As String
        strsql = "SELECT PROJ_NO,PROJ_NAME,FUNC_NO,FUNC_NAME,FUNC_PATH,MUSER,to_char(MDATE,'yyyy/MM/dd') as MDATE FROM  FWEB_SYSTEM where PROJ_NO like '%" + PROJ_NO + "%' and FUNC_NO like '%" + FUNC_NO + "%' order by PROJ_NO"
        viewstate("strquery") = strsql
        bind_data()
    End Sub
    Sub label()
        Label7.Visible = False
        Label11.Visible = False
        Label16.Visible = False
        Label12.Visible = False
        Label17.Visible = False
    End Sub
    Function check_text() As Boolean
        If Trim(Text1.Value) = "" Then
            Label11.Visible = True
        End If
        If Trim(Text2.Value) = "" Then
            Label12.Visible = True
        End If
        If Trim(TextBox1.Text) = "" Then
            Label16.Visible = True
        End If
        If Trim(Text3.Value) = "" Then
            Label17.Visible = True
        End If
        If Trim(Text4.Value) = "" Then
            Label7.Visible = True
        End If
        If Label7.Visible = True Or Label16.Visible = True Or Label17.Visible = True Or Label11.Visible = True Or Label12.Visible = True Then
            Return False
        Else
            Return True
        End If
    End Function
    Sub cancel()
        btn_state(0)
        label()
        DataGrid1.Columns(0).Visible = True
        DataGrid1.Columns(1).Visible = True
        TextBox1.Enabled = True
        TextBox1.ReadOnly = False
        Text1.Disabled = False
        Text1.Value = ""
        Text2.Value = ""
        Text3.Value = ""
        TextBox1.Text = ""
        Text4.Value = ""
        Button1.Disabled = False
        Button2.Disabled = False
        viewstate("strquery") = "SELECT PROJ_NO,PROJ_NAME,FUNC_NO,FUNC_NAME,FUNC_PATH,MUSER,to_char(MDATE,'yyyy/MM/dd') as MDATE FROM  FWEB_SYSTEM order by PROJ_NO"
        bind_data()
    End Sub
    Function check_data(ByVal PROJ_NO As String, ByVal FUNC_NO As String) As Boolean
        Dim strsql As String
        strsql = "select count(*) from FWEB_SYSTEM where PROJ_NO='" + PROJ_NO + "' and FUNC_NO='" + FUNC_NO + "'"
        If db.GetExecuteScalar(strsql) > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub AspNetPager1_PageChanged(ByVal src As System.Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs)
        DataGrid1.EditItemIndex = -1
        DataGrid1.CurrentPageIndex = 0
        DataGrid1.CurrentPageIndex = e.NewPageIndex - 1
        Aspnetpager1.CurrentPageIndex = e.NewPageIndex
        bind_data()
    End Sub
End Class

End Namespace
