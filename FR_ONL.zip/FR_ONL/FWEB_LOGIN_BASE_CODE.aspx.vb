Imports System.Data.OleDb
Imports System.Configuration


Namespace FR

Partial Class FWEB_LOGIN_BASE_CODE
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            LoadProjNo()
            LoadClassNo()
            SetDisplay("M", False)
            SetDisplay("D", False)
        End If
    End Sub

#Region "��l�ƱM�ץN�X�B�N��-�j���B�e��"
    '���
    Sub LoadProjNo()
        Dim sqlstr As String
        sqlstr = "SELECT DISTINCT PROJ_NO, PROJ_NAME FROM FWEB_SYSTEM WHERE SYST_NO LIKE NVL('" + txtSystNo.Text + "','%') "
        '�d��-�M��
        ddlProjName.DataSource = db.FillDataSet(sqlstr).Tables(0)
        ddlProjName.DataValueField = "PROJ_NO"
        ddlProjName.DataTextField = "PROJ_NAME"
        ddlProjName.DataBind()
        ddlProjName.Items.Insert(0, "")
        'Master DBGrid-�s�W-�M��
        ddlProjNameM.DataSource = db.FillDataSet(sqlstr).Tables(0)
        ddlProjNameM.DataValueField = "PROJ_NO"
        ddlProjNameM.DataTextField = "PROJ_NAME"
        ddlProjNameM.DataBind()
        ddlProjNameM.Items.Insert(0, "")
    End Sub

    '�N��-�j��
    Sub LoadClassNo()
        Dim sqlstr As String
        sqlstr = "SELECT CLASS_NO, CLASS_NAME FROM FWEB_BASE_CODE_M " & _
                 " WHERE SYST_NO LIKE NVL('" + txtSystNo.Text + "','%') " & _
                 "   AND PROJ_NO LIKE NVL('" + txtProjNo.Text + "','%') "
        ddlClassName.DataSource = db.FillDataSet(sqlstr).Tables(0)
        ddlClassName.DataValueField = "CLASS_NO"
        ddlClassName.DataTextField = "CLASS_NAME"
        ddlClassName.DataBind()
        ddlClassName.Items.Insert(0, "")
    End Sub

    '�e��
    Sub SetDisplay(ByVal QueryType As String, ByVal IsDisplay As Boolean)
        If QueryType = "M" Then      'Master���
            lblSystM.Visible = IsDisplay
            txtSystNoM.Visible = IsDisplay
            ddlSystNameM.Visible = IsDisplay
            lblProjM.Visible = IsDisplay
            txtProjNoM.Visible = IsDisplay
            ddlProjNameM.Visible = IsDisplay
            lblClassM.Visible = IsDisplay
            txtClassNoM.Visible = IsDisplay
            txtClassNameM.Visible = IsDisplay
            btnAddMaster.Visible = IsDisplay
        ElseIf QueryType = "D" Then  'Detail���
            lblKindD.Visible = IsDisplay
            txtKindNoD.Visible = IsDisplay
            txtKindNameD.Visible = IsDisplay
            btnAddDetail.Visible = IsDisplay
        End If
    End Sub
#End Region

#Region "�d��"
    '�d��
    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
        QueryData("M")
        SetDisplay("M", True)
        txtSystNoD.Text = ""
        txtProjNoD.Text = ""
        txtClassNoD.Text = ""
        QueryData("D")
        SetDisplay("D", False)
    End Sub

    '�d�߸��
    Sub QueryData(ByVal QueryType As String)
        If QueryType = "M" Then      '�d��Master���
            dgMaster.CurrentPageIndex = 0
        ElseIf QueryType = "D" Then  '�d��Detail���
            dgDetail.CurrentPageIndex = 0
        End If
        BindData(QueryType)
    End Sub

    'BindData
    Sub BindData(ByVal QueryType As String)
        Dim ds As New DataSet
        If QueryType = "M" Then      '�d��Master���            
            ds = db.FillDataSet(QueryString("M"))
            dgMaster.DataSource = ds.Tables(0)
            dgMaster.DataBind()
        ElseIf QueryType = "D" Then  '�d��Detail���            
            ds = db.FillDataSet(QueryString("D"))
            dgDetail.DataSource = ds.Tables(0)
            dgDetail.DataBind()
        End If
    End Sub
#End Region

    '�]�wQuery SQL
    Function QueryString(ByVal QueryType As String) As String
            Dim sqlstr As String = ""

        If QueryType = "M" Then      '�d��Master���          

            sqlstr = "SELECT M.*, S.SYST_NAME, S.PROJ_NAME " & _
                     "  FROM FWEB_BASE_CODE_M M, " & _
                     "       (SELECT DISTINCT SYST_NO, SYST_NAME, PROJ_NO, PROJ_NAME FROM FWEB_SYSTEM) S " & _
                     " WHERE M.SYST_NO LIKE NVL('" + txtSystNo.Text + "','%') " & _
                     "   AND M.PROJ_NO LIKE NVL('" + txtProjNo.Text + "','%') " & _
                     "   AND M.CLASS_NO LIKE NVL('" + txtClassNo.Text + "','%') " & _
                     "   AND M.SYST_NO = S.SYST_NO(+) " & _
                     "   AND M.PROJ_NO = S.PROJ_NO(+) " & _
                     " ORDER BY M.SYST_NO, M.PROJ_NO, M.CLASS_NO "

        ElseIf QueryType = "D" Then  '�d��Detail���    

            sqlstr = "SELECT D.* " & _
                     "  FROM FWEB_BASE_CODE_D D " & _
                     " WHERE D.SYST_NO = '" + txtSystNoD.Text + "'" & _
                     "   AND D.PROJ_NO = '" + txtProjNoD.Text + "'" & _
                     "   AND D.CLASS_NO = '" + txtClassNoD.Text + "'" & _
                     " ORDER BY D.KIND_NO"

        ElseIf QueryType = "E" Then  '��XExcel���

            sqlstr = "SELECT M.SYST_NO, S.SYST_NAME, M.PROJ_NO, S.PROJ_NAME, M.CLASS_NO, M.CLASS_NAME, D.KIND_NO, D.KIND_NAME " & _
                     "  FROM FWEB_BASE_CODE_M M, " & _
                     "       FWEB_BASE_CODE_D D, " & _
                     "       (SELECT DISTINCT SYST_NO, SYST_NAME, PROJ_NO, PROJ_NAME FROM FWEB_SYSTEM) S " & _
                     " WHERE M.SYST_NO LIKE NVL('" + txtSystNo.Text + "','%') " & _
                     "   AND M.PROJ_NO LIKE NVL('" + txtProjNo.Text + "','%') " & _
                     "   AND M.CLASS_NO LIKE NVL('" + txtClassNo.Text + "','%')  " & _
                     "   AND M.SYST_NO = D.SYST_NO(+) " & _
                     "   AND M.PROJ_NO = D.PROJ_NO(+) " & _
                     "   AND M.CLASS_NO = D.CLASS_NO(+) " & _
                     "   AND M.SYST_NO = S.SYST_NO(+) " & _
                     "   AND M.PROJ_NO = S.PROJ_NO(+) " & _
                     " ORDER BY M.SYST_NO, M.PROJ_NO, M.CLASS_NO, D.KIND_NO "

        End If

        Return sqlstr
    End Function

#Region "Master�B�z"

    'Master DBGrid-���
    Private Sub dgMaster_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgMaster.ItemCommand
        If e.CommandName.ToUpper = "SELECT" Then  'Master DBGrid-�����,�a�X���Ӹ��
            SetDisplay("D", True)
            txtSystNoD.Text = e.Item.Cells(3).Text
            txtProjNoD.Text = e.Item.Cells(5).Text
            txtClassNoD.Text = e.Item.Cells(7).Text
            QueryData("D")
        End If
    End Sub

    'Master-�s�W
    Private Sub btnAddMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddMaster.Click
        Dim sqlstr As String
        If CheckData("M") = True Then
            sqlstr = "INSERT INTO FWEB_BASE_CODE_M " & _
                     "      (SYST_NO, PROJ_NO, CLASS_NO, CLASS_NAME, CDATE, CUSER) " & _
                     "VALUES('" + txtSystNoM.Text + "'," & _
                     "       '" + txtProjNoM.Text + "'," & _
                     "       '" + txtClassNoM.Text + "'," & _
                     "       '" + txtClassNameM.Text + "'," & _
                     "       SYSDATE, '" + Context.User.Identity.Name + "') "
            Try
                db.ExecuteSQL(sqlstr)
            Catch ex As Exception
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�s�W��ƥ��ѡI');</script>")
                End Try

                dgMaster.EditItemIndex = -1
                Me.BindData("M")
                txtProjNoM.Text = ""
                ddlProjNameM.SelectedValue = ""
                txtClassNoM.Text = ""
                txtClassNameM.Text = ""
            End If
        End Sub

        'Master DBGrid-�ק�
        Private Sub dgMaster_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgMaster.EditCommand
            dgMaster.EditItemIndex = e.Item.ItemIndex
            dgMaster.SelectedIndex = e.Item.ItemIndex
            txtSystNoD.Text = e.Item.Cells(3).Text
            txtProjNoD.Text = e.Item.Cells(5).Text
            txtClassNoD.Text = e.Item.Cells(7).Text
            Me.BindData("M")
            Me.BindData("D")
        End Sub

        'Master DBGrid-��s
        Private Sub dgMaster_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgMaster.UpdateCommand
            Dim sqlstr As String

            sqlstr = "UPDATE FWEB_BASE_CODE_M " & _
                     "   SET CLASS_NAME = '" + CType(e.Item.Cells(8).Controls(0), TextBox).Text + "', " & _
                     "       MDATE = SYSDATE, " & _
                     "       MUSER = '" + Context.User.Identity.Name + "'" & _
                     " WHERE SYST_NO = '" + e.Item.Cells(3).Text + "'" & _
                     "   AND PROJ_NO = '" + e.Item.Cells(5).Text + "'" & _
                     "   AND CLASS_NO = '" + e.Item.Cells(7).Text + "'"

            Try
                db.ExecuteSQL(sqlstr)
            Catch ex As Exception
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ק��ƥ��ѡI');</script>")
            End Try

            dgMaster.EditItemIndex = -1
            Me.BindData("M")
        End Sub

        'Master DBGrid-����
        Private Sub dgMaster_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgMaster.CancelCommand
            dgMaster.EditItemIndex = -1
            dgMaster.SelectedIndex = -1
            txtSystNoD.Text = ""
            txtProjNoD.Text = ""
            txtClassNoD.Text = ""
            Me.BindData("M")
            Me.BindData("D")
        End Sub

        'Master DBGrid-�R��
        Private Sub dgMaster_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgMaster.DeleteCommand
            Dim sqlCheck, sqlDelete As String

            sqlCheck = "SELECT COUNT(*) AS COUNT FROM FWEB_BASE_CODE_D D " & _
                       " WHERE D.SYST_NO = '" + e.Item.Cells(3).Text + "'" & _
                       "   AND D.PROJ_NO = '" + e.Item.Cells(5).Text + "'" & _
                       "   AND D.CLASS_NO = '" + e.Item.Cells(7).Text + "'"

            sqlDelete = "DELETE FROM FWEB_BASE_CODE_M " & _
                        " WHERE SYST_NO = '" + e.Item.Cells(3).Text + "'" & _
                        "   AND PROJ_NO = '" + e.Item.Cells(5).Text + "'" & _
                        "   AND CLASS_NO = '" + e.Item.Cells(7).Text + "'"

            Dim ds As New DataSet
            ds = db.FillDataSet(sqlCheck)
            If ds.Tables(0).Rows(0).Item("COUNT") <> 0 Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�����Ӹ�ơA�L�k�R���I');</script>")
            Else
                Try
                    db.ExecuteSQL(sqlDelete)
                Catch ex As Exception
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�R����ƥ��ѡI');</script>")
                End Try
            End If

            dgMaster.EditItemIndex = -1
            dgMaster.SelectedIndex = -1
            txtSystNoD.Text = ""
            txtProjNoD.Text = ""
            txtClassNoD.Text = ""
            QueryData("M")
            QueryData("D")
        End Sub

        Private Sub dgMaster_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgMaster.ItemDataBound
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
                CType(e.Item.Cells(2).FindControl("lbtMasterDelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
            End If
            e.Item.Attributes.Add("onmouseover", "tdOver(this)")
            e.Item.Attributes.Add("onmouseout", "tdOut(this)")
        End Sub

        'Master DBGrid-����
        Private Sub dgMaster_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgMaster.PageIndexChanged
            dgMaster.CurrentPageIndex = e.NewPageIndex
            dgMaster.SelectedIndex = -1
            txtSystNoD.Text = ""
            txtProjNoD.Text = ""
            txtClassNoD.Text = ""
            Me.BindData("M")
            Me.BindData("D")
        End Sub

#End Region

#Region "Detail�B�z"

        'Detail-�s�W
        Private Sub btnAddDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddDetail.Click
            Dim sqlstr As String
            If CheckData("D") = True Then
                sqlstr = "INSERT INTO FWEB_BASE_CODE_D " & _
                            "      (SYST_NO, PROJ_NO, CLASS_NO, KIND_NO, KIND_NAME, CDATE, CUSER) " & _
                            "VALUES('" + txtSystNoD.Text + "'," & _
                            "       '" + txtProjNoD.Text + "'," & _
                            "       '" + txtClassNoD.Text + "'," & _
                            "       '" + txtKindNoD.Text + "'," & _
                            "       '" + txtKindNameD.Text + "'," & _
                            "       SYSDATE, '" + Context.User.Identity.Name + "') "
                Try
                    db.ExecuteSQL(sqlstr)
                Catch ex As Exception
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�s�W��ƥ��ѡI');</script>")
                End Try

                dgMaster.EditItemIndex = -1
                Me.BindData("D")
                txtKindNoD.Text = ""
                txtKindNameD.Text = ""
            End If
        End Sub

        'Detail DBGrid-�ק�
        Private Sub dgDetail_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgDetail.EditCommand
            dgDetail.EditItemIndex = e.Item.ItemIndex
            Me.BindData("D")
        End Sub

        'Detail DBGrid-��s
        Private Sub dgDetail_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgDetail.UpdateCommand
            Dim sqlstr As String

            sqlstr = "UPDATE FWEB_BASE_CODE_D " & _
                     "   SET KIND_NAME = '" + CType(e.Item.Cells(6).Controls(0), TextBox).Text + "', " & _
                     "       MDATE = SYSDATE, " & _
                     "       MUSER = '" + Context.User.Identity.Name + "'" & _
                     " WHERE SYST_NO = '" + txtSystNoD.Text + "'" & _
                     "   AND PROJ_NO = '" + txtProjNoD.Text + "'" & _
                     "   AND CLASS_NO = '" + txtClassNoD.Text + "'" & _
                     "   AND KIND_NO = '" + e.Item.Cells(5).Text + "'"

            Try
                db.ExecuteSQL(sqlstr)
            Catch ex As Exception
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ק��ƥ��ѡI');</script>")
            End Try

            dgDetail.EditItemIndex = -1
            Me.BindData("D")
        End Sub

        'Detail DBGrid-����
        Private Sub dgDetail_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgDetail.CancelCommand
            dgDetail.EditItemIndex = -1
            Me.BindData("D")
        End Sub

        'Detail DBGrid-�R��
        Private Sub dgDetail_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgDetail.DeleteCommand
            Dim sqlstr As String

            sqlstr = "DELETE FROM FWEB_BASE_CODE_D " & _
                     " WHERE SYST_NO = '" + txtSystNoD.Text + "'" & _
                     "   AND PROJ_NO = '" + txtProjNoD.Text + "'" & _
                     "   AND CLASS_NO = '" + txtClassNoD.Text + "'" & _
                     "   AND KIND_NO = '" + e.Item.Cells(5).Text + "'"

            Try
                db.ExecuteSQL(sqlstr)
            Catch ex As Exception
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�R����ƥ��ѡI');</script>")
            End Try

            dgDetail.EditItemIndex = -1
            QueryData("D")
        End Sub

        Private Sub dgDetail_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgDetail.ItemDataBound
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
                CType(e.Item.Cells(1).FindControl("lbtDetailDelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
            End If
            e.Item.Attributes.Add("onmouseover", "tdOver(this)")
            e.Item.Attributes.Add("onmouseout", "tdOut(this)")
        End Sub

        'Detail DBGrid-����
        Private Sub dgDetail_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgDetail.PageIndexChanged
            dgDetail.CurrentPageIndex = e.NewPageIndex
            BindData("D")
        End Sub

#End Region

#Region "CheckData:�ˬd���"
        Function CheckData(ByVal QueryType As String) As Boolean
            Dim sqlstr As String

            If QueryType = "M" Then  '�ˬdMaster���

                '���ର�ŭ�
                If txtSystNoM.Text = "" Or txtProjNoM.Text = "" Or txtClassNoM.Text = "" Or txtClassNameM.Text = "" Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��줣�ର�ŭȡA�Э��s��J!');</script>")
                    Return False
                End If

                '�t�άO�_�s�b
                If txtSystNoM.Text <> "" Then
                    sqlstr = "SELECT COUNT(*) FROM FWEB_SYSTEM S WHERE S.SYST_NO = '" + txtSystNoM.Text + "'"
                    If db.GetExecuteScalar(sqlstr) = 0 Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�L���t�ΡA�Э��s��J!');</script>")
                        Return False
                    End If
                End If

                '�M�׬O�_�s�b
                If txtProjNoM.Text <> "" Then
                    sqlstr = "SELECT COUNT(*) FROM FWEB_SYSTEM S " & _
                             " WHERE S.SYST_NO = '" + txtSystNoM.Text + "'" & _
                             "   AND S.PROJ_NO = '" + txtProjNoM.Text + "'"
                    If db.GetExecuteScalar(sqlstr) = 0 Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�L���M�סA�Э��s��J!');</script>")
                        Return False
                    End If
                End If

                '�N��-�j���O�_�w�s�b
                If txtClassNoM.Text <> "" Then
                    sqlstr = "SELECT COUNT(*) FROM FWEB_BASE_CODE_M M " & _
                             " WHERE M.SYST_NO = '" + txtSystNoM.Text + "'" & _
                             "   AND M.PROJ_NO = '" + txtProjNoM.Text + "'" & _
                             "   AND M.CLASS_NO = '" + txtClassNoM.Text + "'"
                    If db.GetExecuteScalar(sqlstr) <> 0 Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��Ƥw�s�b�A�L�k�s�W!');</script>")
                        Return False
                    End If
                End If

            ElseIf QueryType = "D" Then  '�ˬdDetail���

                '���ର�ŭ�
                If txtSystNoD.Text = "" Or txtProjNoD.Text = "" Or txtClassNoD.Text = "" Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Х����Master���!');</script>")
                    Return False
                End If

                '�N�����ର�ŭ�
                If txtKindNoD.Text = "" And txtKindNameD.Text = "" Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��줣�ର�ŭȡA�Э��s��J!');</script>")
                    Return False
                End If

                '�N���O�_�w�s�b
                If txtKindNoD.Text <> "" Then
                    sqlstr = "SELECT COUNT(*) FROM FWEB_BASE_CODE_D D " & _
                             " WHERE D.SYST_NO = '" + txtSystNoD.Text + "'" & _
                             "   AND D.PROJ_NO = '" + txtProjNoD.Text + "'" & _
                             "   AND D.CLASS_NO = '" + txtClassNoD.Text + "'" & _
                             "   AND D.KIND_NO = '" + txtKindNoD.Text + "'"
                    If db.GetExecuteScalar(sqlstr) <> 0 Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��Ƥw�s�b�A�L�k�s�W!');</script>")
                        Return False
                    End If
                End If

            End If

            Return True
        End Function
#End Region

#Region "��EXCEL"
    '��EXCEL
    Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
        Dim csExcel As New CSPrintExcel
        Dim filename As String = "LOGIN_BASE_CODE_EXCEL" + Now.ToString("yyyyMMddHHmmss") + ".xls"
        Dim savepath As String = PublicM.GetSessionDataRoot(context) + filename  'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(context) + filename 'JavaScript�}��xls���|,�n�Psavepath�P        
        Try
            Dim ds As New DataSet
            Dim strsql As String
            strsql = QueryString("E")
            ds = db.FillDataSet(strsql)
            csExcel.CreateExcel()
            csExcel.SetDisplayColName("�t��", "�t�ΦW��", "�M��", "�M�צW��", "�N��-�j��", "�N��-�j���W��", "�N��", "�N���W��")
            csExcel.SetDisplayCol("SYST_NO", "SYST_NAME", "PROJ_NO", "PROJ_NAME", "CLASS_NO", "CLASS_NAME", "KIND_NO", "KIND_NAME")
            csExcel.SetDisplayColType(0, 0, 0, 0, 0, 0, 0, 0)
            csExcel.PutExcelData(ds.Tables(0), 1, 1, True, True)
            csExcel.SaveExcel(savepath)
        Catch ex As Exception
            Throw ex
        Finally
            csExcel.ReleaseExcel()
        End Try
        Response.Write("<script>window.open(' " + JSsavepath + " ')</script>")
    End Sub
#End Region

End Class

End Namespace

