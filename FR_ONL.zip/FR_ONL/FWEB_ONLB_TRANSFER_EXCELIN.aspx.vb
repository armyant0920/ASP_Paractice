Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Data
Imports System.Data.OleDb
Imports System.Math
Imports System.Text


Namespace FR


Partial Class FWEB_ONLB_TRANSFER_EXCELIN
    Inherits System.Web.UI.Page

    Dim oExcel As Excel.Application
    Dim oBooks As Excel.Workbooks
    Dim oBook As Excel.Workbook
    Dim oSheets As Excel.Sheets
    Dim oSheet As Excel.Worksheet
    Dim oCells As Excel.Range
    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            btnTranIn.Attributes.Add("onclick", "return loading();")
        End If
    End Sub

    '����
    Private Sub btnEnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnd.Click
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "close", "<script language='JavaScript'>window.close('FWEB_ONLB_TRANSFER_EXCELIN.aspx') </script>")
        End Sub

        'Excel��J
        Private Sub btnTranIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTranIn.Click


            Dim UpFileName As String = ""
            Dim vResult As Boolean
            If Me.File1.Value = "" Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert1", "<script defer>alert('�п����JExcel�ɮ�');</script>")
                Exit Sub
            ElseIf File1.PostedFile.FileName.Substring(File1.PostedFile.FileName.LastIndexOf(".")).ToLower() <> ".xls" Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert2", "<script defer>alert('�п��Excel�ɮ�');</script>")
                Exit Sub
            Else
                Dim vFileName As String = File1.PostedFile.FileName
                UpFileName = vFileName.Substring(vFileName.LastIndexOf("\") + 1)
                File1.PostedFile.SaveAs(PublicM.GetSessionDataRoot_Bond(context) + UpFileName)
                vResult = ExcelIn(UpFileName) '�NExcel�����JDatabase

                If vResult = True Then
                    '�ˬd�O�_�����`
                    Dim SQLError As String

                    SQLError = "SELECT COUNT(*) FROM FWEB_ONLB_TRANSFER_ERROR WHERE FUNC_NO ='ONLB_TRANSFER' AND MUSER = '" + context.User.Identity.Name + "'"
                    If db.GetExecuteScalar(SQLError) = 0 Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�W�Ǧ��\!');</script>")
                    Else
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��J�����`�A�Ьd�ݲ��`����!');</script>")
                    End If
                Else
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('��J�o�Ͳ��`.')</script>")
                End If
            End If
        End Sub

    '�NExcel�����JDatabase
    Function ExcelIn(ByVal UpFileName As String) As Boolean
        Dim starttime As DateTime = DateTime.Now
        oExcel = New Excel.Application
        Dim endtime As DateTime = DateTime.Now
        Dim sTemplate As String = PublicM.GetSessionDataRoot_Bond(context) + UpFileName
        Dim vResult As Boolean = True

        '�M�����
        Dim strB As New StringBuilder
        strB.Append("DECLARE P_USER_ID VARCHAR2(10);")
        strB.Append("BEGIN")
        strB.Append(" P_USER_ID:='" + Context.User.Identity.Name + "';")
        '�MFWEB_ONLB_TRANSFER_ERROR
        strB.Append(" DELETE FROM FWEB_ONLB_TRANSFER_ERROR WHERE FUNC_NO ='ONLB_TRANSFER' AND MUSER = P_USER_ID ;")
        strB.Append("END;")
        db.ExecuteSQL(strB.ToString)

        '��J���
        Try
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

                Dim row As Integer
            Dim intR As Integer = oSheet.UsedRange.Rows.Count
            Dim intC As Integer = oSheet.UsedRange.Columns.Count
            Dim P_PERIOD_NAME, P_ORG, P_TRANSACTION_TYPE, P_COST_CENTER, P_PRODUCT_NUM, P_PRODUCT_DESC, P_UOM, P_PRE_ONHAND, P_NOW_WASTE, P_NOW_ONHAND, P_BONDED_NOW_ONHAND As String

            row = 2
            Do While row <= intR And vResult = True

                P_PERIOD_NAME = IIf(oCells(row, 1).Value Is DBNull.Value, "", oCells(row, 1).Value)
                P_ORG = IIf(oCells(row, 2).Value Is DBNull.Value, "", oCells(row, 2).Value)
                P_TRANSACTION_TYPE = IIf(oCells(row, 3).Value Is DBNull.Value, "", oCells(row, 3).Value)
                P_COST_CENTER = IIf(oCells(row, 4).Value Is DBNull.Value, "", oCells(row, 4).Value)
                P_PRODUCT_NUM = IIf(oCells(row, 7).Value Is DBNull.Value, "", oCells(row, 7).Value)
                P_PRODUCT_DESC = IIf(oCells(row, 8).Value Is DBNull.Value, "", oCells(row, 8).Value)
                P_UOM = IIf(oCells(row, 9).Value Is DBNull.Value, "", oCells(row, 9).Value)
                P_PRE_ONHAND = PublicM.trimStr(oCells(row, 10).Value)
                P_NOW_WASTE = PublicM.trimStr(oCells(row, 11).Value)
                P_NOW_ONHAND = PublicM.trimStr(oCells(row, 12).Value)
                P_BONDED_NOW_ONHAND = 0 'PublicM.trimStr(oCells(row, 13).Value)
                    '����StoreProcedure
                    
                If P_PERIOD_NAME <> "" And P_ORG <> "" And P_COST_CENTER <> "" And P_PRODUCT_NUM <> "" And P_PRODUCT_DESC <> "" And P_UOM <> "" Then
                    vResult = ExecSP(P_PERIOD_NAME, P_ORG, P_TRANSACTION_TYPE, P_COST_CENTER, P_PRODUCT_NUM, P_PRODUCT_DESC, P_UOM, P_PRE_ONHAND, P_NOW_WASTE, P_NOW_ONHAND, P_BONDED_NOW_ONHAND)
                End If

                row = row + 1
            Loop

            '   oBook.Close()
            Catch ex As Exception
                'Response.Write(ex.Message)
                'Response.End()
                'Alert(ex.Message, Me)
                vResult = False
                Throw ex
        Finally
            ReleaseExcel()
            PublicM.KillProcess("EXCEL", starttime, endtime)
        End Try

        Return vResult
    End Function

    '����StoreProcedure
    Function ExecSP(ByVal P_PERIOD_NAME As String, ByVal P_ORG As String, ByVal P_TRANSACTION_TYPE As String, ByVal P_COST_CENTER As String, ByVal P_PRODUCT_NUM As String, ByVal P_PRODUCT_DESC As String, ByVal P_UOM As String, ByVal P_PRE_ONHAND As String, ByVal P_NOW_WASTE As String, ByVal P_NOW_ONHAND As String, ByVal P_BONDED_NOW_ONHAND As String) As Boolean
        Dim cmd As New OleDbCommand
        Dim vResult As Boolean = True

            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_ONLB_TRANSFER_SP"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn

                    cmd.Parameters.Add(New OleDbParameter("P_FUNC_NO", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_PERIOD_NAME", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_ORG", OleDbType.VarChar, 3))
                    cmd.Parameters.Add(New OleDbParameter("P_TRANSACTION_TYPE", OleDbType.VarChar, 6))
                    cmd.Parameters.Add(New OleDbParameter("P_COST_CENTER", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_PRODUCT_NUM", OleDbType.VarChar, 40))
                    cmd.Parameters.Add(New OleDbParameter("P_PRODUCT_DESC", OleDbType.VarChar, 240))
                    cmd.Parameters.Add(New OleDbParameter("P_UOM", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_PRE_ONHAND", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_NOW_WASTE", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_NOW_ONHAND", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_BONDED_NOW_ONHAND", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_REMARK", OleDbType.VarChar, 200))
                    cmd.Parameters.Add(New OleDbParameter("P_MDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_MUSER", OleDbType.VarChar, 10))

                    cmd.Parameters("P_FUNC_NO").Value = "ONLB_TRANSFER"
                    cmd.Parameters("P_PERIOD_NAME").Value = P_PERIOD_NAME
                    cmd.Parameters("P_ORG").Value = P_ORG
                    cmd.Parameters("P_TRANSACTION_TYPE").Value = P_TRANSACTION_TYPE
                    cmd.Parameters("P_COST_CENTER").Value = P_COST_CENTER
                    cmd.Parameters("P_PRODUCT_NUM").Value = P_PRODUCT_NUM
                    cmd.Parameters("P_PRODUCT_DESC").Value = P_PRODUCT_DESC
                    cmd.Parameters("P_UOM").Value = P_UOM
                    cmd.Parameters("P_PRE_ONHAND").Value = IIf(P_PRE_ONHAND = "", 0, P_PRE_ONHAND)
                    cmd.Parameters("P_NOW_WASTE").Value = IIf(P_NOW_WASTE = "", 0, P_NOW_WASTE)
                    cmd.Parameters("P_NOW_ONHAND").Value = IIf(P_NOW_ONHAND = "", 0, P_NOW_ONHAND)
                    cmd.Parameters("P_BONDED_NOW_ONHAND").Value = IIf(P_BONDED_NOW_ONHAND = "", 0, P_BONDED_NOW_ONHAND)
                    cmd.Parameters("P_REMARK").Value = ""
                    cmd.Parameters("P_MDATE").Value = Now
                    cmd.Parameters("P_MUSER").Value = Context.User.Identity.Name

                    cmd.ExecuteNonQuery()
                    vResult = True

                Catch ex As Exception
                    'Response.Write(ex.Message)
                    'Response.End()
                    vResult = False
                    Response.Write("<script>alert('" & ex.Message.Replace("'", "-") & "')</script>")
                Finally
                    cn.Close()
                End Try
            End If

        Return vResult
    End Function

#Region "ReleaseExcel:����Excel�귽"
    Sub ReleaseExcel()
        Try
            oExcel.Quit()
            ReleaseExcelObject(oCells)
            ReleaseExcelObject(oSheet)
            ReleaseExcelObject(oSheets)
            ReleaseExcelObject(oBook)
            ReleaseExcelObject(oBooks)
            ReleaseExcelObject(oExcel)
        Catch ex As Exception
            Throw ex
        Finally
            GC.Collect()
        End Try
    End Sub
#End Region

#Region "ReleaseExcelObject: ������XExcel�Ψ쪺����"
    Sub ReleaseExcelObject(ByVal o As Object)
        Try
            If Not o Is Nothing Then
                Marshal.ReleaseComObject(o)
            End If
        Finally
            o = Nothing
        End Try
    End Sub
#End Region

End Class

End Namespace
