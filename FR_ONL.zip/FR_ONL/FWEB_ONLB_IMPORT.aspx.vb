Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math


Namespace FR

Partial Class FWEB_ONLB_IMPORT
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txt_org_no.Value <> "" Then
            loadcost_name()
            Me.dd_cost_name.Value = Me.txt_cost_no.Value
        End If
        If Not Page.IsPostBack Then
            sysdate()
            loadorg_name()
            Me.dd_org_name.Value = Me.txt_org_no.Value
            loadcost_name()
            listyd()
            btn_state(0)
            Button1.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_PROD_2.aspx?type=a", 640, 480))
            Btnout.Attributes.Add("onclick", "javascript:if (confirm('�T�w�N�U�C�Ҧ���ƥ����ߪ���?')) {return true;} else {return false;};")
        End If
    End Sub

    Sub loadorg_name()
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONLB_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = B.ORG AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                 " AND C.PROJ_NO = 'ONLB' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
        dd_org_name.DataSource = db.FillDataSet(sqlstr)
        dd_org_name.DataValueField = "�s�X"
        dd_org_name.DataTextField = "�W��"
        dd_org_name.DataBind()
        dd_org_name.Items.Insert(0, "")
    End Sub
    Sub loadcost_name()
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.COST_CENTER �s�X, B.COST_CENTER_NAME �W�� FROM FWEB_ONLB_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = '" + txt_org_no.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                 " AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONLB' " & _
                 " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) " & _
                 " ORDER BY A.COST_CENTER "
        dd_cost_name.DataSource = db.FillDataSet(sqlstr).Tables(0)
        dd_cost_name.DataValueField = "�s�X"
        dd_cost_name.DataTextField = "�W��"
        dd_cost_name.DataBind()
        dd_cost_name.Items.Insert(0, "")
    End Sub

    Sub listyd()
        Dim sqlstr As String
        sqlstr = "SELECT DISTINCT TRANSACTION_TYPE �������O FROM FWEB_ONL_TRANSACTION_TYPE"
        dd_list_yd.DataSource = db.FillDataSet(sqlstr).Tables(0)
        dd_list_yd.DataTextField = "�������O"
        dd_list_yd.DataBind()
        dd_list_yd.Items.Insert(0, "")
    End Sub

    Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
        If check_data() = False Then
            Exit Sub
        End If

        Dim strsql As String
        Dim class1 As String = " SELECT TO_CHAR(T.PERIOD_NAME,'yyyy/mm/dd') PERIOD_NAME, T.ORG, T.TRANSACTION_TYPE, T.COST_CENTER, M.COST_CENTER_NAME, T.BONDED_FLAG, T.PRODUCT_NUM, T.PRODUCT_DESC, T.UOM, T.PRE_ONHAND, T.NOW_WASTE, T.NOW_ONHAND, T.BONDED_NOW_ONHAND, " & _
                               " T.CHECK_ONHAND, T.REMARK, T.IMPORT_MARK, TO_CHAR(T.IMPORT_DATE,'yyyy/mm/dd') AS IMPORT_DATE, T.IMPORT_USER, T.APPROVE_MARK, " & _
                               " TO_CHAR(T.APPROVE_DATE,'yyyy/mm/dd') AS APPROVE_DATE, T.APPROVE_USER, TO_CHAR(T.MDATE,'yyyy/mm/dd') AS MDATE, T.MUSER, TO_CHAR(T.CDATE,'yyyy/mm/dd') AS CDATE, T.CUSER " & _
                               " FROM FWEB_ONLB_ONHAND T, FWEB_COST_CENTER_V M "
        Dim class2 As String = " WHERE T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER AND T.PERIOD_NAME=TO_DATE('" + edtDateFrom.Value.Trim + "','yyyy/MM/dd') AND T.ORG= '" + txt_org_no.Value.Trim + "'  AND T.COST_CENTER LIKE '%" + txt_cost_no.Value.Trim + "%'" & _
                               " AND T.PRODUCT_NUM LIKE '%" + Text1.Value.Trim + "%' AND (T.IMPORT_MARK<>'Y'OR T.IMPORT_MARK IS NULL) " 'AND T.TRANSACTION_TYPE LIKE '%" + dd_list_yd.SelectedValue.Trim + "%'
        viewstate("class2") = class2
        If dd_select_on.SelectedItem.Text = "Y" Then
            strsql = class1 & class2 & " AND T.CHECK_ONHAND<0"
        ElseIf dd_select_on.SelectedItem.Text = "N" Then
            strsql = class1 & class2 & " AND T.CHECK_ONHAND >=0 "
        Else
            dd_select_on.SelectedItem.Text = ""
            strsql = class1 & class2
        End If
        viewstate("strsql") = strsql
        Me.dg.CurrentPageIndex = 0
        loaddata(viewstate("strsql"))
        btn_state(1)
    End Sub
        Sub btn_state(ByVal intnum As Int16)
            If intnum = 0 Then
                btnInq.Enabled = True
                Btnout.Enabled = False
                btn_tran_EXCEL.Enabled = False
            ElseIf intnum = 1 Then
                Btnout.Enabled = True
                btn_tran_EXCEL.Enabled = True
            ElseIf intnum = 2 Then
                btnInq.Enabled = True
                Btnout.Enabled = False
                btn_tran_EXCEL.Enabled = False
            End If
        End Sub


        Sub loaddata(ByVal strsql As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            Try
               ds = db.FillDataSet(strsql)
               dv = ds.Tables(0).DefaultView
               dg.DataSource = dv
               dg.DataBind()
               GetPageInfo()
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
        End Sub

    Sub GetPageInfo()
        Dim strsql As String
        strsql = " select count(*) from  FWEB_ONLB_ONHAND T,FWEB_COST_CENTER_V M " & viewstate("class2")
        Dim strsql1 As String = db.GetExecuteScalar(strsql).ToString
        Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
    End Sub

    Function check_data() As Boolean
        Dim inti As Int16 = 0
        If txt_org_no.Value = "" Then
            inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
                Return False
            End If
            If txt_org_no.Value <> "" Then
                'CHECK�O�_���u�W���s�L�I���t�O
                Dim strsql1 As String = "SELECT COUNT(*) FROM FWEB_ONLB_DEPT WHERE ORG='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���t�O�D�u�W���s�L�I���t�O�A��CHECK! �Y���s�W���L�I���t�O�A�гq���]�ȼW�[!');</script>")
                End If
                'CHECK�O�_���t�O�v��
                Dim strsql2 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                        "AND PROJ_NO = 'ONLB' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���]�ȼW�[!');</script>")
                End If

                If txt_cost_no.Value <> "" Then
                    'CHECK�O�_���u�W���s�L�I����������
                    Dim strsql3 As String = "SELECT COUNT(*) FROM FWEB_ONLB_DEPT WHERE ORG ='" + txt_org_no.Value.Trim + "' AND COST_CENTER = '" + txt_cost_no.Value.Trim + "'"
                    If db.GetExecuteScalar(strsql3) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                    End If
                    'CHECK�O�_�����������v��
                    Dim strsql4 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                            "AND PROJ_NO = 'ONLB' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "' " & _
                                            "AND DECODE(COST_CENTER,'ALL','" + txt_cost_no.Value.Trim + "',COST_CENTER)='" + txt_cost_no.Value.Trim + "' "
                    If db.GetExecuteScalar(strsql4) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                    End If
                End If
            End If
            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function
        Sub sysdate()
            Dim sqlstr As String
            sqlstr = "SELECT A.ORG,A.PERIOD_MOTH FROM FWEB_ONLB_CALENDAR A,(SELECT T.ORG FROM FWEB_USER_ORGAU_D O, FWEB_ONLB_DEPT T" & _
                 " WHERE O.USER_ID = '" + context.User.Identity.Name + "' AND O.SYST_NO = 'FWEB' AND O.PROJ_NO = 'ONLB' AND DECODE(O.ORG, 'ALL', T.ORG, O.ORG) = T.ORG " & _
                 " AND DECODE(O.COST_CENTER, 'ALL', T.COST_CENTER, O.COST_CENTER) = T.COST_CENTER AND ROWNUM = 1) B" & _
                 " WHERE A.ORG = B.ORG AND A.CLOSE_DATE IS NULL"
            Dim ds As New DataSet
            ds = db.FillDataSet(sqlstr)
            If ds.Tables(0).Rows.Count <> 0 Then
                txt_org_no.Value = ds.Tables(0).Rows(0).Item("ORG")
                edtDateFrom.Value = ds.Tables(0).Rows(0).Item("PERIOD_MOTH")
            End If
        End Sub

        Private Sub Btnout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnout.Click
            Dim strsql As String
            Dim strsql2 As String
            Try
                strsql = " update FWEB_ONLB_ONHAND T set IMPORT_DATE=sysdate,IMPORT_MARK='Y', IMPORT_USER='" + context.User.Identity.Name + "'" & _
                 " where t.PERIOD_NAME=to_date('" + edtDateFrom.Value.Trim + "','yyyy/MM/dd') and T.ORG= '" + txt_org_no.Value.Trim + "'  and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'" & _
                 " and T.PRODUCT_NUM like '%" + Text1.Value.Trim + "%' and (t.IMPORT_MARK<>'Y'or t.IMPORT_MARK is null) " 'and  t.TRANSACTION_TYPE like '%" + dd_list_yd.SelectedValue.Trim + "%'
                viewstate("strsql3") = strsql
                If dd_select_on.SelectedItem.Text = "Y" Then
                    strsql2 = viewstate("strsql3") & " and CHECK_ONHAND<0 "
                ElseIf dd_select_on.SelectedItem.Text = "N" Then
                    strsql2 = viewstate("strsql3") & " and CHECK_ONHAND>=0 "
                Else
                    dd_select_on.SelectedItem.Text = ""
                    strsql2 = viewstate("strsql3")
                End If
                db.ExecuteSQL(strsql2)
            Catch ex As Exception
                Throw ex
            End Try
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ߪ��ަ��\!');</script>")
            dg.CurrentPageIndex = 0
            loaddata(viewstate("strsql"))
            btn_state(0)
        End Sub

        Private Sub btn_tran_EXCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_tran_EXCEL.Click
            Response.Write("<script>window.open(' " + EXPORT_EXCEL() + " ')</script>")
        End Sub

        Function EXPORT_EXCEL() As String       '(ByVal source, ByVal e)
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim sTemplate As String = Server.MapPath("~") & "\ONLB_Template\ONLB_IMPORT_EXCEL.xls"
            Dim savepath As String = PublicM.GetSessionDataRoot_Bond(context) + "ONLB_IMPORT_EXCEL.xls" 'xls�s����|,�n�PJSsavepath�P
            Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot_Bond(context) + "ONLB_IMPORT_EXCEL.xls" 'JavaScript�}��xls���|,�n�Psavepath�P


            Try
                '�w�q�@�ӷs���u�@ï
                oBooks = oExcel.Workbooks
                oBooks.Open(sTemplate)
                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                '��R���
                Dim ds As DataSet
                ds = db.FillDataSet(viewstate("strsql"))

                Dim y As Integer
                Dim i As Integer = ds.Tables(0).Rows.Count
                Dim j As Int16 = 0
                For y = 0 To ds.Tables(0).Columns.Count - 1
                    Select Case ds.Tables(0).Columns(y).ColumnName
                        Case "PERIOD_NAME"
                            j = 0
                            For i = 0 To i - 1
                                If Not IsDBNull(ds.Tables(0).Rows(i).Item("PERIOD_NAME")) Then
                                    oCells(j + 2, 1) = ds.Tables(0).Rows(i).Item("PERIOD_NAME").ToString.Substring(0, 10)
                                Else
                                    oCells(j + 2, 1) = ""
                                End If
                                j = j + 1
                            Next
                        Case "ORG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 2) = ds.Tables(0).Rows(i).Item("ORG").ToString
                                j = j + 1
                            Next
                        Case "TRANSACTION_TYPE"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 3) = ds.Tables(0).Rows(i).Item("TRANSACTION_TYPE").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 4) = ds.Tables(0).Rows(i).Item("COST_CENTER").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER_NAME"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 5) = ds.Tables(0).Rows(i).Item("COST_CENTER_NAME").ToString
                                j = j + 1
                            Next
                        Case "BONDED_FLAG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 6) = ds.Tables(0).Rows(i).Item("BONDED_FLAG").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 7) = ds.Tables(0).Rows(i).Item("PRODUCT_NUM").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_DESC"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 8) = ds.Tables(0).Rows(i).Item("PRODUCT_DESC").ToString
                                j = j + 1
                            Next
                        Case "UOM"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 9) = ds.Tables(0).Rows(i).Item("UOM").ToString
                                j = j + 1
                            Next
                        Case "PRE_ONHAND"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 10) = ds.Tables(0).Rows(i).Item("PRE_ONHAND").ToString
                                j = j + 1
                            Next
                        Case "NOW_WASTE"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 11) = ds.Tables(0).Rows(i).Item("NOW_WASTE").ToString
                                j = j + 1
                            Next
                        Case "NOW_ONHAND"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 12) = ds.Tables(0).Rows(i).Item("NOW_ONHAND").ToString
                                j = j + 1
                            Next
                            'Case "BONDED_NOW_ONHAND"
                            '    j = 0
                            '    For i = 0 To i - 1
                            '        oCells(j + 2, 13) = ds.Tables(0).Rows(i).Item("BONDED_NOW_ONHAND").ToString
                            '        j = j + 1
                            '    Next
                        Case "CHECK_ONHAND"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 13) = ds.Tables(0).Rows(i).Item("CHECK_ONHAND").ToString
                                j = j + 1
                            Next
                        Case "REMARK"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 14) = ds.Tables(0).Rows(i).Item("REMARK").ToString
                                j = j + 1
                            Next
                        Case "IMPORT_MARK"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 15) = ds.Tables(0).Rows(i).Item("IMPORT_MARK").ToString
                                j = j + 1
                            Next
                        Case "IMPORT_DATE"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 16) = ds.Tables(0).Rows(i).Item("IMPORT_DATE").ToString
                                j = j + 1
                            Next
                        Case "IMPORT_USER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 17) = ds.Tables(0).Rows(i).Item("IMPORT_USER").ToString
                                j = j + 1
                            Next
                        Case "APPROVE_MARK"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 18) = ds.Tables(0).Rows(i).Item("APPROVE_MARK").ToString
                                j = j + 1
                            Next
                        Case "APPROVE_DATE"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 19) = ds.Tables(0).Rows(i).Item("APPROVE_DATE").ToString
                                j = j + 1
                            Next
                        Case "APPROVE_USER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 20) = "'" + ds.Tables(0).Rows(i).Item("APPROVE_USER").ToString
                                j = j + 1
                            Next
                        Case "MDATE"
                            j = 0
                            For i = 0 To i - 1
                                If Not IsDBNull(ds.Tables(0).Rows(i).Item("MDATE")) Then
                                    oCells(j + 2, 21) = "'" + ds.Tables(0).Rows(i).Item("MDATE").ToString.Substring(0, 10)
                                Else
                                    oCells(j + 2, 21) = ""
                                End If
                                j = j + 1
                            Next
                        Case "MUSER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 22) = "'" + ds.Tables(0).Rows(i).Item("MUSER").ToString
                                j = j + 1
                            Next
                        Case "CDATE"
                            j = 0
                            For i = 0 To i - 1
                                If Not IsDBNull(ds.Tables(0).Rows(i).Item("CDATE")) Then
                                    oCells(j + 2, 23) = "'" + ds.Tables(0).Rows(i).Item("CDATE").ToString.Substring(0, 10)
                                Else
                                    oCells(j + 2, 23) = ""
                                End If
                                j = j + 1
                            Next
                        Case "CUSER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 24) = "'" + ds.Tables(0).Rows(i).Item("CUSER").ToString
                                j = j + 1
                            Next
                    End Select
                Next

                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                ' oExcel.DisplayAlerts = True

                Return JSsavepath
            Catch ex As Exception
                Throw ex
            Finally
                ' oExcel.Application.Quit()
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If


                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If

                'GC.Collect()

            End Try
            '  GC.Collect()
        End Function

        Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
            dg.CurrentPageIndex = e.NewPageIndex
            loaddata(viewstate("strsql"))
        End Sub

        Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
                CType(e.Item.Cells(0).FindControl("btnpao"), LinkButton).Attributes.Add("onclick", "return confirm('�T�w�N������Ʃߪ���?');")
            End If
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
                'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
                'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
                e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
                e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
            End If
        End Sub

        Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
            If e.CommandName = "TRUNOUT" Then
                Try
                    Dim strsql4 As String
                    strsql4 = "update FWEB_ONLB_ONHAND  set IMPORT_DATE=sysdate,IMPORT_MARK='Y',IMPORT_USER='" + context.User.Identity.Name + "'" & _
                               " where PERIOD_NAME=to_date('" + e.Item.Cells(1).Text + "','yyyy/MM/dd') and ORG='" + e.Item.Cells(2).Text + "'" & _
                               " and TRANSACTION_TYPE='" + e.Item.Cells(3).Text + "' and COST_CENTER='" + e.Item.Cells(4).Text + "' and PRODUCT_NUM='" + e.Item.Cells(7).Text + "'"
                    db.ExecuteSQL(strsql4)
                Catch ex As Exception
                    Throw ex
                Finally
                    If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                        dg.CurrentPageIndex -= 1
                        loaddata(viewstate("strsql"))
                    Else
                        loaddata(viewstate("strsql"))
                    End If
                End Try
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ߪ��ަ��\!');</script>")
            End If
        End Sub
End Class
End Namespace
