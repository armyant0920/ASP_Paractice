Namespace FR

Partial Class FWEB_LOGIN_AUTHORITY
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
                'btn1.Attributes.Add("onclick", "var st=window.showModalDialog('FWEB_FIND_USER.aspx?level=a',window,'dialogTop=160px;dialogWidth=640px;dialogHeight=480px;help:no;status:no');if(st!=undefined){document.all('TXT_ORG_NO').value=st;document.getElementById('btn1').click();} else {return false;}")
                btn1.Attributes.Add("onclick", "var st=window.open('FWEB_FIND_USER.aspx?level=a',window,'Top=160px;Width=640px;Height=480px;help:no;status:no');if(st!=undefined){document.all('TXT_USER_ID').value=st;document.getElementById('btn1').click();} else {return false;}")
                'TXT_USER_ID.Attributes.Add("onblur", "if (document.all('TXT_USER_ID').value !=''){document.Form1.Button5.click();}")
                TXT_USER_ID.Attributes.Add("onchange", "if (document.all('TXT_USER_ID').value !=''){document.Form1.Button5.click();}")
            form_set()
        End If

    End Sub

    Private Sub btn1_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.ServerClick, Button5.ServerClick
        Dim strid As String
            strid = Trim(TXT_USER_ID.Text)
        If check_data(strid) = True Then
            begin()
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert", "<script refer>console.log('�L���!');</script>") '"alert", "<script refer>alert('�L���!');</script>"
                Exit Sub
            End If
            If check_set(strid) = True Then
                begin()
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert", "<script refer>alert('�ӱb�����ݳ]�m�v��!');</script>")
                Exit Sub
            End If
        lstleft.Items.Clear()
        lstright.Items.Clear()
        bind_text(strid)
        bind_lst(strid)
        BN_MOD.Enabled = True
    End Sub
        Sub form_set()
            TXT_USER_ID.Enabled = True
            TXT_USER_ID.ReadOnly = False
            BN_SAV.Enabled = False
            BN_CAN.Enabled = False
            lstleft.Enabled = False
            lstright.Enabled = False
            lsttoright.Disabled = True
            lsttoleft.Disabled = True
            Button2.Disabled = True
            Button3.Disabled = True
            BN_MOD.Enabled = True
            btn1.Disabled = False
            BN_MOD.Enabled = False
        End Sub
    Sub bind_text(ByVal strid As String)
        Dim strsql As String
        Dim ds As New DataSet
        strsql = "select user_id,user_name,password,e_mail,user_level,muser from FWEB_USER_LOGIN_M where user_id='" + strid + "' and user_level='U'"
        ds = db.FillDataSet(strsql)
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("user_id")) Then
                TXT_USER_ID.Text = ds.Tables(0).Rows(0).Item("user_id")
        Else
                TXT_USER_ID.Text = ""
        End If
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("user_name")) Then
                TXT_USER_NAME.Text = ds.Tables(0).Rows(0).Item("user_name")
        Else
                TXT_USER_NAME.Text = ""
        End If
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("password")) Then
            Text3.Value = ds.Tables(0).Rows(0).Item("password")
        Else
            Text3.Value = ""
        End If
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("e_mail")) Then
            Text1.Value = ds.Tables(0).Rows(0).Item("e_mail")
        Else
            Text1.Value = ""
        End If
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("user_level")) Then
            DropDownList1.SelectedValue = ds.Tables(0).Rows(0).Item("user_level")
        End If
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("muser")) Then
            Text2.Value = ds.Tables(0).Rows(0).Item("muser")
        Else
            Text2.Value = ""
        End If
    End Sub
    Function check_data(ByVal strid As String) As Boolean
        Dim strsql As String
        strsql = "select count(*) from FWEB_USER_LOGIN_M where user_id='" + strid + "'"
        If db.GetExecuteScalar(strsql) > 0 Then
            Return False
        Else
            Return True
        End If
    End Function
    Sub bind_lst(ByVal sttid As String)
            Dim strsql As String = ""
        strsql = "select count(*) from FWEB_USER_LOGIN_M where user_id='" + sttid + "' and user_level='U'"
        If db.GetExecuteScalar(strsql) > 0 Then
            strsql = "SELECT syst_no||'-'||proj_no||'-'||func_no,syst_name||'-'||proj_name||'-'||func_name FROM FWEB_SYSTEM S  WHERE NOT EXISTS (SELECT * FROM FWEB_USER_LOGIN_D D " & _
                    "WHERE D.USER_ID='" + sttid + "'  AND  D.SYST_NO =S.SYST_NO  AND D.PROJ_NO =S.PROJ_NO " & _
                    "AND D.FUNC_NO =S.FUNC_NO) ORDER BY S.SYST_SEQ, S.PROJ_SEQ, S.FUNC_SEQ"
            Dim ds As New DataSet
            ds = db.FillDataSet(strsql)
            lstleft.DataSource = ds.Tables(0)
            lstleft.DataTextField = ds.Tables(0).Columns(1).ColumnName
            lstleft.DataValueField = ds.Tables(0).Columns(0).ColumnName
            lstleft.DataBind()
                Dim strsql2 As String = "select b.syst_no||'-'||b.proj_no||'-'||b.func_no,b.syst_name||'-'||b.proj_name||'-'||b.func_name  " & _
                 "from FWEB_USER_LOGIN_D a,FWEB_SYSTEM b  " & _
                 "where a.syst_no=b.syst_no and a.proj_no=b.proj_no and a.func_no=b.func_no and a.USER_ID='" + sttid + "'" & _
                 " ORDER BY B.SYST_SEQ, B.PROJ_SEQ, B.FUNC_SEQ"
            Dim ds2 As New DataSet
            ds2 = db.FillDataSet(strsql2)
            lstright.DataSource = ds2.Tables(0)
            lstright.DataTextField = ds2.Tables(0).Columns(1).ColumnName
            lstright.DataValueField = ds2.Tables(0).Columns(0).ColumnName
            lstright.DataBind()
        End If

    End Sub

    Private Sub BN_MOD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_MOD.Click
        form_edit()
    End Sub
    Sub form_edit()
            TXT_USER_ID.Enabled = False
            TXT_USER_ID.ReadOnly = True
        BN_SAV.Enabled = True
        BN_CAN.Enabled = True
        lstleft.Enabled = True
        lstright.Enabled = True
        lsttoright.Disabled = False
        lsttoleft.Disabled = False
        Button2.Disabled = False
        Button3.Disabled = False
        BN_MOD.Enabled = False
        btn1.Disabled = True
    End Sub

    Private Sub BN_SAV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SAV.Click
            Dim str_userid As String = Trim(TXT_USER_ID.Text)
        Dim stredt As String = Trim(edt2.Value)
        Dim str As String = "delete from FWEB_USER_LOGIN_D where USER_ID='" + str_userid + "' "
        db.ExecuteSQL(str)
        Dim s As String, str1 As String, str2 As String, str3 As String, strleave As String
        While InStr(1, stredt, ";") <> 0
            s = stredt.Substring(0, InStr(1, stredt, ";") - 1)
            str1 = s.Substring(0, InStr(1, stredt, "-") - 1)
            strleave = s.Substring(str1.Length + 1, s.Length - str1.Length - 1)
            str2 = strleave.Substring(0, strleave.IndexOf("-"))
            str3 = strleave.Substring(str2.Length + 1, strleave.Length - str2.Length - 1)
            str = String.Format("insert into FWEB_USER_LOGIN_D(user_id,syst_no,proj_no,func_no) values('{0}','{1}','{2}','{3}')", str_userid, str1, str2, str3)
            db.ExecuteSQL(str)
            If (InStr(1, stredt, ";") + 1) < (stredt.Length) Then
                stredt = stredt.Substring(InStr(1, stredt, ";"), (stredt.Length - InStr(1, stredt, ";")))
            Else
                Exit While
            End If
        End While
        bind_lst(str_userid)
        form_set()
        BN_MOD.Enabled = True
    End Sub

    Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CAN.Click
            Dim strid As String = Trim(TXT_USER_ID.Text)
        lstleft.Items.Clear()
        lstright.Items.Clear()
        bind_text(strid)
        bind_lst(strid)
        form_set()
        BN_MOD.Enabled = True
    End Sub
    Function check_set(ByVal strid As String) As Boolean
        Dim strsql As String
        strsql = "select count(*) from FWEB_USER_LOGIN_M where user_id='" + strid + "' and user_level='U'"
        If db.GetExecuteScalar(strsql) > 0 Then
            Return False
        Else
            Return True
        End If
    End Function
    Sub begin()
            TXT_USER_ID.Text = ""

            TXT_USER_NAME.Text = ""
        Text3.Value = ""
        Text1.Value = ""
        DropDownList1.SelectedValue = "U"
        Text2.Value = ""
        lstleft.Items.Clear()
        lstright.Items.Clear()
        form_set()
        BN_MOD.Enabled = False
    End Sub
End Class

End Namespace
