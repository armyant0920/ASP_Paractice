Imports System.Xml


Namespace FR

Partial Class FWEB_DATA_TEMP
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Request.QueryString("period_name") <> Nothing And Request.QueryString("org") <> Nothing And Request.QueryString("cost_center") <> Nothing And Request.QueryString("product_num") <> Nothing Then
            Dim strperiod_name As String = Request("period_name").ToString.Trim
            Dim strorg As String = Request("org").ToString.Trim
            Dim strcost_center As String = Request("cost_center").ToString.Trim
            Dim strproduct_num As String = Request("product_num").ToString.Trim
            Dim strTRANSACTION_TYPE As String = Request("TRANSACTION_TYPE").ToString.Trim
            Dim ds As New DataSet("INF")
            Dim SQLStr As String
            SQLStr = "select  FWEB_ONL_PREONHAND('" & strorg & "',to_date('" & strperiod_name & "','yyyy/MM/dd'),'" & strTRANSACTION_TYPE & "','" & strcost_center & "','" & strproduct_num & "') as PREONHAND, " & _
            " FWEB_ONL_WASTEQTY('" & strorg & "',to_date('" & strperiod_name & "','yyyy/MM/dd'),'" & strTRANSACTION_TYPE & "','" & strcost_center & "','" & strproduct_num & "') as WASTEQTY from dual"
            'SQLStr1 = "select nvl(sum(nvl(t.qty,0)),0) as CAL_COST,nvl(FWEB_ONL_WASTEQTY('" + strorg + "',to_date('" + strperiod_name + "','yyyy/MM'),'" + strcost_center + "','" + strproduct_num + "'),0)  AS NOWWASTE  from ucmtl_month_check_t t " & _
            '         "where period_name = upper(to_char (add_months(to_date('" + strperiod_name + "','yyyy/MM'),-1), 'mon-yy','NLS_DATE_LANGUAGE = American')) " & _
            '         "and org = '" + strorg + "' and cost_center = '" + strcost_center + "' and product_num = '" + strproduct_num + "'"
            ds = db.FillDataSet(SQLStr, "TABLE")
            Dim writer As XmlTextWriter = New XmlTextWriter(Response.OutputStream, Response.ContentEncoding)
            writer.Formatting = Formatting.Indented
            writer.Indentation = 4
            writer.IndentChar = " "
            ds.WriteXml(writer)
            writer.Flush()
            Response.End()
            writer.Close()
        End If

    End Sub

End Class

End Namespace
