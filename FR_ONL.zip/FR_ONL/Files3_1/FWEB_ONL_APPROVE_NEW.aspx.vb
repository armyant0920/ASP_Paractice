Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices


Namespace FR

Partial Class FWEB_ONL_APPROVE_NEW
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        If Not Page.IsPostBack Then
           Init_Data()
           GetPeriod()
           Load_Org()
           Lbl_ActionFlag.Text = "QUERY"
        End If
    End Sub

    Sub GetPeriod()
        '����
        Dim SQL As String
        Dim DSTemp As DataSet
        SQL = " SELECT TO_CHAR(START_DATE,'YYYY/MM/DD') AS Period_Name " & vbNewLine & _
              " FROM UCCST_CALENDAR_T WHERE MTL_CLOSE IS NULL "
        DSTemp = db.FillDataSet(SQL, 2)
        If DSTemp.Tables(0).Rows.Count > 0 Then
            txtPeriod_Name.Text = DSTemp.Tables(0).Rows(0).Item("Period_Name").ToString.Substring(0, 7)
            'txtPeriod_Name.Text = "2013/03/01"
        End If
    End Sub


    Sub Load_Org()
        '�t�OddlOrg
        Dim SQL As String = ""
        SQL = " SELECT DISTINCT A.ORG AS ID, A.ORG|| ' ' || B.ORG_NAME AS NAME " & vbNewLine & _
              " FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
              " WHERE A.ORG = B.ORG AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
              " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) " & vbNewLine & _
              " ORDER BY A.ORG "
        GetddlDownList(SQL, ddlOrg, "NCST2")
    End Sub

    Sub Load_Cost()
        ddlCostCenter.SelectedIndex = -1
        txtCostCenter.Text = ""
        '��������ddlCostCenter
        Dim SQL As String = ""
        SQL = " SELECT DISTINCT A.COST_CENTER AS ID, A.COST_CENTER || ' ' || B.COST_CENTER_NAME AS NAME " & vbNewLine & _
              " FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
              " WHERE A.ORG = '" & ddlOrg.SelectedValue.ToString & "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
              " AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
              " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER)  " & _
              " ORDER BY A.COST_CENTER "
        GetddlDownList(SQL, ddlCostCenter, "NCST2")
    End Sub

    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
        '�d��
        GridMain.DataSource = Nothing
        GridMain.DataBind()

        Lbl_ActionFlag.Text = "QUERY"
        SetQueryViewState()
        Me.GridMain.CurrentPageIndex = 0
        Load_Data(ViewState("sqltxt"))

        For i As Integer = 0 To GridMain.Items.Count - 1
           CType(GridMain.Items(i).FindControl("ChkSelect"), WebControls.CheckBox).Enabled = False
        Next i
    End Sub

        Sub Load_Data(ByVal sqlcmd As String)
            Dim DSTemp As New DataSet

            Try
                DSTemp = db.FillDataSet(sqlcmd, 2)

                If DSTemp.Tables(0).Rows.Count > 0 Then
                    GridMain.DataSource = DSTemp.Tables(0)
                    GridMain.DataBind()

                    btnSave.Enabled = True
                Else
                    GridMain.DataSource = Nothing
                    GridMain.DataBind()
                    Alert("�d�L���.", Me)
                End If
                DSTemp.Dispose()
            Catch ex As Exception
                Alert(ex.Message, Me)
            Finally
                If Not DSTemp Is Nothing Then
                   DSTemp.Dispose()
                End If
            End Try
        End Sub

    Sub SetQueryViewState()
        Dim StrMessage As String = ""
        StrMessage = CheckEmpty()
        If StrMessage = "" Then
           Dim StrSQL As String = ""
           StrSQL = " select to_char(T.PERIOD_NAME,'yyyy/MM/dd') as PERIOD_NAME " & vbNewLine & _
                     ",T.ORG,t.TRANSACTION_TYPE,T.COST_CENTER,M.COST_CENTER_NAME,T.BONDED_FLAG, T.PRODUCT_NUM,t.PRODUCT_DESC,T.UOM,T.PRE_ONHAND," & vbNewLine & _
                     " T.NOW_WASTE,T.NOW_ONHAND, T.BONDED_NOW_ONHAND,T.CHECK_ONHAND,T.REMARK,T.IMPORT_MARK,to_char(T.IMPORT_DATE,'yyyy/mm/dd') as IMPORT_DATE," & vbNewLine & _
                     " T.IMPORT_USER,T.APPROVE_MARK,to_char(T.APPROVE_DATE,'yyyy/mm/dd') as APPROVE_DATE ," & _
                     " T.APPROVE_USER,to_char(T.MDATE,'yyyy/mm/dd') as MDATE ,T.MUSER,to_char(T.CDATE,'yyyy/mm/dd') as CDATE,T.CUSER" & vbNewLine & _
                     " from FWEB_ONL_ONHAND T,FWEB_COST_CENTER_V M " & vbNewLine & _
                     "WHERE T.ORG = M.ORG AND T.COST_CENTER=M.COST_CENTER " & vbNewLine & _
                     "AND T.ORG = '" & txtOrg.Text.ToString.Trim & "' " & vbNewLine & _
                     "AND T.COST_CENTER = '" & txtCostCenter.Text.ToString.Trim & "' " & vbNewLine
                     '" ,(" & vbNewLine & _
                     '"    SELECT DECODE(D.ORG,'ALL','02',D.ORG) AS ORG,DECODE(D.COST_CENTER,'ALL','3081',D.COST_CENTER) AS COST_CENTER" & vbNewLine & _
                     '"    FROM FWEB_USER_LOGIN_M M, FWEB_USER_ORGAU_D D" & vbNewLine & _
                     '"    WHERE M.USER_ID=D.USER_ID" & vbNewLine & _
                     '"    AND D.PROJ_NO='ONL' AND M.USER_ID='" & Context.User.Identity.Name & "'" & vbNewLine & _
                     '"    AND DECODE(D.ORG,'ALL','" & txtOrg.Text.ToString & "',D.ORG)='" & txtOrg.Text.ToString & "'" & vbNewLine & _
                     '"    AND DECODE(D.COST_CENTER,'ALL','" & txtCostCenter.Text.ToString & "',D.COST_CENTER)='" & txtCostCenter.Text.ToString & "'" & vbNewLine & _
                     '" ) A" & vbNewLine & _
                     '"WHERE A.ORG=T.ORG AND A.COST_CENTER=T.COST_CENTER " & vbNewLine & _
           StrSQL &= IIf(txtProduct_Num.Text.ToString.Trim.Equals(""), "", "AND T.PRODUCT_NUM = '" & txtProduct_Num.Text.ToString.Trim & "' " & vbNewLine)
           Select Case ddlabNormal.SelectedValue.ToString
               Case "Y" '���`
                   StrSQL &= " AND T.CHECK_ONHAND < 0 "
               Case "N" '���T
                   StrSQL &= " AND T.CHECK_ONHAND >= 0"
           End Select
           StrSQL &= " and  T.IMPORT_MARK ='Y'  and (T.APPROVE_MARK<>'Y' or  T.APPROVE_MARK is null)" & vbNewLine & _
                     " and T.PERIOD_NAME=to_date('" & txtPeriod_Name.Text.ToString & "/01','yyyy/MM/dd') " & vbNewLine

           Dim sqltxt As String = StrSQL
           ViewState("sqltxt") = sqltxt         '�d��Query��JViewState�A�H�K�H�ɥi���sQuery
        Else
           Alert(StrMessage, Me)
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        '����
        Lbl_ActionFlag.Text = "QUERY"
        Init_Data()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim StrSQL As String = ""
        Dim StrMessage As String = ""
        Dim StrErrorMessage As String = ""
        Try
           Dim IntCheck As Integer = 0
           For i As Integer = 0 To GridMain.Items.Count - 1
              If CType(GridMain.Items(i).FindControl("ChkSelect"), WebControls.CheckBox).Checked = True Then
                 If CType(GridMain.Items(i).FindControl("txtNow_Onhand"), WebControls.TextBox).Text.ToString.Equals("") Or _
                    CType(GridMain.Items(i).FindControl("txtBonded_Now_Onhand"), WebControls.TextBox).Text.ToString.Equals("") Or _
                    CType(GridMain.Items(i).FindControl("txtCheck_Onhand"), WebControls.TextBox).Text.ToString.Equals("") Or _
                    CType(GridMain.Items(i).FindControl("txtRemark"), WebControls.TextBox).Text.ToString.Equals("") Then
                    StrErrorMessage += "�Ƹ�" & GridMain.Items(i).Cells(7).Text.ToString & "���s�ƻP�Ƶ������A���i�ťաC" & vbNewLine
                    'Alert(GridMain.Items(i).Cells(1).Text.ToString & GridMain.Items(i).Cells(2).Text.ToString & "�Ƹ�" & GridMain.Items(i).Cells(7).Text.ToString & "���s�ƻP�Ƶ������A���i�ťաC", Me)
                    'Exit Sub
                 Else

                    StrSQL = "Update FWEB_ONL_ONHAND set " & vbNewLine & _
                             "Now_Onhand='" & CType(GridMain.Items(i).FindControl("txtNow_Onhand"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                             ",Bonded_Now_Onhand='" & CType(GridMain.Items(i).FindControl("txtBonded_Now_Onhand"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                             ",Check_Onhand='" & CType(GridMain.Items(i).FindControl("txtCheck_Onhand"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                             ",Remark='" & CType(GridMain.Items(i).FindControl("txtRemark"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                             ",MUSER='" & Context.User.Identity.Name & "'" & vbNewLine & _
                             ",MDATE=SYSDATE "
                    StrSQL += " Where Period_Name=to_date('" & GridMain.Items(i).Cells(1).Text.ToString.Trim & "','yyyy/mm/dd') " & vbNewLine & _
                              " and Org='" & GridMain.Items(i).Cells(2).Text.ToString.Trim & "'" & vbNewLine & _
                              " and cost_center='" & GridMain.Items(i).Cells(4).Text.ToString.Trim & "'" & vbNewLine & _
                              " and Product_Num='" & GridMain.Items(i).Cells(7).Text.ToString.Trim & "' " & vbNewLine

                    db.ExecuteSQL(StrSQL)

                    StrMessage += GridMain.Items(i).Cells(7).Text.ToString & ","
                    'StrMessage += IIf(StrMessage.Equals(""), GridMain.Items(i).Cells(7).Text.ToString & ",", "")

                 End If
                 IntCheck += 1
              End If
           Next

           If IntCheck < 1 Then
              Alert("�п�ܩһݧ�s���!", Me)
           Else
              If StrErrorMessage = "" Then
                 Alert(StrMessage & "�x�s����!", Me)
              Else
                 Alert(StrErrorMessage, Me)
              End If
           End If


        Catch ex As Exception
            Alert(ex.Message, Me)
            Exit Sub
        End Try
        Lbl_ActionFlag.Text = "Save"
        Load_Data(ViewState("sqltxt"))
    End Sub

    Private Sub dg_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        'DataGridView���C�@��Record��Delete�]�wLinkButton
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btnDELETE"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        'DataGridView���C�@��Record�]�wcurrentcolor
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub dg_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        If e.CommandName = "DELETE" Then     '�R��            
            Dim sqlcmd As String
            sqlcmd = "DELETE FROM FWEB_ONL_PROD WHERE PROD_RULE = '" + e.Item.Cells(1).Text.Trim + "' AND ORG ='" + e.Item.Cells(3).Text.Trim + "' " & _
                     "AND COST_CENTER = '" + e.Item.Cells(4).Text.Trim + "' AND INCLUDE = '" + e.Item.Cells(6).Text.Trim + "' AND PRODUCT_NUM = '" + e.Item.Cells(7).Text.Trim + "'"
            Try
                db.ExecuteSQL(sqlcmd)
            Catch ex As Exception
                Throw ex
            Finally
                Load_Data(ViewState("sqltxt"))
            End Try
        End If
    End Sub

    Function Check_Data() As Boolean
        'Check
        Dim ErrCount As Int16 = 0

        '�t�O���i����
        If ErrCount = 0 And txtOrg.Text.ToString.Equals("") Then
            ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
        End If

        'Err
        If ErrCount > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Sub SetDisplay()

        If Lbl_ActionFlag.Text = "ADD" Then    '�s�W

        ElseIf Lbl_ActionFlag.Text = "QUERY" Then '�s��
            '���s���A
            btnSave.Enabled = True
            btnCancel.Enabled = True
            '����
            txtPeriod_Name.BackColor = ColorTranslator.FromHtml("#E0FFFF")
            '�t�O
            txtOrg.Enabled = False
            txtOrg.Text = ""
            txtOrg.BackColor = ColorTranslator.FromHtml("#E0FFFF")
        End If
    End Sub

    Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
        If ViewState("sqltxt") = "" Then
           Alert("�Х�����d��!", Me)
        Else
           '��Excel
           Response.Write("<script>window.open(' " + EXPORT_EXCEL() + " ')</script>")
        End If
    End Sub

        Function EXPORT_EXCEL() As String
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
        Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_APPROVE_EXCEL.xls"
        Dim savepath As String = PublicM.GetSessionDataRoot(Context) + "ONL_APPROVE_EXCEL.xls" 'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(Context) + "ONL_APPROVE_EXCEL.xls" 'JavaScript�}��xls���|,�n�Psavepath�P
        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)
            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells
            '��R���
            Dim ds As DataSet
            ds = db.FillDataSet(ViewState("sqltxt"), 2)

            Dim x, y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "PERIOD_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("PERIOD_NAME").ToString.Substring(0, 10)
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("ORG").ToString
                            j = j + 1
                        Next
                    Case "TRANSACTION_TYPE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 4) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 5) = ds.Tables(0).Rows(x).Item("COST_CENTER_NAME").ToString
                            j = j + 1
                        Next
                    Case "BONDED_FLAG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 6) = ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_NUM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString

                            j = j + 1
                        Next
                    Case "PRODUCT_DESC"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                            j = j + 1
                        Next
                    Case "UOM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString

                            j = j + 1
                        Next
                    Case "PRE_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString

                            j = j + 1
                        Next
                    Case "NOW_WASTE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString

                            j = j + 1
                        Next
                    Case "NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString

                            j = j + 1
                        Next
                    Case "BONDED_NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString

                            j = j + 1
                        Next
                    Case "CHECK_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("CHECK_ONHAND").ToString

                            j = j + 1
                        Next
                    Case "REMARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 15) = ds.Tables(0).Rows(x).Item("REMARK").ToString

                            j = j + 1
                        Next
                    Case "IMPORT_MARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 16) = ds.Tables(0).Rows(x).Item("IMPORT_MARK").ToString

                            j = j + 1
                        Next
                    Case "IMPORT_DATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 17) = ds.Tables(0).Rows(x).Item("IMPORT_DATE").ToString

                            j = j + 1
                        Next
                    Case "IMPORT_USER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 18) = "'" + ds.Tables(0).Rows(x).Item("IMPORT_USER").ToString

                            j = j + 1
                        Next
                    Case "APPROVE_MARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 19) = ds.Tables(0).Rows(x).Item("APPROVE_MARK").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_DATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 20) = ds.Tables(0).Rows(x).Item("APPROVE_DATE").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_USER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 21) = "'" + ds.Tables(0).Rows(x).Item("APPROVE_USER").ToString
                            j = j + 1
                        Next
                    Case "MDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 22) = "'" + ds.Tables(0).Rows(x).Item("MDATE").ToString
                            j = j + 1
                        Next
                    Case "MUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 23) = "'" + ds.Tables(0).Rows(x).Item("MUSER").ToString
                            j = j + 1
                        Next
                    Case "CDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 24) = "'" + ds.Tables(0).Rows(x).Item("CDATE").ToString
                            j = j + 1
                        Next
                    Case "CUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 25) = "'" + ds.Tables(0).Rows(x).Item("CUSER").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            ' oExcel.DisplayAlerts = True

            Return JSsavepath
        Catch ex As Exception
            Throw ex
        Finally
            ' oExcel.Application.Quit()
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If

            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If

            'GC.Collect()

        End Try
        '  GC.Collect()
        End Function

        Sub loaddata(ByVal strsql As String)
            Dim DSTemp As New DataSet
            Dim DVTemp As New DataView
            DSTemp = db.FillDataSet(strsql, 2)
            DVTemp = DSTemp.Tables(0).DefaultView
            GridMain.DataSource = DVTemp
            GridMain.DataBind()
        End Sub

    Private Sub GridMain_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles GridMain.PageIndexChanged
        '����
        GridMain.CurrentPageIndex = e.NewPageIndex

        Load_Data(ViewState("sqltxt"))
    End Sub

    Private Sub ddlOrg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlOrg.SelectedIndexChanged
        txtOrg.Text = ddlOrg.SelectedValue.ToString
        Load_Cost()
    End Sub

    Private Sub Init_Data()
       ddlabNormal.Items.Clear()
       ddlabNormal.Items.Insert(0, "")
       ddlabNormal.Items.Insert(1, "Y")
       ddlabNormal.Items.Insert(2, "N")

       ddlOrg.SelectedIndex = -1
       ddlCostCenter.SelectedIndex = -1
       ddlabNormal.SelectedIndex = -1
       txtOrg.Text = ""
       txtCostCenter.Text = ""
       txtProduct_Num.Text = ""
       btnSave.Enabled = False
       GridMain.DataSource = Nothing
       GridMain.DataBind()
    End Sub

    Protected Sub ddlCostCenter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCostCenter.SelectedIndexChanged
       txtCostCenter.Text = ddlCostCenter.SelectedValue.ToString()
    End Sub

    Protected Sub btnAPPROVE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAPPROVE.Click
        Dim StrSQL As String = ""
        Dim StrMessage As String = ""
        Lbl_ActionFlag.Text = "APPROVE"

        Try
           StrMessage = CheckEmpty()
           If StrMessage = "" Then
              StrSQL = "Update FWEB_ONL_ONHAND set " & vbNewLine & _
                       "APPROVE_MARK='Y', APPROVE_DATE=SYSDATE, APPROVE_USER='" + Context.User.Identity.Name + "' " & vbNewLine & _
                      " WHERE ORG = '" & txtOrg.Text.ToString.Trim & "' " & vbNewLine & _
                      " AND COST_CENTER = '" & txtCostCenter.Text.ToString.Trim & "' " & vbNewLine
              'StrSQL &= IIf(txtOrg.Text.ToString.Trim.Equals(""), "", "AND ORG = '" & txtOrg.Text.ToString.Trim & "' " & vbNewLine)
              'StrSQL &= IIf(txtCostCenter.Text.ToString.Trim.Equals(""), "", "AND COST_CENTER = '" & txtCostCenter.Text.ToString.Trim & "' " & vbNewLine)
              StrSQL &= IIf(txtProduct_Num.Text.ToString.Trim.Equals(""), "", "AND PRODUCT_NUM = '" & txtProduct_Num.Text.ToString.Trim & "' " & vbNewLine)
              Select Case ddlabNormal.SelectedValue.ToString
                  Case "Y" '���`
                      StrSQL &= " AND CHECK_ONHAND < 0 "
                  Case "N" '���T
                      StrSQL &= " AND CHECK_ONHAND >= 0"
              End Select
              StrSQL += " AND IMPORT_MARK ='Y'  and (APPROVE_MARK<>'Y' or  APPROVE_MARK is null)" & vbNewLine & _
                        " AND Period_Name=to_date('" & txtPeriod_Name.Text.ToString.Trim & "/01','yyyy/mm/dd') " & vbNewLine
              db.ExecuteSQL(StrSQL)

              StrMessage = txtOrg.Text.ToString.Trim & txtCostCenter.Text.ToString.Trim
              StrMessage &= IIf(txtProduct_Num.Text.ToString.Trim.Equals(""), "", ",�Ƹ�" & txtProduct_Num.Text.ToString)
              Select Case ddlabNormal.SelectedValue.ToString
                  Case "Y" '���`
                      StrMessage &= ",���`���"
                  Case "N" '���T
                      StrMessage &= ",���`���"
              End Select
              StrMessage &= "APPROVE����!"
              Alert(StrMessage, Me)
           Else
              Alert(StrMessage, Me)
           End If
       Catch ex As Exception
           Alert(ex.Message, Me)
       End Try
    End Sub

    Protected Sub btnModify_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnModify.Click
        Lbl_ActionFlag.Text = "EDIT"
        For i As Integer = 0 To GridMain.Items.Count - 1
           CType(GridMain.Items(i).FindControl("ChkSelect"), WebControls.CheckBox).Enabled = True
        Next i
    End Sub
    Protected Function CheckEmpty() As String
        Dim StrMessage As String = ""
        If txtOrg.Text = "" Then
           StrMessage = "�п�ܼt�O!"
        End If
        If txtCostCenter.Text = "" Then
           StrMessage &= "�п�ܦ�������!"
        End If
       Return StrMessage
    End Function

    Protected Sub GridMain_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridMain.SelectedIndexChanged
        For i As Integer = 0 To GridMain.Items.Count - 1
           CType(GridMain.Items(i).FindControl("ChkSelect"), WebControls.CheckBox).Enabled = False
        Next i
    End Sub
End Class

End Namespace
