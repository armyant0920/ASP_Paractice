﻿
//============================調用成本中心
function load_dropdownlist(facid) {
    console.log('AJAX load_dropdownlist');

    if (facid != "" && facid!=null) {
        var target = "cost";
        var datas = new Array();//以Array形式回傳資料
        $.ajax({
            async: false,
            type: "post",
            dataType: "json",
            url: "Controller.aspx",
            data: { "target": target, "cmd": "S", "facid": facid },
            success:
						function (data) {
						    console.log('test:'+typeof (data));
						    var newOption = document.createElement("OPTION");
						    

						    for (i = 0; i < data.length; i++) {
						        
						        datas.push(data[i]);


						    }
						},
            error: function () { alert("error"); }
        });
    }
    //console.log(datas);
    //console.log(datas.length);
    return datas;


}



//================================ 由廠別帶用起訖日期
function load_edtDateFrom(qijian) {
    console.log('AJAX load_edtDateFrom');

    var obj = new Object(); //以物件形式回傳資料
    
 
    if (qijian != "" && qijian!=null) {
        var target = "edtDate", cmd = "S";
        $.ajax({
            async: false,
            target: "post",
            data: { "target": target, "cmd": cmd, "qijian": qijian },
            dataType: "json",
            url: "Controller.aspx",
            success:
						function (data) {


						    obj = { START_DATE: data[0].START_DATE, END_DATE: data[0].END_DATE };

						    //若用固定順序取資料		
						    /*
						    var dates = [];
                            dates.push(data[0].START_DATE);
						    dates.push(data[0].END_DATE);*/
						},

            error: function () { alert("error"); return; }
        });
    }
    return obj;



}



//================================ 由廠別帶用期間
function load_PeriodMonth(qijian) {
    console.log('AJAX load_PeriodMonth');

    var obj = new Object(); //以物件形式回傳資料


    if (qijian != "" && qijian != null) {
        var target = "periodQuery", cmd = "S";
        $.ajax({
            async: false,
            target: "post",
            data: { "target": target, "cmd": cmd, "qijian": qijian },
            dataType: "json",
            url: "Controller.aspx",
            success:
						function (data) {
						    obj = { PERIOD_MOTH: data[0].PERIOD_MOTH };
						},

            error: function () { alert("error"); return; }
        });
    }
    return obj;



}

function load_Period_Moth(facid) {
    console.log('AJAX load_Period_Moth');

    if (facid != "" && facid != null) {
        var target = "period_moth";
        var datas = new Array(); //以Array形式回傳資料
        $.ajax({
            async: false,
            type: "post",
            dataType: "json",
            url: "Controller.aspx",
            data: { "target": target, "cmd": "S", "facid": facid },
            success:
						function (data) {
						    console.log('test:' + typeof (data));
						    var newOption = document.createElement("OPTION");


						    for (i = 0; i < data.length; i++) {

						        datas.push(data[i]);


						    }
						},
            error: function () { alert("error"); }
        });
    }
    //console.log(datas);
    //console.log(datas.length);
    return datas;



}






function getInfo() {
    console.log('AJAX getInf');

    var obj = new Object(); //以物件形式回傳資料

    var period_name = document.all('edtDateFrom').value;
    var org = document.all('txt_org_no').value;
    var cost_center = document.all('txt_cost_no').value;
    var TRANSACTION_TYPE = document.all('dd_list_yd').value;
    var product_num = document.all('Text1').value;

    var target = "getInfo", cmd = "S";



    //實際需要回傳的值:
    var Cal_Cost = 0;
    var NowWaste = 0;

    $.ajax({
        async: false,
        target: "post",
        data: { "target": target,
            "cmd": cmd,
            "period_name": period_name,
            "org": org,
            "cost_center": cost_center,
            "TRANSACTION_TYPE": TRANSACTION_TYPE,
            "product_num": product_num
        },

        dataType: "json",
        url: "Controller.aspx",
        success:
						function (data) {
						    console.log("暫不處理");

						    //obj = { START_DATE: data[0].START_DATE, END_DATE: data[0].END_DATE };

						    //若用固定順序取資料		
						    /*
						    var dates = [];
						    dates.push(data[0].START_DATE);
						    dates.push(data[0].END_DATE);*/
						},

        error: function () { alert("error"); return; }
    });

    return obj;

    //舊版程式
   /* var date_ = document.getElementById('Text2');
    var txt_ = document.all('Text3');

    //empno.value=empno.value.replace(' ','').toUpperCase(); 
    var oHttpReq = new ActiveXObject("MSXML2.XMLHTTP");
    var oDoc = new ActiveXObject("MSXML2.DOMDocument");
    oHttpReq.open("post", "FWEB_DATA_TEMP.aspx?period_name=" + document.all('edtDateFrom').value + "&org=" + document.all('txt_org_no').value + "&cost_center=" + document.all('txt_cost_no').value + "&TRANSACTION_TYPE=" + document.all('dd_list_yd').value + "&product_num=" + document.all('Text1').value, false);
    oHttpReq.send("");
    result = oHttpReq.responseText;
    oDoc.loadXML(result);

    items = oDoc.selectNodes("//NewDataSet/TABLE");

    for (var item = items.nextNode(); item; item = items.nextNode()) {

        if (item.selectSingleNode("PREONHAND") != undefined)
            Cal_Cost = item.selectSingleNode("PREONHAND").text;
        if (item.selectSingleNode("WASTEQTY") != undefined)
            NowWaste = item.selectSingleNode("WASTEQTY").text;
    }
    date_.value = Cal_Cost
    txt_.value = NowWaste
    if (date_.value == "")
    { date_.value = 0 }
    if (txt_.value == "")
    { txt_.value = 0 }*/
}

