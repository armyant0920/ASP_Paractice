Namespace FR

    Partial Class FWEB_LOGIN
        Inherits System.Web.UI.Page

        Public imageurl As String  '�Ϥ��۹���|
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'imageurl = Request.ApplicationPath & "/Image/"
            If Not Page.IsPostBack Then
                'Response.Write("<script>alert('�g��J�t�Υ����ץ��K�X:��2008/5/1�}�l,�Ĥ@���i�J�t��,�K�X�w�]��:FWEB+�b��,�i�J�t�Ϋ�,�A�ۦ�]�w�ӤH�K�X!!')</script>")

                btnok.Attributes.Add("onclick", "check();")
                DIV1.Visible = True
                DIV2.Visible = False
            End If
        End Sub

        Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
            If check_lenth() = True Then
                If check_canpsw(txtID.Text) = True Then
                    UserLoginValidate(txtID.Text, txtpwd.Text)
                Else
                    DIV1.Visible = False
                    DIV2.Visible = True
                    Me.TBuserid.Text = Me.txtID.Text
                End If
            End If
        End Sub

        Sub UserLoginValidate(ByVal uid As String, ByVal pwd As String)
            Dim TempDS As New DataSet
            Dim strid As String = ""
            Dim sqltext As String
            Try
                sqltext = "select * from FWEB_USER_LOGIN_M t where USER_ID='" + uid + "'"
                TempDS = db.FillDataSet(sqltext, 2)
                Dim dt = TempDS.Tables(0)
                Dim dr As DataRow
                Dim dc As DataColumn


                For Each dr In dt.Rows
                    For Each dc In dt.Columns
                        System.Diagnostics.Debug.WriteLine("value  " + dr(dc).ToString)
                    Next
                Next
                '�ˬd�b���O�_�s�b()
                If dt.Rows.Count = 0 Then
                    Response.Write("<script defer>alert('���s�b�ӱb��');</script>")
                    Exit Sub
                End If

                '�ˬd�b���O�_����()
                If dt.Rows(0).Item("OFFWORK") = "Y" Then
                    Response.Write("<script defer>alert('�b���w����!');</script>")
                    Exit Sub
                End If
                '�ˬd�K�X
                If dt.Rows(0).Item("PASSWORD") <> pwd Then
                    Response.Write("<script defer>alert('�K�X���~');</script>")
                    Exit Sub
                End If

                System.Web.Security.FormsAuthentication.RedirectFromLoginPage(uid, False)
                Response.Redirect("~/FWEB_MENU.aspx")

                'If TempDS.Tables(0).Rows.Count = 0 Then
                '    Response.Write("<script defer>alert('���s�b�ӱb��');</script>")
                '    Exit Sub
                'Else
                '    sqltext = "select * from FWEB_USER_LOGIN_M t where t.USER_ID = '" + uid + "' and nvl(t.OFFWORK,'N') = 'N'"
                '    TempDS = db.FillDataSet(sqltext, 2)
                '    If TempDS.Tables(0).Rows.Count = 0 Then
                '        Response.Write("<script defer>alert('�b���w����!');</script>")
                '        Exit Sub
                '    Else
                '        sqltext = "select * from FWEB_USER_LOGIN_M t where t.USER_ID='" + uid + "' and PASSWORD='" + pwd + "'"
                '        TempDS = db.FillDataSet(sqltext, 2)
                '        If TempDS.Tables(0).Rows.Count = 0 Then
                '            Response.Write("<script defer>alert('�K�X���~');</script>")
                '            Exit Sub
                '        Else
                '            System.Web.Security.FormsAuthentication.RedirectFromLoginPage(uid, False)
                '            Response.Redirect("~/FWEB_MENU.aspx")
                '        End If
                '    End If
                'End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try
        End Sub

        Function check_canpsw(ByVal txtid As String) As Boolean
            Dim TempDS As New DataSet
            Dim psw As String = "FWEB" & Me.txtID.Text.Trim
            Dim BooReturn As Boolean = False
            Try
                TempDS = db.FillDataSet("select * from fweb_user_login_m where user_id='" + Me.txtID.Text.Trim + "' and password='" + Me.txtpwd.Text.Trim + "'", 2)

                Dim dt = TempDS.Tables(0)
                Dim dr As DataRow
                Dim dc As DataColumn

                System.Diagnostics.Debug.WriteLine("TEST " + dt.Rows.Count.ToString)

                'For Each dr In dt.Rows
                '    For Each dc In dt.Columns
                '        System.Diagnostics.Debug.WriteLine("key=" + dc.ColumnName + " value  " + dr(dc).ToString)
                '    Next
                'Next



                If TempDS.Tables(0).Rows.Count = 1 Then
                    If psw = Me.txtpwd.Text.Trim Then
                        Response.Write("<script defer>alert('�z�O�Ĥ@�n�J,�Эק�K�X,���¡I');</script>")
                        BooReturn = False
                    Else
                        BooReturn = True
                    End If
                Else
                    BooReturn = True
                End If

            Catch ex As Exception
                Alert(ex.Message, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try
            Return BooReturn
        End Function

        Function check_lenth() As Boolean
            If Me.txtpwd.Text.Trim.Length < 7 Then
                Return False
            Else
                Return True
            End If
        End Function

        Private Sub Btnchange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnchange.Click
            Dim TempDS As New DataSet
            Try
                TempDS = db.FillDataSet("select * from FWEB_USER_LOGIN_M t where USER_ID='" + Me.txtID.Text.Trim + "'", 2)
                If TempDS.Tables(0).Rows.Count <> 0 Then
                    DIV1.Visible = False
                    DIV2.Visible = True
                    Me.TBuserid.Text = txtID.Text
                Else
                    Response.Write("<script defer>alert('���s�b�ӱb��')</script>")
                    Exit Sub
                End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try
        End Sub

        Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        End Sub

        Private Sub Btn_cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_cancel.Click
            DIV1.Visible = True
            DIV2.Visible = False
        End Sub

        Private Sub Btn_ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ok.Click
            Dim i As Int16
            Dim y As Int16 = 0
            Dim m As Int16 = 0
            Dim sqltext As String
            If TBpsw.Text = "" Then
                L1.Visible = True
                Exit Sub
            ElseIf TBxpsw.Text = "" Then
                L2.Visible = True
                Exit Sub
            ElseIf TBcpsw.Text = "" Then
                L3.Visible = True
                Exit Sub
            Else
                L3.Visible = False
                L2.Visible = False
                L1.Visible = False
            End If
            If Me.TBxpsw.Text.Trim.Length < 7 Then
                Response.Write("<script defer>alert('�K�X���פ��i�p��7!')</script>")
                Exit Sub
            End If

            Dim TempDS As New DataSet
            Try
                sqltext = "select * from FWEB_USER_LOGIN_M t where t.USER_ID='" + Me.TBuserid.Text.Trim + "' and PASSWORD='" + Me.TBpsw.Text.Trim + "'"
                TempDS = db.FillDataSet(sqltext, 2)
                If TempDS.Tables(0).Rows.Count = 0 Then
                    Response.Write("<script defer>alert('�K�X���~,�Э��s��J!')</script>")
                    Exit Sub
                End If
                For i = 0 To Me.TBxpsw.Text.Trim.Length - 1
                    If 65 <= Asc(Me.TBxpsw.Text.Trim.Substring(i, 1)) And Asc(Me.TBxpsw.Text.Trim.Substring(i, 1)) <= 90 Then
                        y = y + 1
                    End If
                    If 97 <= Asc(Me.TBxpsw.Text.Trim.Substring(i, 1)) And Asc(Me.TBxpsw.Text.Trim.Substring(i, 1)) <= 122 Then
                        y = y + 1
                    End If
                    If Asc(Me.TBxpsw.Text.Trim.Substring(i, 1)) >= 48 And Asc(Me.TBxpsw.Text.Trim.Substring(i, 1)) <= 57 Then
                        m = m + 1
                    End If
                Next
                If y <> 0 And m <> 0 Then
                    If Me.TBxpsw.Text.Trim = Me.TBcpsw.Text.Trim Then
                        If Me.TBxpsw.Text.Trim = Me.TBpsw.Text.Trim Then
                            Response.Write("<script defer>alert('�s�K�X���i�H�M�±K�X�@�ˡI')</script>")
                            Exit Sub
                        ElseIf Me.TBxpsw.Text.Trim.IndexOf(Me.TBuserid.Text.Trim) >= 0 Then
                            Response.Write("<script defer>alert('�K�X������t�u���I')</script>")
                            Exit Sub
                        Else
                            db.ExecuteSQL("update FWEB_USER_LOGIN_M set PASSWORD='" + Me.TBxpsw.Text.Trim + "' where USER_ID='" + Me.TBuserid.Text.Trim + "'")
                            Response.Write("<script defer>alert('�ק�K�X���\�I')</script>")
                            DIV1.Visible = True
                            DIV2.Visible = False
                        End If
                    Else
                        Response.Write("<script defer>alert('�K�X��J���@�P�A�Э��s��J�I')</script>")
                    End If
                Else
                    Response.Write("<script defer>alert('�K�X���A�ܤ֨ϥ�1�ӭ^��r���M�@�ӼƦr�I')</script>")
                End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try
        End Sub

        Protected Sub btn_throw_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_throw.Click
            Throw New Exception



        End Sub
    End Class

End Namespace
