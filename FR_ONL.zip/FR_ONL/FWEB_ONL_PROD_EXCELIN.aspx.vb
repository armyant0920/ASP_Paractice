﻿Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Data
Imports System.Data.OleDb
Imports System.Math
Imports System.Text
Imports Excel

'202205 author A3504 Kevin_A 

Namespace FR

    Partial Class FWEB_ONL_PROD_EXCELIN
        Inherits System.Web.UI.Page



        Dim oExcel As Excel.Application
        Dim oBooks As Excel.Workbooks
        Dim oBook As Excel.Workbook
        Dim oSheets As Excel.Sheets
        Dim oSheet As Excel.Worksheet
        Dim oCells As Excel.Range
        Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
        Dim occur_error As Boolean


        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            '在這裡放置使用者程式碼以初始化網頁
            If Not Page.IsPostBack Then
                'init_dg()       
                btn_export.Enabled = False
                btnTranIn.Attributes.Add("onclick", "return loading();")
                'Else
                '    tempTable = CType(ViewState("tempDT"), System.Data.DataTable)
                '    If tempTable Is Nothing Then
                '        System.Diagnostics.Debug.WriteLine("post_back tempTable is null")

                '    Else
                '        System.Diagnostics.Debug.WriteLine("post_back tempTable not null")
                '        System.Diagnostics.Debug.WriteLine("post_back tempT rows=" + tempTable.Rows.Count.ToString)

                '    End If
            End If
            

        End Sub
        '測試資料
        Private Sub init_dg()
            Dim dt As System.Data.DataTable

            dt = reset_Table()

            dt.Rows.Add("料號全碼", "07", "3141", "Y", "Y", "Y", "C73060001", "")
            dt.Rows.Add("料號全碼", "07", "3141", "Y", "Y", "Y", "C00060001", "")
            dt.Rows.Add("料號全碼", "07", "3141", "Y", "Y", "Y", "C00060002", "")
            dg.DataSource = dt
            dg.DataBind()



        End Sub

        Function reset_Table() As System.Data.DataTable

            dg.DataSource = Nothing
            Dim dt As New System.Data.DataTable
            dt.Columns.Add("PROD_RULE", GetType(String))
            dt.Columns.Add("ORG", GetType(String))
            dt.Columns.Add("COST_CENTER", GetType(String))
            dt.Columns.Add("INCLUDE", GetType(String))
            dt.Columns.Add("COST_FLAG", GetType(String))
            dt.Columns.Add("GOLD_FLAG", GetType(String))
            dt.Columns.Add("PRODUCT_NUM", GetType(String))
            dt.Columns.Add("RESULT", GetType(String))
            Return dt


        End Function
        '202205 Kevin_A 有空看能不能以C#改寫並建立物件簡化處理

        Class Prod

            Dim prod_rule As String
            Dim org As String
            Dim cost_center As String
            Dim include As String
            Dim cost_flag As String
            Dim gold_flag As String
            Dim product_num As String
            Dim result As String

            Public Sub New()

            End Sub

        End Class


        '關閉
        Private Sub btnEnd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnd.Click
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "close", "<script language='JavaScript'>window.close('FWEB_ONL_PROD_EXCELIN.aspx') </script>")
        End Sub

        'Excel轉入
        Private Sub btnTranIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTranIn.Click

            Dim UpFileName As String = ""
            Dim vResult As Boolean

            If Me.File1.Value = "" Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert1", "<script defer>alert('請選擇轉入Excel檔案');</script>")
                Exit Sub
            ElseIf (File1.PostedFile.FileName.Substring(File1.PostedFile.FileName.LastIndexOf(".")).ToLower() <> ".xls") _
                   And (File1.PostedFile.FileName.Substring(File1.PostedFile.FileName.LastIndexOf(".")).ToLower() <> ".xlsx") Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert2", "<script defer>alert('請選擇Excel檔案');</script>")
                Exit Sub
            Else
                Dim vFileName As String = File1.PostedFile.FileName
                UpFileName = vFileName.Substring(vFileName.LastIndexOf("\") + 1)
                File1.PostedFile.SaveAs(PublicM.GetSessionDataRoot(Context) + UpFileName)
                vResult = ExcelIn(UpFileName) '將Excel資料轉入Database
                If vResult = True Then
                    '檢查是否有異常


                    If occur_error = False Then
                        Alert("上傳成功!", Me)
                        'Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('上傳成功!');</script>")
                    Else
                        Alert("轉入有異常，請查看報表!", Me)
                        '202205 Kevin_A 這邊之後可以試試看如果有異常報告,調整視窗大小
                        'Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "open", "<script language='JavaScript'>window.open('FWEB_ONL_PROD_EXCELIN.aspx','','height=180,width=430') </script>")
                        'Window_MoveTo(0, 0, Me)
                        'Window_ResizeTo(0, 0, Me)


                    End If
                Else
                    'Response.Write(vResult)
                    'Response.End()
                    Alert("轉入發生異常.", Me)
                    'Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('轉入發生異常.')</script>")
                End If

                btn_export.Enabled = True
            

            End If
        End Sub


        Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
            dg.CurrentPageIndex = e.NewPageIndex

            dg.DataSource = CType(ViewState("tempDT"), System.Data.DataTable)
            dg.DataBind()


        End Sub

        '將Excel資料轉入Database
        Function ExcelIn(ByVal UpFileName As String) As Boolean
            Dim starttime As DateTime = DateTime.Now
            oExcel = New Excel.Application
            Dim endtime As DateTime = DateTime.Now
            Dim sTemplate As String = PublicM.GetSessionDataRoot(Context) + UpFileName
            Dim vResult As Boolean = True '此變數純粹確認"執行"是否異常
            Dim sqlcmd As String
            Dim dt As System.Data.DataTable

            occur_error = False '此變數追蹤內容是否有問題

            dt = reset_Table()

            Try
                oBooks = oExcel.Workbooks
                oBooks.Open(sTemplate)
                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                Dim row As Integer
                Dim intR As Integer = oSheet.UsedRange.Rows.Count
                Dim intC As Integer = oSheet.UsedRange.Columns.Count

                Dim error_msg As String


                '日期和時間直接抓系統

                Dim P_PROD_RULE, P_PROD_RULE_CN, P_ORG, P_COST_CENTER, P_INCLUDE, P_PRODUCT_NUM, P_COST_FLAG, P_GOLD_FLAG As String

                row = 2
                Do While row <= intR And vResult = True
                    error_msg = ""

                    'P_PERIOD_NAME = IIf(oCells(row, 1).Value Is DBNull.Value, "", oCells(row, 1).Value)

                    '1.料號規則
                    P_PROD_RULE_CN = PublicM.trimStr(oCells(row, 1).Value)
                    
                    '2.廠別
                    P_ORG = PublicM.trimStr(oCells(row, 2).Value)
                    '3.成本中心
                    P_COST_CENTER = PublicM.trimStr(oCells(row, 3).Value)
                    '5.是否盤點
                    P_INCLUDE = PublicM.trimStr(oCells(row, 5).Value)

                    '6.成本計算
                    P_COST_FLAG = PublicM.trimStr(oCells(row, 6).Value)

                    '7是否金鹽
                    P_GOLD_FLAG = PublicM.trimStr(oCells(row, 7).Value)

                    '8.料號
                    P_PRODUCT_NUM = PublicM.trimStr(oCells(row, 8).Value)

                    'Response.Write(P_PROD_RULE & "-" & P_ORG & "-" & P_COST_CENTER & "-" & P_INCLUDE & "-" & P_COST_FLAG & "-" & P_GOLD_FLAG & "-" & P_PRODUCT_NUM)
                    '202205 Kevin_A 檢查資料~錯誤訊息用之前單筆的延伸過來 
                    '要做的事太多,之後可以考慮C#改寫建成內部類處理...

                    '1.料號規則
                    '不可為空
                    If String.IsNullOrEmpty(P_PROD_RULE_CN) Then
                        error_msg += "料號規則請設料號第一碼/料號全碼!" + "<br>"

                    End If

                    '從中文轉為英文代碼
                    'P_PROD_RULE_CN 為中文輸入值,要轉換為資料庫插入的英文字,又需要在報表呈現,故放兩個變數
                    If P_PROD_RULE_CN = "料號全碼" Then
                        P_PROD_RULE = "A"
                    ElseIf P_PROD_RULE_CN = "料號第一碼" Then
                        P_PROD_RULE = "F"
                    Else
                        error_msg += "只能是'料號全碼'或'料號第一碼'" + "<br>"

                    End If

                    '2廠別
                    '不可為空
                    If String.IsNullOrEmpty(P_ORG) Then
                        error_msg += "廠別不可為空!" + "<br>"

                    Else
                        '可盤點廠別
                        sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG = DECODE('" + P_ORG + "','ALL',ORG,'" + P_ORG + "')"
                        If db.GetExecuteScalar(sqlcmd) = 0 Then
                            error_msg += "廠別錯誤，請重新輸入 (不是線上結存可盤點廠別) !" + "<br>"

                        End If
                    End If

                    '3.成本中心
                    '成本中心不可為空
                    If String.IsNullOrEmpty(P_COST_CENTER) Then
                        error_msg += "成本中心不可為空!" + "<br>"

                    Else
                        '是否為線上結存可盤點成本中心
                        sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG = DECODE('" + P_ORG + "','ALL',ORG,'" + P_ORG + "') AND COST_CENTER = DECODE('" + P_COST_CENTER + "','ALL',COST_CENTER,'" + P_COST_CENTER + "')"
                        If db.GetExecuteScalar(sqlcmd) = 0 Then
                            error_msg += "成本中心錯誤，請重新輸入 (不是線上結存可盤點成本中心)!" + "<br>"

                        End If

                    End If

                    '4.是否盤點
                    '請設定選取Y/排除N
                    If String.IsNullOrEmpty(P_INCLUDE) Then
                        error_msg += "'請設定選取Y/排除N !" + "<br>"

                    ElseIf P_INCLUDE <> "Y" And P_INCLUDE <> "N" Then
                        error_msg += "盤點只能是'Y'或'N'!" + "<br>"

                    End If

                    '5.是否成本計算
                    '進原物料成本MTL

                    If String.IsNullOrEmpty(P_COST_FLAG) Then
                        error_msg += "請設定是否須進MTL 是Y/否N !" + "<br>"

                    ElseIf P_COST_FLAG <> "Y" And P_COST_FLAG <> "N" Then
                        error_msg += "成本計算只能是'Y'或'N'!" + "<br>"

                    End If

                    '6.是否為金鹽

                    '金鹽
                    If String.IsNullOrEmpty(P_GOLD_FLAG) Then
                        error_msg += "請設定是否為金鹽 是Y/否N !" + "<br>"

                    ElseIf P_GOLD_FLAG <> "Y" And P_GOLD_FLAG <> "N" Then
                        error_msg += "金鹽只能是'Y'或'N'!" + "<br>"

                    End If

                    '7.料號檢查

                    '料號不可為空
                    If String.IsNullOrEmpty(P_PRODUCT_NUM) Then
                        error_msg += "料號不可為空!" + "<br>"

                    End If

                    '8.料號規則+料號檢查
                    '料號規則若為F,同時檢查長度
                    If P_PROD_RULE = "F" And P_PRODUCT_NUM.Length > 1 Then
                        error_msg += "請輸入料號第一碼!" + "<br>"

                    End If

                    '組成資料列


                    '如果經過上面資料檢查沒問題,才執行insert
                    'If 1 = 1 And P_PROD_RULE <> "" And P_ORG <> "" And P_COST_CENTER <> "" And P_INCLUDE <> "" And P_COST_FLAG <> "" And P_GOLD_FLAG <> "" And P_PRODUCT_NUM <> "" Then
                    If error_msg.Length < 1 Then

                        '9.資料已存在 (料號規則+廠別+成本中心+料號 為唯一值)

                        sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_PROD WHERE PROD_RULE = '" + P_PROD_RULE + "' AND ORG = '" + P_ORG + "' " & _
                                 "AND COST_CENTER = '" + P_COST_CENTER + "' AND PRODUCT_NUM = '" + P_PRODUCT_NUM + "'"

                        If db.GetExecuteScalar(sqlcmd) > 0 Then
                            error_msg += "修改成功" + "<br>"
                            sqlcmd = String.Format("UPDATE FWEB_ONL_PROD SET COST_FLAG='{0}',GOLD_FLAG='{1}',INCLUDE='{2}',CUSER='{3}',CDATE=sysdate " & _
                                                   "WHERE PROD_RULE='{4}' AND ORG='{5}' AND COST_CENTER='{6}' AND PRODUCT_NUM='{7}'", _
                                                    P_COST_FLAG, P_GOLD_FLAG, P_INCLUDE, Context.User.Identity.Name, P_PROD_RULE, P_ORG, P_COST_CENTER, P_PRODUCT_NUM)
                        Else
                            sqlcmd = String.Format("INSERT INTO FWEB_ONL_PROD (PROD_RULE,ORG,COST_CENTER,INCLUDE,PRODUCT_NUM,COST_FLAG,GOLD_FLAG,CDATE,CUSER) " & _
                                       "VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}',SYSDATE,'{7}') ", _
                                        P_PROD_RULE, P_ORG, P_COST_CENTER, P_INCLUDE, P_PRODUCT_NUM.ToUpper, P_COST_FLAG, P_GOLD_FLAG, Context.User.Identity.Name)

                        End If

                        '如果執行結果不等於1,表示異常
                        Try
                            If db.Get_ExecuteSQL_Result(sqlcmd.ToString) <> 1 Then
                                Throw New Exception("error,sql=" + sqlcmd)

                            End If


                        Catch ex As Exception
                            error_msg = ex.ToString + "<br>" & "sql=" + sqlcmd
                        End Try

                        'vResult = ExecSP(P_PERIOD_NAME, P_ORG, P_TRANSACTION_TYPE, P_COST_CENTER, P_PRODUCT_NUM, P_PRODUCT_DESC, P_UOM, P_PRE_ONHAND, P_NOW_WASTE, P_NOW_ONHAND, P_BONDED_NOW_ONHAND, P_COST_FLAG)
                    Else
                        occur_error = True

                    End If

                    If error_msg.Length < 1 Then
                        error_msg = "新增成功"

                    End If
                    dt.Rows.Add(P_PROD_RULE_CN, P_ORG, P_COST_CENTER, P_INCLUDE, P_COST_FLAG, P_GOLD_FLAG, P_PRODUCT_NUM, error_msg)

                    row = row + 1

                Loop


            Catch ex As Exception

                Response.Write("<script>console.log('" & ex.Message.Replace("'", "-") & "')</script>")

                vResult = False

                Throw ex
            Finally
                ReleaseExcel()
                PublicM.KillProcess("EXCEL", starttime, endtime)
                dg.DataSource = dt
                ViewState("tempDT") = dt
                dg.DataBind()


            End Try

            Return vResult
        End Function
        Protected Sub btn_export_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_export.Click
            Response.Write("<script>window.open('ONL/" + EXPORT_EXCEL() + ".xls')</script>")
            'Response.Write("<script>window.open('ONL_Template/" + EXPORT_TEST() + ".xls')</script>")
        End Sub

        Function EXPORT_TEST() As String
            System.Diagnostics.Debug.WriteLine("PROD_RULE:")
            Return "test"

        End Function



        Function EXPORT_EXCEL() As String
            'ByVal dt As System.Data.DataTable
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing


            Dim dt As System.Data.DataTable
            dt = CType(ViewState("tempDT"), System.Data.DataTable)
            'debug
            If dt Is Nothing Then
                System.Diagnostics.Debug.WriteLine("dt is null")
            Else
                System.Diagnostics.Debug.WriteLine("dt not null")
            End If

            System.Diagnostics.Debug.WriteLine("dt:" + dt.Rows.Count.ToString)


            '202205 kevin_A 針對每一種上傳、下載格式去新增template EXCEL的做法感覺很不好
            '既然可以操作excel,應該直接用程式寫入title,但對excel application的操作項不夠熟
            '目前受限於用open開template活頁簿,若能直接創一個新的應該就能成,待找..

            '202205 Kevin_A 使用空白公版的折衷作法,以後統一用這份空白的做..
            Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_TEMPLATE.xls"
            Dim fileNameTmp As String = "ONL_PROD_ERROR_" + Context.User.Identity.Name
            Dim savepath As String = Server.MapPath("~") & "\ONL\" + fileNameTmp + ".xls"

            Try
                '定義一個新的工作簿

                oBooks = oExcel.Workbooks

                oBooks.Open(sTemplate)

                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                '填充資料

                Dim y As Integer
                Dim i As Integer = dt.Rows.Count
                Dim z As Integer
                Dim j As Int16 = 0

                For z = 0 To dt.Columns.Count - 1

                    Select Case z
                        Case "0"
                            ''oCells.Font.Background = ""

                            ' oCells(1, z).Font.Color = "65535"

                            oCells(1, z + 1) = "執行結果"

                        Case "1"
                            oCells(1, z + 1) = "料號"
                        Case "2"
                            oCells(1, z + 1) = "料號規則"

                        Case "3"
                            oCells(1, z + 1) = "廠別"
                        Case "4"
                            oCells(1, z + 1) = "成本中心"
                        Case "5"
                            oCells(1, z + 1) = "選取Y/排除N"
                        Case "6"
                            oCells(1, z + 1) = "成本計算Y/N"
                        Case "7"
                            oCells(1, z + 1) = "金鹽Y/N"



                    End Select


                Next

                For y = 0 To dt.Columns.Count - 1
                    Select Case dt.Columns(y).ColumnName

                        Case "RESULT"

                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 1) = dt.Rows(i).Item("RESULT").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 2) = dt.Rows(i).Item("PRODUCT_NUM").ToString
                                j = j + 1
                            Next


                        Case "PROD_RULE"
                            j = 0
                            For i = 0 To i - 1
                                System.Diagnostics.Debug.WriteLine("PROD_RULE:" + dt.Rows(i).Item("PROD_RULE").ToString)

                                oCells(j + 2, 3) = dt.Rows(i).Item("PROD_RULE").ToString
                                j = j + 1
                            Next
                        Case "ORG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 4) = dt.Rows(i).Item("ORG").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 5) = dt.Rows(i).Item("COST_CENTER").ToString
                                j = j + 1
                            Next

                        Case "INCLUDE"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 6) = dt.Rows(i).Item("INCLUDE").ToString
                                j = j + 1
                            Next
                        Case "COST_FLAG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 7) = dt.Rows(i).Item("COST_FLAG").ToString
                                j = j + 1
                            Next

                        Case "GOLD_FLAG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 8) = dt.Rows(i).Item("GOLD_FLAG").ToString
                                j = j + 1
                            Next

                       



                    End Select
                Next
                oCells.Columns.AutoFit() '自動調整大小


                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                Return fileNameTmp
            Catch ex As Exception
                Alert("轉入發生異常." + ex.ToString, Me)
                System.Diagnostics.Debug.WriteLine("轉入發生異常:" + ex.ToString)

            Finally
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If


                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If



            End Try
            Return fileNameTmp

        End Function
       


#Region "ReleaseExcel:釋放Excel資源"
        Sub ReleaseExcel()
            Try
                oExcel.Quit()
                ReleaseExcelObject(oCells)
                ReleaseExcelObject(oSheet)
                ReleaseExcelObject(oSheets)
                ReleaseExcelObject(oBook)
                ReleaseExcelObject(oBooks)
                ReleaseExcelObject(oExcel)

            Catch ex As Exception
                Throw ex
            Finally
                GC.Collect()
            End Try
        End Sub
#End Region

#Region "ReleaseExcelObject: 釋放轉出Excel用到的物件"
        Sub ReleaseExcelObject(ByVal o As Object)
            Try
                If Not o Is Nothing Then
                    Marshal.ReleaseComObject(o)
                End If
            Finally
                o = Nothing
            End Try
        End Sub
#End Region


        
       
    End Class

End Namespace

