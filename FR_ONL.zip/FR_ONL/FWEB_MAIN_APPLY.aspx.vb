Namespace FR

Partial Class FWEB_MAIN_APPLY
    Inherits System.Web.UI.Page

    Public imageurl As String  '�Ϥ��۹���|
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        imageurl = Request.ApplicationPath & "/Image/"
    End Sub

End Class

End Namespace
