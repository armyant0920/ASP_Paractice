﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Collections;
using System.Web.Script.Serialization;
using DB;
using PublicUMethod;






public partial class Controller : System.Web.UI.Page
{
    public class DateRange {

        public string start_date { get; set; }

        public string end_date { get; set; }
    
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        //string path = Server.UrlDecode(Request.QueryString["path"]);//靠居然是方括號
        
        /*
        固定從ajax傳送的request中取得以下三個參數
              
         */
        string cmd = Request.Params["cmd"].ToString();//根據不同cmd執行對應CURD
        string target = Request.Params["target"].ToString();//根據不同cmd執行對應CURD
                       
        switch (cmd) { 
        
            case "S":
                selectMethod(target);
                break;
            case "U":
                break;

            case "C":
                break;
            case "D":
                break;
                             
        }
       
        end();

    }
    /// <summary>
    /// 查詢共用method
    /// </summary>
    /// <param name="type"></param>
    private void selectMethod(string target) {

        string sql = "";        
        switch(target){

            case "cost":
                sql=costQuery();
                
                break;
            case "edtDate":
                sql = edtDateQuery();
                break;
            case "periodQuery":
                sql=periodQuery();
                break;
            case "period_moth":
                sql = period_moth();
                break;
            case "getInfo":
                sql = InfoQuery();
                break;
            default:
                break;
        
        }

        queryResult(sql);
       
    }

    private void defaultQuery() { 
   
    
    }

    /// <summary>
    /// 回傳指定SQL回傳之DataTable
    /// </summary>
    /// <param name="sql"></param>
    /// <returns></returns>
    private DataTable getDataTable(string sql) {
        OleDbConnection conn = new OleDbConnection(System.Configuration.ConfigurationManager.AppSettings["conn"].ToString());
        OleDbDataAdapter da = new OleDbDataAdapter(sql, conn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
         
    }
    /// <summary>
    ///回傳query結果,回傳資料型態為序列化的list,內容為以Dictionary<string,string>儲存的欄位名稱&值
    ///
    /// </summary>
    /// <param name="sql"></param>
    private void queryResult(string sql) {
        OleDbConnection conn = new OleDbConnection(System.Configuration.ConfigurationManager.AppSettings["conn"].ToString());
        OleDbDataAdapter da = new OleDbDataAdapter(sql, conn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        ArrayList list = new ArrayList();
        for (int i = 0; i < dt.Rows.Count; i++)
        {

            Dictionary<string, string> data = new Dictionary<string, string>();
            for (int j = 0; j < dt.Columns.Count; j++)
            {
                string title = dt.Columns[j].ColumnName;
                data.Add(title, dt.Rows[i][title].ToString());
            }
            list.Add(data);
            foreach (var entry in data)
            {
                System.Diagnostics.Debug.WriteLine("key=" + entry.Key + " value=" + entry.Value);
            }

        }

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        string ret = serializer.Serialize(list);//將資料序列化->for json
        Response.Write(ret);//把list丟給前端
        
        
    
    }
    /// <summary>
    /// 回傳成本中心查詢SQL
    /// </summary>
    private string costQuery() {
        string facid = Request.Params["facid"].ToString();
        string sql = "SELECT DISTINCT B.COST_CENTER, B.COST_CENTER_NAME  from FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B WHERE A.ORG = '" + facid + "'  AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER order by B.COST_CENTER ";
        return sql;        
    }


    private string edtDateQuery()
    {
        string qijian = Request.Params["qijian"].ToString();

        string sql = "SELECT to_char(A.START_DATE,'yyyy/mm/dd')START_DATE,to_char(A.END_DATE,'yyyy/mm/dd')END_DATE FROM FWEB_ONL_CALENDAR A WHERE A.ORG = '" + qijian + "' AND A.CLOSE_DATE IS NULL";
        return sql;
    }


    private string periodQuery() {

        string qijian = Request.Params["qijian"].ToString();
        return  "SELECT to_char(A.period_moth,'yyyy/mm/dd')period_moth FROM FWEB_ONL_CALENDAR A WHERE A.ORG = '" + qijian + "' AND A.CLOSE_DATE IS NULL";
        
    }

    private string period_moth()
    {
        string facid = Request.Params["facid"].ToString();
        return "SELECT to_char(A.period_moth,'yyyy/MM/dd')period_moth FROM FWEB_ONL_CALENDAR A WHERE A.ORG = '" + facid + "' AND A.CLOSE_DATE IS NOT NULL order by period_moth desc";
    }

    /// <summary>
    /// 2022/03/22 舊版IE此功能似乎就有問題,暫不處理
    /// 
    /// </summary>
    /// <returns></returns>
    private string InfoQuery() {

        string strorg = Request.Params["org"].ToString();
        string strperiod_name = Request.Params["period_name"].ToString();
        string strTRANSACTION_TYPE = Request.Params["TRANSACTION_TYPE"].ToString();
        string strcost_center = Request.Params["cost_center"].ToString();
        string strproduct_num = Request.Params["product_num"].ToString();
        string sql="select  FWEB_ONL_PREONHAND('"+ strorg + "',to_date('" + strperiod_name + "','yyyy/MM/dd'),'" + strTRANSACTION_TYPE + "','"
            + strcost_center + "','" + strproduct_num + "') as PREONHAND, "
            +" FWEB_ONL_WASTEQTY('" + strorg + "',to_date('" + strperiod_name + "','yyyy/MM/dd'),'" + strTRANSACTION_TYPE + "','" + strcost_center + "','" + strproduct_num + "') as WASTEQTY from dual";
        return sql;
    }

    /// <summary>
    /// 還不清楚結束段有那些共同事件可以處理,
    /// 但應該會需要擴充,故先拉出來為一個method
    /// </summary>
    private void end() {
        Response.End();
    }

}