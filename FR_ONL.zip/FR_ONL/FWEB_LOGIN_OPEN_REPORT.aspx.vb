Imports System.Data
Imports System.Data.OleDb


Namespace FR

Partial Class FWEB_LOGIN_OPEN_REPORT
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            LoadDate()            
        End If
    End Sub

#Region "��l�ƴ���"
    '����
    Sub LoadDate()
        Dim sqlstr As String
        Dim ds As New DataSet
        sqlstr = "SELECT ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-1) AS PERIOD_MOTH " & _
                 "  FROM DUAL "
        ds = db.FillDataSet(sqlstr)
        txtPeriodMoth.Value = ds.Tables(0).Rows(0).Item("PERIOD_MOTH")
    End Sub
#End Region

#Region "ExecSP:����StoreProcedure"
        Function ExecSP(ByVal OpenSystNo As String) As Boolean
            Dim cmd As New OleDbCommand
            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_OPEN_REPORT_SP1"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn
                    cmd.Parameters.Add(New OleDbParameter("P_MOTH", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_SYST_NO", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_USER_ID", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_MESSAGE", OleDbType.VarChar, 100)).Direction = ParameterDirection.Output

                    cmd.Parameters("P_MOTH").Value = txtPeriodMoth.Value
                    cmd.Parameters("P_SYST_NO").Value = OpenSystNo
                    cmd.Parameters("P_USER_ID").Value = Context.User.Identity.Name
                    cmd.Parameters("P_MESSAGE").Value = ""

                    cmd.ExecuteNonQuery()

                    Dim V_Message As String = cmd.Parameters("P_MESSAGE").Value.ToString
                    If V_Message <> "" Then
                        Response.Write("<script>alert('" & V_Message.Replace("'", "-").Replace("\n", "").Replace("\r", "") & "')</script>")
                        Return False
                    Else
                        Return True
                    End If

                Catch ex As Exception
                    Response.Write("<script>alert('" & ex.Message.Replace("'", "-").Replace("\n", "").Replace("\r", "") & "')</script>")
                    Return False
                Finally
                    cn.Close()
                End Try
            End If
            Return True
        End Function
#End Region

    '�d��
    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
        Dim ds As New DataSet
        Dim sqlstr As String
        sqlstr = "SELECT TO_CHAR(R.PERIOD_MOTH,'YYYY/MM/DD') AS PERIOD_MOTH, R.SYST_NO, D.KIND_NAME AS SYST_NAME, " & _
                 "       R.ISOPEN, R.MDATE, R.MUSER " & _
                 "  FROM FWEB_OPEN_REPORT R, " & _
                 "       (SELECT * FROM FWEB_BASE_CODE_D " & _
                 "         WHERE SYST_NO = 'FWEB' " & _
                 "           AND PROJ_NO = 'LOGIN' " & _
                 "           AND CLASS_NO = 'OPEN_REPORT') D " & _
                 " WHERE R.PERIOD_MOTH = TRUNC(TO_DATE('" + txtPeriodMoth.Value + "','YYYY/MM/DD'),'MONTH') " & _
                 "   AND R.SYST_NO = D.KIND_NO(+) "

        dg.CurrentPageIndex = 0
        ds = db.FillDataSet(sqlstr)
        dg.DataSource = ds.Tables(0)
        dg.DataBind()
    End Sub

    '�O�_�}�����
    Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
        Dim sqlstr As String

        If e.CommandName.ToUpper = "OPEN" Then  '�}�����

            sqlstr = "UPDATE FWEB_OPEN_REPORT " & _
                     "   SET ISOPEN = 'Y', MDATE = SYSDATE, MUSER = '" + Context.User.Identity.Name + "'" & _
                     " WHERE PERIOD_MOTH = TRUNC(TO_DATE('" + txtPeriodMoth.Value + "','YYYY/MM/DD'),'MONTH') " & _
                     "   AND SYST_NO = '" + e.Item.Cells(3).Text + "'"

            Try
                db.ExecuteSQL(sqlstr)
                ExecSP(e.Item.Cells(3).Text)  '����StoreProcedure   
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�w�קאּ�}������I');</script>")
                Catch ex As Exception
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�}��������ѡI');</script>")
                End Try

            ElseIf e.CommandName.ToUpper = "NOTOPEN" Then '���}�����

                sqlstr = "UPDATE FWEB_OPEN_REPORT " & _
                         "   SET ISOPEN = 'N', MDATE = SYSDATE, MUSER = '" + Context.User.Identity.Name + "'" & _
                         " WHERE PERIOD_MOTH = TRUNC(TO_DATE('" + txtPeriodMoth.Value + "','YYYY/MM/DD'),'MONTH') " & _
                         "   AND SYST_NO = '" + e.Item.Cells(3).Text + "'"

                Try
                    db.ExecuteSQL(sqlstr)
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�w�קאּ���}������I');</script>")
                Catch ex As Exception
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���}��������ѡI');</script>")
                End Try

            End If

            '���s�d��
            Dim sender As System.Object
            Dim ee As System.EventArgs
            btnQuery_Click(sender, ee)
        End Sub

        Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
                CType(e.Item.Cells(1).FindControl("linkbtOpen"), LinkButton).Attributes.Add("onclick", "return loading();")
            End If
        End Sub

        '�s�W
        Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
            Dim ds As New DataSet
            Dim sqlstr As String
            sqlstr = "SELECT R.*, D.KIND_NAME AS SYST_NAME " & _
                     "  FROM FWEB_OPEN_REPORT R, " & _
                     "       (SELECT * FROM FWEB_BASE_CODE_D " & _
                     "         WHERE SYST_NO = 'FWEB' " & _
                     "           AND PROJ_NO = 'LOGIN' " & _
                     "           AND CLASS_NO = 'OPEN_REPORT') D " & _
                     " WHERE R.PERIOD_MOTH = TRUNC(TO_DATE('" + txtPeriodMoth.Value + "','YYYY/MM/DD'),'MONTH') " & _
                     "   AND R.SYST_NO = D.KIND_NO(+) "

            dg.CurrentPageIndex = 0
            ds = db.FillDataSet(sqlstr)

            If ds.Tables(0).Rows.Count = 0 Then

                Dim sqlstr1 As String
                sqlstr1 = "INSERT INTO FWEB_OPEN_REPORT " & _
                          "      (PERIOD_MOTH, SYST_NO, ISOPEN, MDATE, MUSER) " & _
                          "SELECT TRUNC(TO_DATE('" + txtPeriodMoth.Value + "','YYYY/MM/DD'),'MONTH'), " & _
                          "       D.KIND_NO AS SYST_NO, 'N', " & _
                          "       SYSDATE, '" + Context.User.Identity.Name + "'" & _
                          "  FROM FWEB_BASE_CODE_D D " & _
                          " WHERE D.SYST_NO = 'FWEB' " & _
                          "   AND D.PROJ_NO = 'LOGIN' " & _
                          "   AND D.CLASS_NO = 'OPEN_REPORT' "

                Try
                    db.ExecuteSQL(sqlstr1)
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�s�W���\�I');</script>")
                Catch ex As Exception
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�s�W���ѡI');</script>")
                End Try

            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ӵ��w����ƵL�k�s�W�I');</script>")
            End If
        End Sub

        Private Sub btnSendMail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendMail.Click
            Dim ds As New DataSet
            Dim sqlstr As String
            Dim strmailto As String = ""
            Dim i As Integer

            '���X�����
            sqlstr = "SELECT DISTINCT B.E_MAIL " & _
                     "  FROM FWEB_USER_GROUP A, " & _
                     "       FWEB_USER_LOGIN_M B " & _
                     " WHERE A.SYST_NO = 'FWEB' " & _
                     "   AND A.PROJ_NO = 'ROS' " & _
                     "   AND A.GROUP_NO IN ('ALERT01') " & _
                     "   AND A.USER_ID = B.USER_ID "

            ds = db.FillDataSet(sqlstr)
            For i = 0 To ds.Tables(0).Rows.Count - 1
                strmailto = strmailto + ds.Tables(0).Rows(i).Item("E_MAIL") + ";"
            Next

            '���ͷs�l��
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "creatmail", "<script>createmail('" + strmailto + "');</script>")
        End Sub

End Class

End Namespace
