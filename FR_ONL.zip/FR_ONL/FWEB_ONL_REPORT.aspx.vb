Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices


Namespace FR

Partial Class FWEB_ONL_REPORT
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        If Not Page.IsPostBack Then
            Load_Org()
            Load_Cost()
            Load_Month()
            Lbl_ActionFlag.Text = "QUERY"
            Init_Data()
            SetDisplay()
        End If
    End Sub
    Private Sub Init_Data()
       ddlORG.SelectedIndex = -1
       ddlCostCenter.SelectedIndex = -1
       ddlBeginDate.SelectedIndex = -1
       ddlEndDate.SelectedIndex = -1
       txtOrg.Text = ""
       txtCostCenter.Text = ""
    End Sub

    Sub Load_Org()
        '�t�OddlOrg
        Dim SQL As String = ""
        SQL = " SELECT DISTINCT A.ORG AS ID, A.ORG|| ' ' || B.ORG_NAME AS NAME " & vbNewLine & _
              " FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
              " WHERE A.ORG = B.ORG AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
              " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) " & vbNewLine & _
              " ORDER BY A.ORG "
        GetddlDownList(SQL, ddlORG, "NCST2")
    End Sub

    Sub Load_Cost()
        '��������ddlCostCenter
        Dim SQL As String = ""
        SQL = " SELECT DISTINCT A.COST_CENTER AS ID, A.COST_CENTER || ' ' || B.COST_CENTER_NAME AS NAME " & vbNewLine & _
              " FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
              " WHERE A.ORG = '" & ddlORG.SelectedValue.ToString & "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
              " AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
              " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER)  " & _
              " ORDER BY A.COST_CENTER "
        GetddlDownList(SQL, ddlCostCenter, "NCST2")
    End Sub

    Sub Load_Month()
        '����
        Dim SQL As String = ""
        SQL = "SELECT TO_CHAR(START_DATE,'YYYY/MM/DD') AS ID, TO_CHAR(START_DATE,'YYYY/MM/DD') AS NAME " & vbNewLine & _
              "FROM UCCST_CALENDAR_T WHERE START_DATE>= ADD_MONTHS(SYSDATE,-13) " & vbNewLine & _
              "ORDER BY START_DATE DESC " & vbNewLine
        GetddlDownList(SQL, ddlBeginDate, "NCST2")
        GetddlDownList(SQL, ddlEndDate, "NCST2")
    End Sub

    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
            '�d��
        Lbl_ActionFlag.Text = "QUERY"
            SetQueryViewState()
            'Response.Write("<script>window.open(' " + ViewState("sqltxt") + " ')</script>")
        Me.dg.CurrentPageIndex = 0
        Load_Data(viewstate("sqltxt"))
    End Sub

        Sub Load_Data(ByVal sqlcmd As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            Try

               dg.DataSource = Nothing
               dg.DataBind()

               ds = db.FillDataSet(sqlcmd, 2)
               dv = ds.Tables(0).DefaultView
               dg.DataSource = dv
               dg.DataBind()
               'GetPageInfo()
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not dv Is Nothing Then
                 dv.Dispose()
              End If
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End try
        End Sub

    Sub SetQueryViewState()
        '�d��Query��JViewState�A�H�K�H�ɥi���sQuery
        Dim StrSQL As String = ""
        StrSQL = "SELECT to_char(T.PERIOD_NAME,'yyyy/MM/dd') as PERIOD_NAME,T.ORG,t.TRANSACTION_TYPE,T.COST_CENTER,M.COST_CENTER_NAME " & vbNewLine & _
                 ",T.BONDED_FLAG,T.PRODUCT_NUM,t.PRODUCT_DESC,T.UOM,T.PRE_ONHAND " & vbNewLine & _
                 ",T.NOW_WASTE,T.NOW_ONHAND,T.BONDED_NOW_ONHAND,T.CHECK_ONHAND,T.REMARK " & vbNewLine & _
                 ",T.IMPORT_MARK,T.IMPORT_USER,T.APPROVE_MARK,T.APPROVE_USER,NVL(T.COST_FLAG,'Y') AS COST_FLAG" & vbNewLine & _
                 ",T.IMPORT_DATE,APPROVE_DATE " & vbNewLine & _
                 "FROM FWEB_ONL_ONHAND T,FWEB_COST_CENTER_V M,FWEB_USER_ORGAU_D O  " & vbNewLine & _
                 "WHERE(T.ORG = M.ORG And T.COST_CENTER = M.COST_CENTER) " & vbNewLine & _
                 "AND T.ORG = DECODE(O.ORG,'ALL',T.ORG,O.ORG) " & vbNewLine & _
                 "AND T.COST_CENTER = DECODE(O.COST_CENTER,'ALL',T.COST_CENTER,O.COST_CENTER)" & vbNewLine & _
                 "AND (O.SYST_NO = 'FWEB' OR O.SYST_NO = 'ONL') " & vbNewLine & _
                 "AND (O.PROJ_NO = 'ONL' OR O.PROJ_NO = 'ONL') " & vbNewLine & _
                 "AND O.USER_ID = '" & Context.User.Identity.Name & "'" & vbNewLine & _
                 "AND T.PERIOD_NAME between to_date('" & ddlBeginDate.SelectedValue.ToString & "','yyyy/mm/dd') " & vbNewLine & _
                 "                      and last_day(to_date('" & ddlEndDate.Text.ToString & "','yyyy/mm/dd'))+0.99999 " & vbNewLine & _
                 "AND T.ORG =  DECODE('" & ddlORG.SelectedValue.ToString & "','',T.ORG,'" & ddlORG.SelectedValue.ToString & "') " & vbNewLine & _
                 "AND T.COST_CENTER = DECODE('" & ddlCostCenter.SelectedValue.ToString & "','',T.COST_CENTER ,'" & ddlCostCenter.SelectedValue.ToString & "')  " & vbNewLine
        Dim sqltxt As String = StrSQL
        viewstate("sqltxt") = sqltxt

    End Sub

    Sub GetPageInfo()
        '�`�p����
        Dim sqlcmd As String = "SELECT COUNT(*) "
        Dim RecordCount As String = db.GetExecuteScalar(sqlcmd & viewstate("sqltxt2")).ToString
        Label9.Text = "�@<font face=verdana >" + RecordCount + "</font>���O��<font face=verdana >"
    End Sub

    Private Sub dg_PageIndexChanged(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs)
        '����
        dg.CurrentPageIndex = e.NewPageIndex
        Load_Data(viewstate("sqltxt"))
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '�s�W
        Lbl_ActionFlag.Text = "ADD"
        SetDisplay()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        '����
        Lbl_ActionFlag.Text = "QUERY"
        SetDisplay()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        '�x�s
            Dim sqlcmd As String = ""
        Try
            db.ExecuteSQL(sqlcmd)
        Catch ex As Exception
            Throw ex
            Exit Sub
        End Try
        Lbl_ActionFlag.Text = "QUERY"
        SetDisplay()
        Load_Data(viewstate("sqltxt"))
    End Sub

    Private Sub dg_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        'DataGridView���C�@��Record��Delete�]�wLinkButton
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btnDELETE"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        'DataGridView���C�@��Record�]�wcurrentcolor
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub dg_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        If e.CommandName = "DELETE" Then     '�R��            
            Dim sqlcmd As String
            sqlcmd = "DELETE FROM FWEB_ONL_PROD WHERE PROD_RULE = '" + e.Item.Cells(1).Text.Trim + "' AND ORG ='" + e.Item.Cells(3).Text.Trim + "' " & _
                     "AND COST_CENTER = '" + e.Item.Cells(4).Text.Trim + "' AND INCLUDE = '" + e.Item.Cells(6).Text.Trim + "' AND PRODUCT_NUM = '" + e.Item.Cells(7).Text.Trim + "'"
            Try
                db.ExecuteSQL(sqlcmd)
            Catch ex As Exception
                Throw ex
            Finally
                Lbl_ActionFlag.Text = "QUERY"
                Load_Data(viewstate("sqltxt"))
            End Try
        End If
    End Sub

    Function Check_Data() As Boolean
        'Check
        Dim ErrCount As Int16 = 0
        Dim sqlcmd As String
        '�Ƹ��W�h�г]�Ƹ��Ĥ@�X/�Ƹ����X
        If ErrCount = 0 And ddlBeginDate.SelectedIndex < 1 Or ddlEndDate.SelectedIndex < 1 Then
            ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������i����!');</script>")
            End If
            '�t�O���i����
            If ErrCount = 0 And txtOrg.Text = "" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
            End If
            '�������ߤ��i����
            If ErrCount = 0 And txtCostCenter.Text = "" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������ߤ��i����!');</script>")
            End If
            '�O�_���u�W���s�i�L�I�t�O
            If (ErrCount = 0) And txtOrg.Text <> "" Then
                sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG = DECODE('" & txtOrg.Text.ToString & "','ALL',ORG,'" & txtOrg.Text.ToString & "')"
                If db.GetExecuteScalar(sqlcmd) = 0 Then
                    ErrCount = ErrCount + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���~�A�Э��s��J (���O�u�W���s�i�L�I�t�O) !');</script>")
                End If
            End If
            '�O�_���u�W���s�i�L�I��������
            If (ErrCount = 0) And txtOrg.Text.ToString <> "" Then
                sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG = DECODE('" & txtOrg.Text.ToString & "','ALL',ORG,'" & txtOrg.Text.ToString & "') AND COST_CENTER = DECODE('" & txtCostCenter.Text.ToString & "','ALL',COST_CENTER,'" & txtCostCenter.Text.ToString & "')"
                If db.GetExecuteScalar(sqlcmd) = 0 Then
                    ErrCount = ErrCount + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������߿��~�A�Э��s��J (���O�u�W���s�i�L�I��������)!');</script>")
                End If
            End If
        'Err
        If ErrCount > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Sub SetDisplay()

        If Lbl_ActionFlag.Text = "ADD" Then    '�s�W

        ElseIf Lbl_ActionFlag.Text = "QUERY" Then '�s��
            '���s���A
            btnSave.Enabled = False
            btnCancel.Enabled = False
            '����
            ddlBeginDate.BackColor = ColorTranslator.FromHtml("#E0FFFF")
            ddlEndDate.BackColor = ColorTranslator.FromHtml("#E0FFFF")
            '�t�O
            txtOrg.Enabled = False
            txtOrg.Text = ""
            'Load_Org()
            txtOrg.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
            ddlORG.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
            '��������
            txtCostCenter.Enabled = False
            txtCostCenter.Text = ""
            'Load_Cost()
            txtCostCenter.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
            ddlCostCenter.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
        End If
    End Sub

    Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
        '��Excel
        Response.Write("<script>window.open('ONL/" + EXPORT_EXCEL() + ".xls')</script>")
    End Sub

    Function EXPORT_EXCEL() As String
        Dim oExcel As New Excel.Application
        Dim oBooks As Excel.Workbooks = Nothing
        Dim oBook As Excel.Workbook = Nothing
        Dim oSheets As Excel.Sheets = Nothing
        Dim oSheet As Excel.Worksheet = Nothing
        Dim oCells As Excel.Range = Nothing
        Dim ds As New DataSet
        Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_REPORT.xls"
        Dim fileNameTmp As String = "ONL_REPORT" + context.User.Identity.Name
        Dim savepath As String = Server.MapPath("~") & "\ONL\" + fileNameTmp + ".xls"

        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

            '��R���
            ds = db.FillDataSet(ViewState("sqltxt"), 2)
            Dim x, y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "PERIOD_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("PERIOD_NAME").ToString
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("ORG").ToString
                            j = j + 1
                        Next
                    Case "TRANSACTION_TYPE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 4) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "COST_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 5) = ds.Tables(0).Rows(x).Item("COST_NAME").ToString
                            j = j + 1
                        Next
                    Case "BONDED_FLAG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 6) = ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_NUM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_DESC"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                            j = j + 1
                        Next
                    Case "UOM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString
                            j = j + 1
                        Next
                    Case "PRE_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "NOW_WASTE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString
                            j = j + 1
                        Next
                    Case "NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "BONDED_NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "CHECK_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("CHECK_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "REMARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 15) = ds.Tables(0).Rows(x).Item("REMARK").ToString
                            j = j + 1
                        Next
                    Case "IMPORT_USER" '��J�H��
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 16) = ds.Tables(0).Rows(x).Item("IMPORT_USER").ToString
                            j = j + 1
                        Next
                    Case "IMPORT_DATE" '��J�ɶ�
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 17) = ds.Tables(0).Rows(x).Item("IMPORT_DATE").ToString
                            j = j + 1
                        Next
                    Case "IMPORT_MARK" '�O�_�w�ߪ���
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 18) = ds.Tables(0).Rows(x).Item("IMPORT_MARK").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_MARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 19) = ds.Tables(0).Rows(x).Item("APPROVE_MARK").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_USER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 20) = ds.Tables(0).Rows(x).Item("APPROVE_USER").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_DATE" '����APPROVE�ɶ�
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 21) = ds.Tables(0).Rows(x).Item("APPROVE_DATE").ToString
                            j = j + 1
                        Next
                    Case "COST_FLAG" '20130311 ADD �O�_�JMTL����
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 22) = ds.Tables(0).Rows(x).Item("COST_FLAG").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            Return fileNameTmp
        Catch ex As Exception
            Throw ex
        Finally
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If


            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If

            If Not ds Is Nothing Then
               ds.Dispose()
            End If
            'GC.Collect()

        End Try
    End Function

    Private Sub ddlORG_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlORG.SelectedIndexChanged
         Try
            txtOrg.Text = ddlORG.SelectedValue.ToString
            txtCostCenter.Text = ""
            ddlCostCenter.SelectedIndex = -1
            Load_Cost()

         Catch ex As Exception
             Alert(ex.ToString, Me)
         End Try
    End Sub

    Private Sub ddlCostCenter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCostCenter.SelectedIndexChanged
        Try
           txtCostCenter.Text = ddlCostCenter.SelectedValue.ToString
        Catch ex As Exception
           Alert(ex.ToString, Me)
        End Try
    End Sub
End Class

End Namespace
