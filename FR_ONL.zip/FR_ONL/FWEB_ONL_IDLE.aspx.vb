﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices


Namespace FR



    Partial Class FWEB_ONL_IDLE
        Inherits System.Web.UI.Page
        Dim sql As String




        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            '在這裡放置使用者程式碼以初始化網頁
            Dim id As String
            Dim i As Integer

            For i = 0 To Session.Keys.Count - 1

                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>console.log('session=" + Session.Keys(i) + "');</script>")
                i = i + 1

            Next



            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>console.log('sessionid=" + Session.SessionID + "');</script>")

            Load_Cost()
            Me.cmb_cost_name.Value = Me.txt_cost_center.Value


            If Not Page.IsPostBack Then
                Load_Org()
                Me.cmb_org_name.Value = Me.txt_org.Value
                Load_Cost()
                'Load_Period()
                Session("USER_ID") = (New Check.APPT_IsAccess).ConfirmUser(Page, System.Configuration.ConfigurationManager.AppSettings("service_uri").ToString())
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>console.log('USER_ID=" + Session("USER_ID") + "');</script>")

                'SetDisplay()
            ElseIf txt_org.Value <> "" Then
                Load_Period()
                Me.period_list.Value = Me.input_period.Value


                'Me.cmb_cost_name.Value = Me.txt_cost_center.Value
                'Load_Cost()
                'Load_Period()

            End If
        End Sub
        Sub Load_Period()
            Dim sql As String
            Dim org As String
            Dim ds As New DataSet
            org = txt_org.Value.Trim
            sql = "select to_char(period_moth,'yyyy/MM/dd') period_moth from fweb_onl_calendar where org='" + org + "' and close_date is not null order by period_moth desc"
            Try
                System.Diagnostics.Debug.WriteLine("period sqltxt:" + sql)
                ds = db.FillDataSet(sql, 2)
                period_list.DataSource = ds.Tables(0)
                period_list.DataValueField = "period_moth"
                period_list.DataTextField = "period_moth"
                period_list.DataBind()
                '插入空白項
                period_list.Items.Insert(0, "")
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
            




        End Sub
        Sub Load_Org()
            '廠別
            Dim sqlcmd As String
            Dim TempDS As New DataSet
            Try

                sqlcmd = " SELECT * FROM (SELECT 'ALL' AS ORG, 'ALL' AS ORG_NAME FROM DUAL UNION ALL " & _
                         " SELECT DISTINCT A.ORG AS ORG,B.ORG_NAME AS ORG_NAME FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                         " WHERE A.ORG = B.ORG  AND C.SYST_NO = 'FWEB' " & _
                         " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ) T ORDER BY T.ORG "

                'sqlcmd = " SELECT * FROM (SELECT 'ALL' AS ORG, 'ALL' AS ORG_NAME FROM DUAL UNION ALL " & _
                '" SELECT DISTINCT A.ORG AS ORG,B.ORG_NAME AS ORG_NAME FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                '" WHERE A.ORG = B.ORG AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                '" AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ) T ORDER BY T.ORG "
                TempDS = db.FillDataSet(sqlcmd, 2)
                cmb_org_name.DataSource = TempDS.Tables(0)
                cmb_org_name.DataValueField = "ORG"
                cmb_org_name.DataTextField = "ORG_NAME"
                cmb_org_name.DataBind()
                cmb_org_name.Items.Insert(0, "")

            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try

        End Sub
        Sub Load_Cost()
            '成本中心
            Dim sqlcmd As String
            Dim TempDS As New DataSet
            Try

                sqlcmd = " SELECT * FROM (SELECT 'ALL' AS COST_CENTER, 'ALL' AS COST_NAME FROM DUAL UNION ALL " & _
                         " SELECT DISTINCT A.COST_CENTER AS COST_CENTER, B.COST_CENTER_NAME AS COST_NAME FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                         " WHERE A.ORG = '" + txt_org.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                         "  AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
                         " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) ) T " & _
                         " ORDER BY T.COST_CENTER "
                'sqlcmd = " SELECT * FROM (SELECT 'ALL' AS COST_CENTER, 'ALL' AS COST_NAME FROM DUAL UNION ALL " & _
                '        " SELECT DISTINCT A.COST_CENTER AS COST_CENTER, B.COST_CENTER_NAME AS COST_NAME FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                '       " WHERE A.ORG = '" + txt_org.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                '      " AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
                '     " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) ) T " & _
                '    " ORDER BY T.COST_CENTER "
                TempDS = db.FillDataSet(sqlcmd, 2)
                cmb_cost_name.DataSource = TempDS.Tables(0)
                cmb_cost_name.DataValueField = "COST_CENTER"
                cmb_cost_name.DataTextField = "COST_NAME"
                cmb_cost_name.DataBind()
                cmb_cost_name.Items.Insert(0, "")

            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try

        End Sub



        Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
            Dim org = txt_org.Value.Trim
            Dim cost_center = txt_cost_center.Value.Trim

            Dim period = period_list.Value.ToString.Trim
            System.Diagnostics.Debug.WriteLine("org:" + org)
            System.Diagnostics.Debug.WriteLine("period:" + period)

            Dim sub1, sub2, sub3 As String
            sub1 = "select * from fweb_onl_onhand_V where org='" + org + "' and cost_center like '%" + cost_center + "%' and period_name =add_months(to_date('" + period + "','yyyy-MM-dd'),0)"
            sub2 = "select * from fweb_onl_onhand_V where org='" + org + "' and cost_center like '%" + cost_center + "%' and period_name =add_months(to_date('" + period + "','yyyy-MM-dd'),-1)"
            sub3 = "select * from fweb_onl_onhand_V where org='" + org + "' and cost_center like '%" + cost_center + "%' and period_name =add_months(to_date('" + period + "','yyyy-MM-dd'),-2)"

            sql = "select * from (select case when(c.now_onhand-b.now_onhand<0 or b.now_onhand-a.now_onhand<0 or(c.now_onhand=0 and b.now_onhand=0 and a.now_onhand=0)) then ''  else '*' end as 庫存未減少," & _
                  "case when (c.now_waste=0 and b.now_waste=0 and a.now_waste=0) then '*' else '' end as 庫存未領用," & _
                 "c.period_name,c.org,c.cost_center,c.product_num,c.product_desc,c.uom,c.now_onhand as 本月結存,c.now_waste as 本月領用," & _
                 "b.now_onhand as 上月結存,b.now_waste as 上月領用, " & _
                 "a.now_onhand as 前月結存,a.now_waste as 前月領用 " & _
                 "from (" + sub1 + ")c," & _
                 "(" + sub2 + ")b," & _
                 "(" + sub3 + ")a " & _
                 "where c.product_num=b.product_num and b.product_num=a.product_num and c.cost_center=b.cost_center and b.cost_center=a.cost_center )"

            System.Diagnostics.Debug.WriteLine("sqltxt:" + sql)




            Load_Data(sql)
            'Load_Data(ViewState("sqltxt"))
        End Sub


        Sub Load_Data(ByVal sqlcmd As String)
            Dim dt As New DataTable

            Try
                System.Diagnostics.Debug.WriteLine("Load_Data:" + sqlcmd)
                dg.Dispose()

                dt = db.FillDataSet(sqlcmd).Tables(0)

                dg.DataSource = dt
                dg.DataBind()
                ViewState("tempDT") = dt


            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not dt Is Nothing Then
                    dt.Dispose()
                End If

            End Try
        End Sub

        Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
            '換頁
            dg.CurrentPageIndex = e.NewPageIndex
            dg.DataSource = CType(ViewState("tempDT"), DataTable)
            dg.DataBind()

        End Sub

        Function readData() As DataTable
            Dim temp_dt As New DataTable


            Return temp_dt

        End Function


        'Protected Sub period_list_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles period_list.SelectedIndexChanged
        '    System.Diagnostics.Debug.WriteLine("select index changed:" + period_list.SelectedValue.ToString)
        'End Sub

        Protected Sub btnExcel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExcel.Click
            Response.Write("<script>window.open('ONL/" + EXPORT_EXCEL() + ".xls')</script>")
        End Sub

        Function EXPORT_EXCEL() As String
            'ByVal dt As System.Data.DataTable
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing


            Dim dt As System.Data.DataTable

            dt = CType(ViewState("tempDT"), System.Data.DataTable)
            'debug
            If dt Is Nothing Then
                System.Diagnostics.Debug.WriteLine("dt is null")
            Else
                System.Diagnostics.Debug.WriteLine("dt not null")
            End If

            System.Diagnostics.Debug.WriteLine("dt:" + dt.Rows.Count.ToString)


            Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_TEMPLATE.xls"
            Dim fileNameTmp As String = "ONL_IDLE_" + Context.User.Identity.Name
            Dim savepath As String = Server.MapPath("~") & "\ONL\" + fileNameTmp + ".xls"

            Try
                '定義一個新的工作簿

                oBooks = oExcel.Workbooks

                oBooks.Open(sTemplate)

                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                '填充資料

                Dim y As Integer
                Dim i As Integer = dt.Rows.Count
                Dim z As Integer
                Dim j As Int16 = 0

                For z = 0 To dt.Columns.Count - 1

                    Select Case z
                        Case "0"
                            oCells(1, z + 1) = "期間"
                        Case "1"
                            oCells(1, z + 1) = "廠別"
                        Case "2"
                            oCells(1, z + 1) = "成本中心"

                        Case "3"
                            oCells(1, z + 1) = "料號"
                        Case "4"
                            oCells(1, z + 1) = "品名規格"
                        Case "5"
                            oCells(1, z + 1) = "單位"
                        Case "6"
                            oCells(1, z + 1) = "本期結存"
                        Case "7"
                            oCells(1, z + 1) = "本期領用"

                        Case "8"
                            oCells(1, z + 1) = "上月結存"
                        Case "9"
                            oCells(1, z + 1) = "上月領用"
                        Case "10"
                            oCells(1, z + 1) = "前月結存"
                        Case "11"
                            oCells(1, z + 1) = "前月領用"
                        Case "12"
                            oCells(1, z + 1) = "庫存未領用"
                        Case "13"
                            oCells(1, z + 1) = "庫存未減少"


                    End Select


                Next

                For y = 0 To dt.Columns.Count - 1
                    Select Case dt.Columns(y).ColumnName

                        Case "PERIOD_NAME"

                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 1) = dt.Rows(i).Item("PERIOD_NAME").ToString
                                j = j + 1
                            Next
                        Case "ORG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 2) = dt.Rows(i).Item("ORG").ToString
                                j = j + 1
                            Next


                        Case "COST_CENTER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 3) = dt.Rows(i).Item("COST_CENTER").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 4) = dt.Rows(i).Item("PRODUCT_NUM").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_DESC"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 5) = dt.Rows(i).Item("PRODUCT_DESC").ToString
                                j = j + 1
                            Next

                        Case "UOM"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 6) = dt.Rows(i).Item("UOM").ToString
                                j = j + 1
                            Next
                        Case "本月結存"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 7) = dt.Rows(i).Item("本月結存").ToString
                                j = j + 1
                            Next

                        Case "本月領用"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 8) = dt.Rows(i).Item("本月領用").ToString
                                j = j + 1
                            Next
                        Case "上月結存"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 9) = dt.Rows(i).Item("上月結存").ToString
                                j = j + 1
                            Next
                        Case "上月領用"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 10) = dt.Rows(i).Item("上月領用").ToString
                                j = j + 1
                            Next
                        Case "前月結存"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 11) = dt.Rows(i).Item("前月結存").ToString
                                j = j + 1
                            Next
                        Case "前月領用"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 12) = dt.Rows(i).Item("前月領用").ToString
                                j = j + 1
                            Next
                        Case "庫存未領用"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 13) = dt.Rows(i).Item("庫存未領用").ToString
                                j = j + 1
                            Next
                        Case "庫存未減少"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 14) = dt.Rows(i).Item("庫存未減少").ToString
                                j = j + 1
                            Next

                    End Select
                Next
                oCells.Columns.AutoFit() '自動調整大小


                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                Return fileNameTmp
            Catch ex As Exception
                Alert("轉入發生異常." + ex.ToString, Me)
                System.Diagnostics.Debug.WriteLine("轉入發生異常:" + ex.ToString)

            Finally
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If


                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If



            End Try
            Return fileNameTmp

        End Function
    End Class
End Namespace

