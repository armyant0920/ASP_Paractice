Imports System.Data
Imports System.Data.OleDb
Imports System.Net.Mail


Namespace FR


Partial Class FWEB_ONLB_IMPORT_MAIL
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))

#Region "initial"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            Load_Calendar()
            Load_Org()
            Me.cmb_org_name.Value = Me.txt_org.Value
            Load_Cost()
        ElseIf txt_org.Value <> "" Then
            Load_Cost()
            Me.cmb_cost_name.Value = Me.txt_cost_center.Value
        End If
    End Sub

        Sub Load_Calendar()
            '����
            Dim sqlstr As String
            Dim ds As New DataSet
            sqlstr = "SELECT A.ORG,A.PERIOD_MOTH FROM FWEB_ONLB_CALENDAR A,(SELECT T.ORG FROM FWEB_USER_ORGAU_D O, FWEB_ONLB_DEPT T" & _
                     " WHERE O.USER_ID = '" + context.User.Identity.Name + "' AND O.SYST_NO = 'FWEB' AND O.PROJ_NO = 'ONLB' AND DECODE(O.ORG, 'ALL', T.ORG, O.ORG) = T.ORG " & _
                     " AND DECODE(O.COST_CENTER, 'ALL', T.COST_CENTER, O.COST_CENTER) = T.COST_CENTER AND ROWNUM = 1) B" & _
                     " WHERE A.ORG = B.ORG AND A.CLOSE_DATE IS NULL"
            ds = db.FillDataSet(sqlstr)
            If ds.Tables(0).Rows.Count <> 0 Then
                txt_org.Value = ds.Tables(0).Rows(0).Item("ORG")
                txt_period_name.Value = ds.Tables(0).Rows(0).Item("PERIOD_MOTH")
            End If
        End Sub

    Sub Load_Org()
        '�t�O
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.ORG AS ORG,B.ORG_NAME AS ORG_NAME FROM FWEB_ONLB_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = B.ORG AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                 " AND C.PROJ_NO = 'ONLB' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
        cmb_org_name.DataSource = db.FillDataSet(sqlstr)
        cmb_org_name.DataValueField = "ORG"
        cmb_org_name.DataTextField = "ORG_NAME"
        cmb_org_name.DataBind()
        cmb_org_name.Items.Insert(0, "")
    End Sub

    Sub Load_Cost()
        '��������
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.COST_CENTER AS COST_CENTER, B.COST_NAME AS COST_NAME FROM FWEB_ONLB_DEPT A, WMAP_EXP_COST@COST_PROD B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = '" + txt_org.Value.Trim + "' AND A.COST_CENTER = B.COST_ID " & _
                 " AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONLB' " & _
                 " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) " & _
                 " ORDER BY A.COST_CENTER "
        cmb_cost_name.DataSource = db.FillDataSet(sqlstr).Tables(0)
        cmb_cost_name.DataValueField = "COST_CENTER"
        cmb_cost_name.DataTextField = "COST_NAME"
        cmb_cost_name.DataBind()
        cmb_cost_name.Items.Insert(0, "")
    End Sub
#End Region

    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
        Dim sqltxt1 As String
        Dim sqltxt2 As String
        '�d��
        If Check_Data() = False Then
            Exit Sub
        End If
        sqltxt1 = "SELECT A.ORG, A.COST_CENTER, B.COST_CENTER_NAME, C.USER_ID, D.USER_NAME, D.E_MAIL "
        sqltxt2 = "FROM FWEB_ONLB_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C, FWEB_USER_LOGIN_M D " & _
                  "WHERE A.ORG = '" + txt_org.Value.Trim + "' " & _
                  "AND A.COST_CENTER LIKE '" + txt_cost_center.Value.Trim + "'||'%' " & _
                  "AND A.ORG = B.ORG " & _
                  "AND A.COST_CENTER = B.COST_CENTER " & _
                  "AND C.SYST_NO = 'FWEB' " & _
                  "AND C.PROJ_NO = 'ONLB' " & _
                  "AND A.ORG = C.ORG " & _
                  "AND A.COST_CENTER = C.COST_CENTER " & _
                  "AND C.USER_ID = D.USER_ID " & _
                  "AND D.USER_GROUP = 'PROC' " & _
                  "AND NOT EXISTS (SELECT 'X' FROM FWEB_ONLB_ONHAND " & _
                  "WHERE PERIOD_NAME = TO_DATE('" + txt_period_name.Value + "','YYYY/MM/DD') AND ORG = A.ORG AND COST_CENTER = A.COST_CENTER " & _
                  "AND NVL(IMPORT_MARK,'N') = 'Y') "
        Dim sqltxt As String = sqltxt1 & sqltxt2
        viewstate("sqltxt") = sqltxt
        viewstate("sqltxt1") = sqltxt1
        viewstate("sqltxt2") = sqltxt2
        Me.dg.CurrentPageIndex = 0
        Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
    End Sub

    Function Check_Data() As Boolean
        Dim err_count As Int16 = 0
        Dim checksql As String
        If txt_org.Value = "" Then
            'CHECK�t�O���i����
            err_count = err_count + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
            ElseIf txt_org.Value <> "" Then
                'CHECK�O�_���u�W���s�L�I���t�O
                checksql = "SELECT COUNT(*) FROM FWEB_ONLB_DEPT where org='" + txt_org.Value.Trim + "'"
                If db.GetExecuteScalar(checksql) = 0 Then
                    err_count = err_count + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���t�O�D�u�W���s�L�I���t�O�A��CHECK! �Y���s�W���L�I���t�O�A�гq���]�ȼW�[!');</script>")
                End If
                'CHECK�O�_���t�O�v��
                checksql = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                           "AND PROJ_NO = 'ONLB' AND DECODE(ORG,'ALL','" + txt_org.Value.Trim + "',ORG)='" + txt_org.Value.Trim + "'"
                If db.GetExecuteScalar(checksql) = 0 Then
                    err_count = err_count + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���]�ȼW�[!');</script>")
                End If

                If txt_cost_center.Value <> "" Then
                    'CHECK�O�_���u�W���s�L�I����������
                    checksql = "SELECT COUNT(*) FROM FWEB_ONLB_DEPT WHERE ORG ='" + txt_org.Value.Trim + "' AND COST_CENTER = '" + txt_cost_center.Value.Trim + "'"
                    If db.GetExecuteScalar(checksql) = 0 Then
                        err_count = err_count + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                    End If
                    'CHECK�O�_�����������v��
                    checksql = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                               "AND PROJ_NO = 'ONLB' AND DECODE(ORG,'ALL','" + txt_org.Value.Trim + "',ORG)='" + txt_org.Value.Trim + "' " & _
                               "AND DECODE(COST_CENTER,'ALL','" + txt_cost_center.Value.Trim + "',COST_CENTER)='" + txt_cost_center.Value.Trim + "' "
                    If db.GetExecuteScalar(checksql) = 0 Then
                        err_count = err_count + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                    End If
                End If
            End If
            If err_count > 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Sub Load_Data(ByVal strsql As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            ds = db.FillDataSet(strsql)
            dv = ds.Tables(0).DefaultView
            dg.DataSource = dv
            dg.DataBind()
            GetPageInfo()
        End Sub

        Sub GetPageInfo()
            Dim getsqltxt As String = "SELECT COUNT(*) "
            Dim RecordCount As String = db.GetExecuteScalar(getsqltxt & viewstate("sqltxt2") & Set_SqlNotIn()).ToString
            Label9.Text = "�@<font face=verdana >" + RecordCount + "</font>���O��<font face=verdana >"
        End Sub

        Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
            dg.CurrentPageIndex = e.NewPageIndex
            Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
        End Sub

        Function Set_SqlNotIn() As String
            '�d�ߤl�y - �w�[�J����̪���Ƥ���ܦbDataGrid
            Dim sqlnotin As String = ""
            If lbl_MailToId.Text <> "" Then sqlnotin = "AND C.USER_ID NOT IN (" & lbl_MailToId.Text & ")"
            Return sqlnotin
        End Function

        Private Sub btnMail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMail.Click
            '�[�J�����-�d�ߥX�Ӫ�DataGrid�����[�J�����
            Dim ds As New DataSet
            Dim dv As New DataView
            Dim i As Integer = 0

            SetMailFrom()  '�]�w�H��̤ΥD��

            ds = db.FillDataSet(viewstate("sqltxt") & Set_SqlNotIn())

            For i = 0 To ds.Tables(0).Rows.Count - 1
                If txt_MailTo.Text <> "" Then   '����̩m�W
                    txt_MailTo.Text = txt_MailTo.Text + ";"
                End If
                If lbl_MailToId.Text <> "" Then '����̤u��
                    lbl_MailToId.Text = lbl_MailToId.Text + ","
                End If
                If lbl_MailToEmail.Text <> "" Then '�����EMAIL
                    lbl_MailToEmail.Text = lbl_MailToEmail.Text + ";"
                End If
                txt_MailTo.Text = txt_MailTo.Text + ds.Tables(0).Rows(i).Item(4)  '����̩m�W
                lbl_MailToId.Text = lbl_MailToId.Text + "'" + ds.Tables(0).Rows(i).Item(3) + "'"  '����̤u��
                lbl_MailToEmail.Text = lbl_MailToEmail.Text + ds.Tables(0).Rows(i).Item(5)  '�����EMAIL
            Next

            '���s�d��
            If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                dg.CurrentPageIndex -= 1
                Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
            Else
                Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
            End If
        End Sub

        Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
            '�[�J�����-�浧�[�J�����
            If e.CommandName = "AddMailTo" Then

                SetMailFrom()  '�]�w�H��̤ΥD��

                If txt_MailTo.Text <> "" Then '����̩m�W
                    txt_MailTo.Text = txt_MailTo.Text + ";"
                End If
                If lbl_MailToId.Text <> "" Then '����̤u��
                    lbl_MailToId.Text = lbl_MailToId.Text + ","
                End If
                If lbl_MailToEmail.Text <> "" Then '�����EMAIL
                    lbl_MailToEmail.Text = lbl_MailToEmail.Text + ";"
                End If
                txt_MailTo.Text = txt_MailTo.Text + e.Item.Cells(5).Text  '����̩m�W
                lbl_MailToId.Text = lbl_MailToId.Text + "'" + e.Item.Cells(4).Text + "'"  '����̤u��
                lbl_MailToEmail.Text = lbl_MailToEmail.Text + e.Item.Cells(6).Text  '�����EMAIL

                '���s�d��
                If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                    dg.CurrentPageIndex -= 1
                    Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
                Else
                    Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
                End If

            End If
        End Sub

        Private Sub SetMailFrom()
            '�]�w�H��̤ΥD��
            If txt_MailFrom.Text = "" Then
                Dim dr As OleDbDataReader
                Dim MailFromSql As String = "SELECT USER_NAME, E_MAIL FROM FWEB_USER_LOGIN_M WHERE USER_ID = '" + context.User.Identity.Name + "'"
                db.GetDataReader(dr, MailFromSql)
                While dr.Read
                    txt_MailFrom.Text = dr.Item("USER_NAME")  '�H��̩m�W
                    lbl_MailFromEmail.Text = dr.Item("E_MAIL") '�H���EMAIL
                    txt_subject.Text = "�q��-[���� " & String.Format(txt_period_name.Value, "YYYY/MM") & "] �u�W���s�����|���ߪ���"  '�D��                
                    txt_MailBody.Text = "�q��-[���� " & String.Format(txt_period_name.Value, "YYYY/MM") & "] �u�W���s�����|���ߪ��ޡA�о��ޱN�u�W���s���ફ��" '����
                End While
                dr.Close()
            End If
        End Sub

        Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
            '����
            txt_MailFrom.Text = ""
            lbl_MailFromEmail.Text = ""
            txt_subject.Text = ""
            txt_MailTo.Text = ""
            lbl_MailToId.Text = ""
            lbl_MailToEmail.Text = ""
            txt_MailBody.Text = ""
            If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                dg.CurrentPageIndex -= 1
                Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
            Else
                Load_Data(viewstate("sqltxt") & Set_SqlNotIn())
            End If
        End Sub

        Private Sub btnSendMail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendMail.Click
            '�ǰe
            Dim msg As New System.Net.Mail.MailMessage()
            Dim client As New SmtpClient()

            If txt_MailFrom.Text <> "" And txt_MailTo.Text <> "" Then
                msg.From = New MailAddress(lbl_MailFromEmail.Text, "", System.Text.Encoding.UTF8)
                msg.To.Add(lbl_MailToEmail.Text)
                msg.Subject = txt_subject.Text
                msg.Body = txt_MailBody.Text
                client.Host = "WWEISYEX1"
                client.Send(msg)
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�l��w�ǰe!');</script>")
                btnCancel_Click(sender, e)  '�٭��l���A
            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�п�������!');</script>")
            End If
        End Sub

End Class

End Namespace
