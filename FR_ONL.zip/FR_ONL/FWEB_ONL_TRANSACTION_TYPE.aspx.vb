Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math


Namespace FR

Partial Class FWEB_ONL_TRANSACTION_TYPE
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txt_org_no.Value <> "" Then
            loadcost_name()

            Me.dd_cost_name.Value = Me.txt_cost_no.Value
        End If
        If Not Page.IsPostBack Then
            loadorg()
            'onchange="costname()"
            'Me.txt_cost_no.Attributes.Add("onchange", "<script language='javascript'>costname()</script>")
                'Page.ClientScript.RegisterClientScriptBlock(Me.GetType(),"msg", "<script defer>alert('�������O��J���ŦX�n�D!');</script>")
                btn_state(0)
            End If
        End Sub
        Sub loadorg()
            Dim sqlstr As String
            Dim TempDS As New DataSet
            Try

            sqlstr = "SELECT T.�s��, T.�W�� FROM (SELECT 'ALL' AS �s��, 'ALL' AS �W�� FROM DUAL UNION ALL SELECT DISTINCT A.ORG �s��, B.ORG_NAME �W�� FROM FWEB_ONL_DEPT A, UCCST_ORG_T B WHERE(A.ORG = B.ORG) ) T ORDER BY T.�s��"
            TempDS = db.FillDataSet(sqlstr, 2)
            dd_org_name.DataSource = TempDS.Tables(0)
            dd_org_name.DataValueField = "�s��"
            dd_org_name.DataTextField = "�W��"
            dd_org_name.DataBind()
            dd_org_name.Items.Insert(0, "")
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not TempDS Is Nothing Then
                 TempDS.Dispose()
              End If
            End Try

        End Sub
        Sub btn_state(ByVal intnum As Int16)
            If intnum = 0 Then                     '�D�s�説�A
                btnInq.Enabled = True
                BN_ADD.Enabled = True
                BN_SAV.Enabled = False
                BN_CAN.Enabled = False
                Btnexcel.Enabled = False
            End If
            If intnum = 1 Then                      '�s�説�A
                btnInq.Enabled = False
                BN_ADD.Enabled = False
                BN_SAV.Enabled = True
                BN_CAN.Enabled = True
                Btnexcel.Enabled = False
            End If
            If intnum = 2 Then
                btnInq.Enabled = True
                BN_ADD.Enabled = True
                BN_SAV.Enabled = False
                BN_CAN.Enabled = False
                Btnexcel.Enabled = True
            End If
        End Sub

        Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
            find()
            Label1.Text = 0
            btn_state(2)
            textbox_state(2)
        End Sub
        Sub find()
            Dim strsql As String = ""
            Dim class3 As String
            class3 = "select t.PRODUCT_NUM_FIRST,t.ORG,t.COST_CENTER,m.COST_CENTER_name,t.TRANSACTION_TYPE,to_char(t.MDATE,'yyyy/mm/dd') as mdate, t.MUSER,to_char(t.CDATE,'yyyy/mm/dd') as cdate, t.CUSER " & _
                     " from FWEB_ONL_TRANSACTION_TYPE t , (SELECT 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM DUAL UNION ALL SELECT DISTINCT COST_CENTER, COST_CENTER_NAME FROM FWEB_COST_CENTER_V) m" & _
                     " where t.COST_CENTER=m.COST_CENTER and T.ORG like '%" + txt_org_no.Value.Trim + "%' and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'"
            Dim class4 As String = " and t.PRODUCT_NUM_FIRST like '%" + Text1.Value.Trim.ToUpper + "%' and t.TRANSACTION_TYPE like '%" + Text2.Value.Trim.ToUpper + "%' "
            viewstate("strsql") = strsql
            If Text1.Value = "" Then
                If Text2.Value = "" Then
                    strsql = class3 & class4
                Else
                    strsql = class3 & " and t.PRODUCT_NUM_FIRST like '%" + Text1.Value.Trim.ToUpper + "%' and t.TRANSACTION_TYPE = '" + Text2.Value.Trim.ToUpper + "'"
                End If
            Else
                If Text2.Value = "" Then
                    strsql = class3 & " and t.PRODUCT_NUM_FIRST = '" + Text1.Value.Trim.ToUpper + "' and t.TRANSACTION_TYPE like '%" + Text2.Value.Trim.ToUpper + "%'"
                Else
                    strsql = class3 & " and t.PRODUCT_NUM_FIRST = '" + Text1.Value.Trim.ToUpper + "' and t.TRANSACTION_TYPE = '" + Text2.Value.Trim.ToUpper + "'"
                End If
            End If
            viewstate("strsql") = strsql
            dg.CurrentPageIndex = 0
            loaddata(viewstate("strsql"))
        End Sub
        Sub loaddata(ByVal strsql As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            If strsql <> "" Then
                ds = db.FillDataSet(strsql, 2)
                dv = ds.Tables(0).DefaultView
                dg.DataSource = dv
                dg.DataBind()
            End If
            GetPageInfo()
        End Sub
        Sub GetPageInfo()
            Dim strsql As String
            Dim class2 As String = "select count(*) from FWEB_ONL_TRANSACTION_TYPE T, FWEB_COST_CENTER_V M " & _
                                  " where T.ORG = M.ORG AND T.COST_CENTER=M.COST_CENTER and T.ORG like '%" + txt_org_no.Value.Trim + "%' and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'"
            strsql = class2 & " and t.PRODUCT_NUM_FIRST like '%" + Text1.Value.Trim.ToUpper + "%' and t.TRANSACTION_TYPE like '%" + Text2.Value.Trim.ToUpper + "%' "
            Dim strsql1 As String = db.GetExecuteScalar(strsql).ToString
            Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
        End Sub
        Private Sub BN_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_ADD.Click
            Label1.Text = 1
            btn_state(1)
            cleartext(0)
            textbox_state(0)
        End Sub
        Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
                CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
            End If
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
                'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
                'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
                e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
                e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
            End If
        End Sub

        Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
            If e.CommandName = "delete" Then
                Dim str As String
                str = "delete from FWEB_ONL_TRANSACTION_TYPE  T where T.ORG = '" + e.Item.Cells(3).Text.Trim + "' and T.TRANSACTION_TYPE='" + e.Item.Cells(6).Text.Trim + "'" & _
                " and T.COST_CENTER = '" + e.Item.Cells(4).Text.Trim + "' and T.PRODUCT_NUM_FIRST = '" + e.Item.Cells(2).Text.Trim + "'"
                Try
                    db.ExecuteSQL(str)
                Catch ex As Exception
                    Throw ex
                Finally

                    loaddata(viewstate("strsql"))
                End Try
                btn_state(2)
                textbox_state(2)
            ElseIf e.CommandName = "edit" Then

                btn_state(1)
                cleartext(0)
                textbox_state(1)
                txt_org_no.Value = e.Item.Cells(3).Text.Trim
                dd_org_name.Value = e.Item.Cells(3).Text.Trim
                loadcost_name()                               '�K�[�t�O�W��
                txt_cost_no.Value = e.Item.Cells(4).Text.Trim
                dd_cost_name.Value = e.Item.Cells(4).Text.Trim
                Text1.Value = e.Item.Cells(2).Text.Trim
                txt_org_no.Disabled = True
                dd_org_name.Disabled = True
                dd_org_name.Visible = True
                txt_cost_no.Disabled = True
                dd_cost_name.Disabled = True
                dd_cost_name.Visible = True
                Text2.Value = e.Item.Cells(6).Text.Trim
                Label2.Text = Text2.Value
                Text1.Disabled = True
                Text2.Disabled = False
                Label1.Text = "2"
            End If
        End Sub
        Sub textbox_state(ByVal intnum As Int16)
            If intnum = 0 Then                     '�s�W���A  
                Text1.Disabled = False
                Text1.Style.Add("BACKGROUND-COLOR", "lightcyan")
                txt_org_no.Disabled = False
                txt_org_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
                dd_org_name.Visible = True
                dd_org_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
                txt_cost_no.Disabled = False
                txt_cost_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
                dd_cost_name.Visible = True
                dd_cost_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
                Text2.Disabled = False
                Text2.Style.Add("BACKGROUND-COLOR", "lightcyan")
                dg.Columns(0).Visible = False
                dg.Columns(1).Visible = False
            ElseIf intnum = 1 Then                 '�s�説�A
                Text1.Disabled = True
                txt_org_no.Disabled = True
                dd_org_name.Visible = False
                txt_cost_no.Disabled = True
                dd_cost_name.Visible = False
                Text2.Disabled = False
                Text2.Style.Add("BACKGROUND-COLOR", "lightcyan")
                dg.Columns(0).Visible = False
                dg.Columns(1).Visible = False
            Else                                   '��L���A
                Text1.Disabled = False
                Text1.Style.Add("BACKGROUND-COLOR", "white")
                txt_org_no.Disabled = False
                txt_org_no.Style.Add("BACKGROUND-COLOR", "beige")
                dd_org_name.Visible = True
                dd_org_name.Disabled = False
                dd_org_name.Style.Add("BACKGROUND-COLOR", "white")
                txt_cost_no.Disabled = False
                txt_cost_no.Style.Add("BACKGROUND-COLOR", "beige")
                dd_cost_name.Visible = True
                dd_cost_name.Disabled = False
                dd_cost_name.Style.Add("BACKGROUND-COLOR", "white")
                Text2.Style.Add("BACKGROUND-COLOR", "white")
                dg.Columns(0).Visible = True
                dg.Columns(1).Visible = True
            End If
        End Sub

        Private Sub BN_SAV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SAV.Click
            Dim strsql As String
            Try
                If Label1.Text = 1 Then                'label1.text=1���ܬO�s�W���A
                    If check_data() = False Then
                        Exit Sub
                    End If
                    strsql = String.Format(" insert into  FWEB_ONL_TRANSACTION_TYPE (ORG,COST_CENTER,PRODUCT_NUM_FIRST,TRANSACTION_TYPE,cdate,cuser) " & _
                   " values('{0}','{1}','{2}','{3}',sysdate,'{4}') ", txt_org_no.Value.Trim, txt_cost_no.Value.Trim, Text1.Value.Trim.ToUpper, Text2.Value.Trim.ToUpper, Context.User.Identity.Name)
                Else                                                 '�s��
                    If Text2.Value = "" Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������O���i����!');</script>")
                        Exit Sub
                    Else
                        strsql = String.Format("update FWEB_ONL_TRANSACTION_TYPE set TRANSACTION_TYPE='{0}',MDATE=sysdate,MUSER='{1}' where PRODUCT_NUM_FIRST='{2}' AND org = '{3}' and cost_center = '{4}' and TRANSACTION_TYPE='{5}'", _
                        Text2.Value.Trim.ToUpper, Context.User.Identity.Name, Text1.Value.Trim.ToUpper, txt_org_no.Value.Trim, txt_cost_no.Value.Trim, Label2.Text.Trim)
                    End If
                End If
                db.ExecuteSQL(strsql)
            Catch ex As Exception
                Throw ex
                Exit Sub
            End Try
            btn_state(2)
            textbox_state(2)
            cleartext(0)
            loaddata(viewstate("strsql"))
        End Sub

        Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CAN.Click
            btn_state(2)
            textbox_state(2)
            cleartext(0)
        End Sub
        Function check_data() As Boolean
            Dim inti As Int16 = 0
            If Text1.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ƹ��Ĥ@�X���i����!');</script>")
            End If
            If Text1.Value.Length > 1 Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ƹ��Ĥ@�X��J���ŦX�n�D!');</script>")
            End If
            If Text2.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������O���i����!');</script>")
            End If
            If Text2.Value.Length > 6 Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������O��J���ŦX�n�D!');</script>")
            End If
            If txt_org_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
            End If
            If txt_cost_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������ߤ��i����!');</script>")
            End If
            If txt_org_no.Value <> "ALL" Then
                Dim str1 As String = "select count(*) From FWEB_ONL_DEPT where ORG='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(str1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���~�A�Э��s��J!');</script>")
                End If
            End If
            If txt_cost_no.Value = "ALL" And txt_org_no.Value <> "ALL" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O�Φ������߿��~�A�Э��s��J!');</script>")
            End If
            If txt_cost_no.Value <> "ALL" And txt_org_no.Value = "ALL" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O�Φ������߿��~�A�Э��s��J!');</script>")
            End If
            If txt_cost_no.Value <> "ALL" And txt_org_no.Value <> "ALL" Then
                Dim str2 As String = "select count(*) From FWEB_ONL_DEPT where  COST_CENTER='" + txt_cost_no.Value.Trim + "'"
                If db.GetExecuteScalar(str2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                End If
            End If

            If txt_org_no.Value <> "" And txt_cost_no.Value <> "" Then
                If Label1.Text = 1 Then
                    Try
                        Dim strsql2 As String = " select count(*) from FWEB_ONL_TRANSACTION_TYPE where ORG='" + txt_org_no.Value.Trim + "'" & _
                        " and COST_CENTER='" + txt_cost_no.Value.Trim + "' and PRODUCT_NUM_FIRST = '" + Text1.Value.ToUpper.Trim + "'"
                        If db.GetExecuteScalar(strsql2) > 0 Then
                            inti = inti + 1
                            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('������Ƥw�s�b!');</script>")
                            Return False
                        End If
                        'Dim strsql As String = " select count(*) from FWEB_ONL_TRANSACTION_TYPE where ORG='" + txt_org_no.Value.Trim + "'" & _
                        '" and COST_CENTER='" + txt_cost_no.Value.Trim + "' and PRODUCT_NUM_FIRST = '" + Text1.Value.ToUpper.Trim + "' and TRANSACTION_TYPE = '" + Text2.Value.ToUpper.Trim + "'"
                        'If db.GetExecuteScalar(strsql) > 0 Then
                        '    inti = inti + 1
                        '    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(),"msg", "<script defer>alert('������Ƥw�s�b!');</script>")
                        '    Return False
                        'End If
                    Catch ex As Exception
                        Throw ex
                    End Try
                End If
            End If
            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function
    Sub cleartext(ByVal intstate As Int16)
        If intstate = 0 Then                     '�D�d�ߪ��A
            txt_org_no.Value = ""
            dd_org_name.SelectedIndex = -1
            txt_cost_no.Value = ""
            dd_cost_name.SelectedIndex = -1
            Text1.Value = ""
            Text2.Value = ""
        End If
    End Sub
    Sub bind_data()
        With db.FillDataSet(viewstate("strsql")).Tables(0)
            dg.DataSource = .DefaultView
            dg.DataBind()
            dg.Height = Unit.Pixel(1)
        End With
    End Sub
    Private Sub Btnexcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnexcel.Click
        Response.Write("<script>window.open('ONL/" + EXPORT_EXCEL() + ".xls')</script>")
    End Sub
    Function EXPORT_EXCEL() As String       '(ByVal source, ByVal e)
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
        Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL3.xls"
        Dim fileNameTmp As String = "temp003"
        Dim savepath As String = Server.MapPath("~") & "\ONL\" + fileNameTmp + ".xls"
        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

            '��R���
            Dim ds As DataSet
            ds = db.FillDataSet(ViewState("strsql"), 2)
                Dim y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "PRODUCT_NUM_FIRST"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(i).Item("PRODUCT_NUM_FIRST").ToString
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 2) = ds.Tables(0).Rows(i).Item("ORG").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(i).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER_NAME"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 4) = ds.Tables(0).Rows(i).Item("COST_CENTER_NAME").ToString
                            j = j + 1
                        Next
                    Case "TRANSACTION_TYPE"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 5) = ds.Tables(0).Rows(i).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "MDATE"
                        j = 0
                        For i = 0 To i - 1
                            If Not IsDBNull(ds.Tables(0).Rows(i).Item("MDATE")) Then
                                oCells(j + 2, 6) = "'" + ds.Tables(0).Rows(i).Item("MDATE").ToString.Substring(0, 10)
                            Else
                                oCells(j + 2, 6) = ""
                            End If
                            j = j + 1
                        Next
                    Case "MUSER"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 7) = "'" + ds.Tables(0).Rows(i).Item("MUSER").ToString
                            j = j + 1
                        Next
                    Case "CDATE"
                        j = 0
                        For i = 0 To i - 1
                            If Not IsDBNull(ds.Tables(0).Rows(i).Item("CDATE")) Then
                                oCells(j + 2, 8) = "'" + ds.Tables(0).Rows(i).Item("CDATE").ToString.Substring(0, 10)
                            Else
                                oCells(j + 2, 8) = ""
                            End If
                            j = j + 1
                        Next
                    Case "CUSER"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 9) = "'" + ds.Tables(0).Rows(i).Item("CUSER").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            ' oExcel.DisplayAlerts = True

            Return fileNameTmp
        Catch ex As Exception
            Throw ex
        Finally
            ' oExcel.Application.Quit()
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If


            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If

            GC.Collect()

        End Try
        '  GC.Collect()
    End Function

    Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
        dg.CurrentPageIndex = e.NewPageIndex
        loaddata(viewstate("strsql"))
    End Sub

    Sub loadcost_name()
        Dim sqlstr As String
        Dim TempDS As New DataSet
        Try

           sqlstr = "SELECT T.�s�X, T.�W�� FROM (SELECT 'ALL' AS �s�X, 'ALL' AS �W�� FROM DUAL UNION ALL SELECT DISTINCT A.COST_CENTER �s�X, B.COST_CENTER_NAME �W�� from FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B WHERE A.ORG = '" + txt_org_no.Value.Trim + "' and A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER) T ORDER BY T.�s�X "
           TempDS = db.FillDataSet(sqlstr, 2)
           dd_cost_name.DataSource = TempDS.Tables(0)
           dd_cost_name.DataValueField = "�s�X"
           dd_cost_name.DataTextField = "�W��"
           dd_cost_name.DataBind()
           dd_cost_name.Items.Insert(0, "")

        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

End Class

End Namespace
