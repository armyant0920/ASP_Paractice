select * from fweb_user_login_m
SELECT * FROM wmap_exp_cost ORDER BY cost_id
select /*distinct rep_date_type*/ * from FWEB_WIN_RPT4_TMP
select * from FWEB_WIN_RPT1_TMP-- for update

SELECT  * FROM FWEB_WIN_RPT4_TMP where rep_date_type=18--�_
SELECT DISTINCT ORG, COST_CENTER, PRODUCT_TYPE FROM FWEB_WIN_RPT4_TMP --�O

SELECT distinct t1.REP_DATE_TYPE,t1.ORG, t1.COST_CENTER, PRODUCT_TYPE,SUM(NVL(QTY,0))Qty,SUM(NVL(AMOUNT,0))AMOUNT
 FROM FWEB_WIN_RPT4_TMP t1,(SELECT DISTINCT ORG, COST_CENTER, PRODUCT_NUM, PRODUCT_DESC, UOM FROM FWEB_WIN_RPT4_TMP) loop1
WHERE t1.ORG = LOOP1.ORG
   AND t1.COST_CENTER = LOOP1.COST_CENTER
   AND t1.PRODUCT_NUM = LOOP1.PRODUCT_NUM
   AND t1.PRODUCT_DESC = LOOP1.PRODUCT_DESC
   AND t1.UOM = LOOP1.UOM   
   AND t1.REP_DATE_TYPE between '2007/04' and '2007/08'
 group by t1.ORG, t1.COST_CENTER, PRODUCT_TYPE,REP_DATE_TYPE
------
SELECT REP_DATE_TYPE,t1.ORG, t1.COST_CENTER, t1.PRODUCT_TYPE,SUM(NVL(QTY,0))Qty, SUM(NVL(AMOUNT,0))Amount
 FROM FWEB_WIN_RPT4_TMP t1,(SELECT DISTINCT ORG, COST_CENTER, PRODUCT_TYPE FROM FWEB_WIN_RPT4_TMP)loop1
WHERE t1.ORG = LOOP1.ORG
   AND t1.COST_CENTER = LOOP1.COST_CENTER
   AND t1.PRODUCT_TYPE = LOOP1.PRODUCT_TYPE
   AND REP_DATE_TYPE between '2007/04' and '2007/08'
   group by t1.ORG, t1.COST_CENTER, t1.PRODUCT_TYPE,REP_DATE_TYPE
    
select to_char(sysdate,'fmww') from dual --���P

INSERT INTO FWEB_WIN_RPT4_TMP
        (ORG, REP_DATE_TYPE, COST_CENTER, COST_NAME,
         PRODUCT_ID, PRODUCT_NUM, PRODUCT_DESC, UOM,
         QTY, AMOUNT, MDATE, MUSER)        
  SELECT A.ORG, 
         DECODE('W',
                'D',TO_CHAR(A.TRANSACTION_DATE,'YYYY/MM/DD'),  --BY��
                'W',TO_CHAR(A.TRANSACTION_DATE,'WW'),          --BY�g
                'M',TO_CHAR(A.TRANSACTION_DATE,'YYYY/MM'),     --BY��
                'Y',TO_CHAR(A.TRANSACTION_DATE,'YYYY')),       --BY�~  
         A.COST_CENTER,
         B.COST_NAME, 
         A.PRODUCT_ID, 
         A.PRODUCT_NUM, 
         A.PRODUCT_DESC, 
         A.UOM, 
         SUM(NVL(A.QTY,0)),
         SUM(NVL(A.AMOUNT,0)),
         SYSDATE,
        '02438'
    FROM FWEB_WIN_RPT1_TMP A,
         (SELECT * FROM WMAP_EXP_COST) B
   WHERE A.MUSER = '02438'
     AND A.PRE_NOW_TYPE = 'NOW'
     AND A.COST_CENTER = B.COST_ID
   GROUP BY A.ORG, 
            DECODE('W',
                   'D',TO_CHAR(A.TRANSACTION_DATE,'YYYY/MM/DD'),  --BY��
                   'W',TO_CHAR(A.TRANSACTION_DATE,'WW'),          --BY�g
                   'M',TO_CHAR(A.TRANSACTION_DATE,'YYYY/MM'),     --BY��
                   'Y',TO_CHAR(A.TRANSACTION_DATE,'YYYY')),       --BY�~
            A.COST_CENTER,
            B.COST_NAME,
            A.PRODUCT_ID,
            A.PRODUCT_NUM,
            A.PRODUCT_DESC,
            A.UOM;                  
            
            
            SELECT REP_DATE_TYPE ���,
       t1.ORG �t�O,
       t1.COST_CENTER ��������,
       t1.COST_NAME �������ߦW��,
       t1.PRODUCT_NUM �Ƹ�,
       t1.PRODUCT_DESC �~�W�W��,
       t1.UOM ���,
       SUM(NVL(QTY, 0)) �ƶq
  FROM FWEB_WIN_RPT4_TMP t1,
       (SELECT DISTINCT ORG, COST_CENTER, PRODUCT_NUM, PRODUCT_DESC, UOM
          FROM FWEB_WIN_RPT4_TMP)  LOOP1
 WHERE (t1.ORG = LOOP1.ORG)
   AND t1.COST_CENTER = LOOP1.COST_CENTER
   AND t1.PRODUCT_NUM = LOOP1.PRODUCT_NUM
   AND t1.PRODUCT_DESC = LOOP1.PRODUCT_DESC
   AND t1.UOM = LOOP1.UOM
   AND REP_DATE_TYPE between '2007/07/26' and '2007/7/31'
   and muser = '02438'
 group by REP_DATE_TYPE,
          t1.ORG,
          t1.COST_CENTER,
          t1.COST_NAME,
          t1.PRODUCT_NUM,
          t1.PRODUCT_DESC,
          t1.UOM
          
 order by ��������, ���    E00000238
--  select * from /*WMINV_TRX_V*/ FWEB_WIN_RPT4_TMP order by product_num