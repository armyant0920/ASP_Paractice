Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices


Namespace FR

Partial Class FWEB_ONL_APPROVE
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txt_org_no.Value <> "" Then
            loadcost()
            Me.dd_cost_name.Value = Me.txt_cost_no.Value
        End If
        If Not Page.IsPostBack Then
            btn_state(0)
            sysdate()
            loadorg()
            Me.dd_org_name.Value = Me.txt_org_no.Value
            loadcost()
            listyd()
            textbox_state(2)
            btn1.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_PROD_2.aspx?type=a", 640, 480))
            btn4_Approve.Attributes.Add("onclick", "javascript:if (confirm('�O�_�nAPPROVE�U��������ơH')) {return true;} else {return false;};")
        End If
    End Sub
    Sub loadorg()
        Dim TempDS As New DataSet
        Dim sqlstr As String
        Try
           sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                    " WHERE A.ORG = B.ORG AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                    " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
           TempDS = db.FillDataSet(sqlstr, 2)
           dd_org_name.DataSource = TempDS.Tables(0)
           dd_org_name.DataValueField = "�s�X"
           dd_org_name.DataTextField = "�W��"
           dd_org_name.DataBind()
           dd_org_name.Items.Insert(0, "")
        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

    Sub listyd()
        Dim TempDS As New DataSet
        Dim sqlstr As String
        Try
           sqlstr = "SELECT DISTINCT TRANSACTION_TYPE �������O FROM FWEB_ONL_TRANSACTION_TYPE"
           TempDS = db.FillDataSet(sqlstr)
           dd_list_yd.DataSource = TempDS.Tables(0)
           'dd_list_yd.DataValueField = "�s�X"
           dd_list_yd.DataTextField = "�������O"
           dd_list_yd.DataBind()
           dd_list_yd.Items.Insert(0, "")
       Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�D�s�説�A
            btnInq.Enabled = True              '�d��
            btn2_sav.Enabled = False          '�x�s
            btn3_ab.Enabled = False           '����
            btn4_Approve.Enabled = False       'APRROVE
            btn5_excel.Enabled = False         '��EXECL
            btn6_tran.Enabled = True           '�h�������J
            btn7_form.Enabled = True           '���ɮ榡
            btn8_excel.Enabled = True          '���`������EXCEL
        End If
        If intnum = 3 Then
            btnInq.Enabled = True
            btn2_sav.Enabled = False
            btn3_ab.Enabled = False
            btn4_Approve.Enabled = True
            btn5_excel.Enabled = True
            btn6_tran.Enabled = True           '�h�������J
            btn7_form.Enabled = True           '���ɮ榡
            btn8_excel.Enabled = True
        End If
        If intnum = 1 Then
            btnInq.Enabled = False
            btn6_tran.Enabled = False
            btn7_form.Enabled = False
            btn2_sav.Enabled = True
            btn3_ab.Enabled = True
            btn4_Approve.Enabled = True
            btn5_excel.Enabled = True
            btn8_excel.Enabled = True
        End If
        If intnum = 2 Then
            btnInq.Enabled = False               '�d��
            btn2_sav.Enabled = True           '�x�s
            btn3_ab.Enabled = True            '����
            btn4_Approve.Enabled = False       'APRROVE
            btn5_excel.Enabled = False         '��EXECL
            btn6_tran.Enabled = False            '�h�������J
            btn7_form.Enabled = False           '���ɮ榡
            btn8_excel.Enabled = False
        End If
        If intnum = 4 Then                     '�D�s�説�A
            btnInq.Enabled = True              '�d��
            btn2_sav.Enabled = False          '�x�s
            btn3_ab.Enabled = False           '����
            btn4_Approve.Enabled = True         'APRROVE
            btn5_excel.Enabled = True         '��EXECL
            btn6_tran.Enabled = True           '�h�������J
            btn7_form.Enabled = True           '���ɮ榡
            btn8_excel.Enabled = False         '���`������EXCEL
        End If
    End Sub

    Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
        If check_data() = False Then
            Exit Sub
        End If
            Dim strsql As String = ""
            Dim longstr As String = ""
            Dim tiaojian As String = ""
            Dim strsql3 As String = ""
            Dim strsql2 As String = ""
        tiaojian = " T.PERIOD_NAME=to_date('" + edtDateFrom.Value + "','yyyy/MM/dd') and T.ORG = '" + txt_org_no.Value + "' AND T.COST_CENTER LIKE '%" + txt_cost_no.Value + "%'" & _
                   " AND T.PRODUCT_NUM LIKE '%" + Text1.Value + "%' and T.TRANSACTION_TYPE like '%" + dd_list_yd.SelectedValue.Trim + "%'" & _
                   " and  T.IMPORT_MARK ='Y'  and (T.APPROVE_MARK<>'Y' or  T.APPROVE_MARK is null)"
        longstr = " select to_char(T.PERIOD_NAME,'yyyy/MM/dd') as PERIOD_NAME,T.ORG,t.TRANSACTION_TYPE,T.COST_CENTER,M.COST_CENTER_NAME,T.BONDED_FLAG, T.PRODUCT_NUM,t.PRODUCT_DESC,T.UOM,T.PRE_ONHAND," & _
                 " T.NOW_WASTE,T.NOW_ONHAND, T.BONDED_NOW_ONHAND,T.CHECK_ONHAND,T.REMARK,T.IMPORT_MARK,to_char(T.IMPORT_DATE,'yyyy/mm/dd') as IMPORT_DATE," & _
                 " T.IMPORT_USER,T.APPROVE_MARK,to_char(T.APPROVE_DATE,'yyyy/mm/dd') as APPROVE_DATE ," & _
                 " T.APPROVE_USER,to_char(T.MDATE,'yyyy/mm/dd') as MDATE ,T.MUSER,to_char(T.CDATE,'yyyy/mm/dd') as CDATE,T.CUSER" & _
                 " from FWEB_ONL_ONHAND T,FWEB_COST_CENTER_V M where T.ORG = M.ORG AND T.COST_CENTER=M.COST_CENTER and " & tiaojian
        viewstate("tiaojian") = tiaojian
        strsql2 = "select count(*) from FWEB_ONL_ONHAND T,FWEB_COST_CENTER_V M where T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER AND T.IMPORT_MARK='Y' and (T.APPROVE_MARK<>'Y' or  T.APPROVE_MARK is null) and" & tiaojian
        If dd_select_on.SelectedItem.Text = "Y" Then
            strsql = longstr & " and T.CHECK_ONHAND < 0 "
            strsql3 = strsql2 & " and T.CHECK_ONHAND < 0 "
        End If
        If dd_select_on.SelectedItem.Text = "N" Then
            strsql = longstr & " and T.CHECK_ONHAND >= 0 "
            strsql3 = strsql2 & " and T.CHECK_ONHAND >= 0 "
        End If
        If dd_select_on.SelectedItem.Text = "" Then
            strsql = longstr
            strsql3 = strsql2
        End If
        btn_state(3)
        viewstate("strsql") = strsql
        viewstate("strsql3") = strsql3
        dg.CurrentPageIndex = 0
            loaddata(ViewState("strsql"))

            '�ˬd�Ӽt�O�O�_���������ߩ|���W�ǡA�Y���A�h����apporve�s�A20200109 by callo
            'user�ں��A�䴩�渹�Gpro_11_itreq00019769
            Dim chk_ready As String
            chk_ready = "select distinct org,cost_center from FWEB_WIN_MTLTRX_TMP_T A where transaction_type='�����ӥ�' and not exists "
            chk_ready = chk_ready & "(SELECT 'x' FROM FWEB_ONL_ONHAND WHERE PERIOD_NAME = TO_DATE('" & edtDateFrom.Value & "','YYYY/MM/DD') AND ORG = A.ORG AND COST_CENTER = A.COST_CENTER AND NVL(IMPORT_MARK, 'N') = 'Y') "
            chk_ready = chk_ready & "and exists(select 'x' from FWEB_ONL_DEPT where org=A.ORG and COST_CENTER=A.COST_CENTER) "
            chk_ready = chk_ready & "and (substr(A.Product_Num,1,1) in ('B','C','D','E','F','I','J','L','M') or A.Product_Num in (select Product_Num from FWEB_ONL_PROD where substr(Product_Num,1,1) ='V' and include='Y')) "
            chk_ready = chk_ready & "and A.Product_Num not in (select Product_Num from FWEB_ONL_PROD where substr(Product_Num,1,1) ='B' and include='N' and cost_center='ALL' and org=A.org) "
            chk_ready = chk_ready & "and A.Product_Num not in (select Product_Num from FWEB_ONL_PROD where substr(Product_Num,1,1) ='B' and include='N' and cost_center=A.COST_CENTER and org=A.org) "
            chk_ready = chk_ready & "and A.ORG = '" & txt_org_no.Value & "' order by org,cost_center"
            'Response.Write(chk_ready)
            'Response.End()
            Dim ds_chk As New DataSet
            ds_chk = db.FillDataSet(chk_ready)
            If ds_chk.Tables(0).Rows.Count > 0 Then
                Response.Write(ds_chk.Tables(0).Rows(0)(0).ToString() & "�t�@���H�U�������ߩ|���W�ǡA�ФW�ǧ�����ơA���¡I<br>")
                For i = 0 To ds_chk.Tables(0).Rows.Count - 1
                    Response.Write(ds_chk.Tables(0).Rows(i)(0).ToString() & "-" & ds_chk.Tables(0).Rows(i)(1).ToString() & "<br>")
                Next
                'btn4_Approve.Enabled = False
            End If

    End Sub

    Function check_data() As Boolean
        Dim inti As Int16 = 0
        If txt_org_no.Value = "" Then
            inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
                Return False
            End If
            If txt_org_no.Value <> "" Then
                'CHECK�O�_���u�W���s�L�I���t�O
                Dim strsql1 As String = "SELECT COUNT(*) FROM FWEB_ONL_DEPT where org='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���t�O�D�u�W���s�L�I���t�O�A��CHECK! �Y���s�W���L�I���t�O�A�гq���]�ȼW�[!');</script>")
                End If
                'CHECK�O�_���t�O�v��
                Dim strsql2 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                        "AND PROJ_NO = 'ONL' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���]�ȼW�[!');</script>")
                End If

                If txt_cost_no.Value <> "" Then
                    'CHECK�O�_���u�W���s�L�I����������
                    Dim strsql3 As String = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG ='" + txt_org_no.Value.Trim + "' AND COST_CENTER = '" + txt_cost_no.Value.Trim + "'"
                    If db.GetExecuteScalar(strsql3) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                    End If
                    'CHECK�O�_�����������v��
                    Dim strsql4 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                            "AND PROJ_NO = 'ONL' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "' " & _
                                            "AND DECODE(COST_CENTER,'ALL','" + txt_cost_no.Value.Trim + "',COST_CENTER)='" + txt_cost_no.Value.Trim + "' "

                    If db.GetExecuteScalar(strsql4) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                    End If
                End If
            End If
            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Sub loaddata(ByVal strsql As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            Try
               If strsql <> "" Then
                   ds = db.FillDataSet(strsql)
                   dv = ds.Tables(0).DefaultView
                   dg.DataSource = dv
                    dg.DataBind()                    
                    'GridView1.DataSource = dv
                    'GridView1.DataBind()



               End If
               GetPageInfo()
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not dv Is Nothing Then
                 dv.Dispose()
              End If
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
        End Sub

        Sub GetPageInfo()
            Dim strsql1 As String = db.GetExecuteScalar(viewstate("strsql3")).ToString
            Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
        End Sub

        Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
                CType(e.Item.Cells(0).FindControl("btnapp"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{APPROVE������ƶ�?');")
            End If
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
                'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
                'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
                e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
                e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
            End If
        End Sub

        Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
            If e.CommandName = "approve" Then

                Dim strsql2 As String
                '�ˬdcheck��<0�B�S���Ƶ���

                strsql2 = " select count(*) from  FWEB_ONL_ONHAND T where t.CHECK_ONHAND<0 and t.REMARK is null and " & _
                         " T.ORG = '" + e.Item.Cells(3).Text + "' AND T.COST_CENTER LIKE '" + e.Item.Cells(5).Text + "'" & _
                         " AND T.PRODUCT_NUM LIKE '" + e.Item.Cells(8).Text + "' and T.TRANSACTION_TYPE like '" + e.Item.Cells(4).Text + "'"

                '���Ƴ���
                Dim itemSql As String
                itemSql = "T.ORG= '" + e.Item.Cells(3).Text + "' AND T.COST_CENTER LIKE '" + e.Item.Cells(5).Text + "'" & _
                          " AND T.PRODUCT_NUM LIKE '" + e.Item.Cells(8).Text + "' AND T.TRANSACTION_TYPE like '" + e.Item.Cells(4).Text + "' AND PERIOD_NAME=to_date('" + e.Item.Cells(2).Text + "','yyyy/MM/dd')"

                'Kevin �浧���Q�ˬd�P�_
                Dim goldSql = "select count(*) from (select * from FWEB_ONL_ONHAND T where " & itemSql & ") A,FWEB_ONL_PROD B " & vbNewLine & _
                                "where 1=1" & vbNewLine & _
                                "and A.PRE_ONHAND+A.NOW_WASTE>0" & vbNewLine & _
                                "and A.NOW_ONHAND<=0" & vbNewLine & _
                                "and A.PRODUCT_NUM=B.PRODUCT_NUM" & vbNewLine & _
                                "and A.REMARK is null" & vbNewLine & _
                                "and B.GOLD_FLAG='Y' "

                System.Diagnostics.Debug.WriteLine("goldSql=" + goldSql)



                If db.GetExecuteScalar(strsql2) > 0 Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('CHECK�����u�W���s�����A�ж�g�Ƶ������A�~��APPROVE');</script>")
                    Exit Sub
                End If

                If db.GetExecuteScalar(goldSql) > 0 Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Яd�N,���Q�Ƹ�" + e.Item.Cells(8).Text + "�ƶq�����A\n���Q�ݥѤ��R�Ǥ��R�Ѥ����ӥο@�סA�æ^�����s�ơC\n���t�O�����Q���s��<=0�A�Щ�Ƶ���컡���~��APPROVE');</script>")
                    Exit Sub
                End If
                



                Try
                    Dim strsql As String
                    strsql = " update FWEB_ONL_ONHAND  set APPROVE_MARK='Y',APPROVE_DATE=SYSDATE,APPROVE_USER='" + Context.User.Identity.Name + "'" & _
                             " where NVL(APPROVE_MARK,'N') = 'N' and PERIOD_NAME=to_date('" + e.Item.Cells(2).Text + "','yyyy/MM/dd') and ORG='" + e.Item.Cells(3).Text + "'" & _
                             " and COST_CENTER='" + e.Item.Cells(5).Text + "' and PRODUCT_NUM='" + e.Item.Cells(8).Text + "' and TRANSACTION_TYPE='" + e.Item.Cells(4).Text + "'"
                    db.ExecuteSQL(strsql)
                Catch ex As Exception
                    Throw ex
                Finally
                    dg.CurrentPageIndex = 0
                    loaddata(ViewState("strsql"))
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('APPROVE���\!');</script>")
                End Try
            ElseIf e.CommandName = "edit" Then

                If e.Item.Cells(18).Text = "Y" Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�w�gAPPROVE ���i�ק�');</script>")
                    Exit Sub
                End If

                txt_org_no.Value = e.Item.Cells(3).Text.Trim
                dd_org_name.Value = e.Item.Cells(3).Text.Trim 'e.Item.Cells(3).Text.Trim
                dd_list_yd.SelectedItem.Text = e.Item.Cells(4).Text.Trim
                txt_cost_no.Value = e.Item.Cells(5).Text.Trim
                dd_cost_name.Value = e.Item.Cells(5).Text.Trim 'e.Item.Cells(5).Text.Trim
                Text1.Value = e.Item.Cells(8).Text.Trim
                TB1.Text = e.Item.Cells(13).Text.Trim
                TB2.Text = e.Item.Cells(16).Text.Trim
                txtbonded_now_onhand.Text = e.Item.Cells(14).Text.Trim
                Text2.Value = hanshu1(e.Item.Cells(3).Text.Trim, e.Item.Cells(2).Text.Trim, e.Item.Cells(4).Text.Trim, e.Item.Cells(5).Text.Trim, Text1.Value)
                Text3.Value = hanshu2(e.Item.Cells(3).Text.Trim, e.Item.Cells(2).Text.Trim, e.Item.Cells(4).Text.Trim, e.Item.Cells(5).Text.Trim, Text1.Value)
                check_data2()
                If TB1.Text Is Nothing Then
                    TB1.Text = ""
                End If
                If TB2.Text = "&nbsp;" Then
                    TB2.Text = ""
                End If
                loaddata(ViewState("strsql"))
                textbox_state(1)
                btn_state(2)
            End If
        End Sub
        Function hanshu1(ByVal P_ORG_1 As String, ByVal P_MOTH_1 As String, ByVal P_TRANSACTION_TYPE_1 As String, ByVal P_COST_CENTER_1 As String, ByVal P_PRODUCT_NUM_1 As String) As String
            Dim ds As New DataSet
            Try
               Dim strsql1 As String = "select FWEB_ONL_PREONHAND('" & P_ORG_1 & "',to_date('" & P_MOTH_1 & "','yyyy-MM-dd'),'" & P_TRANSACTION_TYPE_1 & "','" & P_COST_CENTER_1 & "','" & P_PRODUCT_NUM_1 & "')PREONHAND from dual"
               ds = db.FillDataSet(strsql1, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("PREONHAND")) Then
                       Text2.Value = ds.Tables(0).Rows(0).Item("PREONHAND")
                   Else
                       Text2.Value = "0"
                   End If
               Else
                   Text2.Value = "0"
               End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try

            Return (Text2.Value)
        End Function
        Function hanshu2(ByVal P_ORG_1 As String, ByVal P_MOTH_1 As String, ByVal P_TRANSACTION_TYPE_1 As String, ByVal P_COST_CENTER_1 As String, ByVal P_PRODUCT_NUM_1 As String) As String
            Dim ds As New DataSet
            Try
               Dim strsql2 As String = "select FWEB_ONL_WASTEQTY('" & P_ORG_1 & "',to_date('" & P_MOTH_1 & "','yyyy-MM-dd'),'" & P_TRANSACTION_TYPE_1 & "','" & P_COST_CENTER_1 & "','" & P_PRODUCT_NUM_1 & "')WASTEQTY from dual"
               ds = db.FillDataSet(strsql2, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("WASTEQTY")) Then
                       Text3.Value = ds.Tables(0).Rows(0).Item("WASTEQTY")
                   Else
                       Text3.Value = "0"
                   End If
               Else
                   Text3.Value = "0"
               End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
            Return (Text3.Value)
        End Function

        Private Sub btn4_Approve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4_Approve.Click
            Dim strsql As String = ""

            If check_gold_approve() = False Then
                Exit Sub
            End If

            If check_approve() = False Then
                Exit Sub
            Else
                Try

                    If dd_select_on.SelectedItem.Text = "Y" Then
                        strsql = "update FWEB_ONL_ONHAND T set t.APPROVE_MARK='Y',t.APPROVE_DATE=SYSDATE,t.APPROVE_USER='" + Context.User.Identity.Name + "'" & _
                        " where " & ViewState("tiaojian") & "and T.CHECK_ONHAND < 0"
                    End If
                    If dd_select_on.SelectedItem.Text = "N" Then
                        strsql = "update FWEB_ONL_ONHAND T set t.APPROVE_MARK='Y',t.APPROVE_DATE=SYSDATE,t.APPROVE_USER='" + Context.User.Identity.Name + "'" & _
                         " where " & ViewState("tiaojian") & " and T.CHECK_ONHAND >= 0 "
                    End If
                    If dd_select_on.SelectedItem.Text = "" Then
                        strsql = "update FWEB_ONL_ONHAND T set t.APPROVE_MARK='Y',t.APPROVE_DATE=SYSDATE,t.APPROVE_USER='" + Context.User.Identity.Name + "'" & _
                                " where " & ViewState("tiaojian")
                    End If
                    db.ExecuteSQL(strsql)
                Catch ex As Exception
                    Throw ex
                Finally
                    loaddata(ViewState("strsql"))
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('APRROVE���\!');</script>")
                End Try
            End If
            btn_state(0)
            textbox_state(2)
            cleartext(0)
        End Sub
        Function check_gold_approve() As Boolean

            Dim BooPass As Boolean = True
            Dim sql = "select count(*) from (select * from FWEB_ONL_ONHAND T where " & ViewState("tiaojian") & ") A,FWEB_ONL_PROD B " & vbNewLine & _
            "where 1=1" & vbNewLine & _
            "and A.PRE_ONHAND+A.NOW_WASTE>0" & vbNewLine & _
            "and A.NOW_ONHAND<=0" & vbNewLine & _
            "and A.PRODUCT_NUM=B.PRODUCT_NUM" & vbNewLine & _
            "and A.REMARK is null" & vbNewLine & _
            "and B.GOLD_FLAG='Y' "
            System.Diagnostics.Debug.WriteLine("sqltxt:" + sql)



            ' "where A.ORG='" + txt_org_no.Value + "'" & vbNewLine & _
            ' "and A.PERIOD_NAME='" + edtDateFrom.Value + "'" & vbNewLine & _

            If db.GetExecuteScalar(sql) > 0 Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Яd�N,���Q�Ƹ��ƶq�����A\n���Q�ݥѤ��R�Ǥ��R�Ѥ����ӥο@�סA�æ^�����s�ơC\n���t�O�����Q���s��<=0�A�Щ�Ƶ���컡��');</script>")
                BooPass = False


            End If
            Return BooPass




        End Function

        Function check_approve() As Boolean
            Dim BooPass As Boolean = True
            Dim TempDS As New DataSet
            Dim SQL As String = ""
            Dim StrMessage As String = ""
            Try
                SQL = " select count(*) from  FWEB_ONL_ONHAND T where t.CHECK_ONHAND<0 and t.REMARK is null and " & ViewState("tiaojian")
                If db.GetExecuteScalar(SQL) > 0 Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('CHECK�����u�W���s�����A�ж�g�Ƶ������A�~��APPROVE');</script>")
                    BooPass = False
                End If

                '�W��t�������ߦ��L�IC00060001�Ƹ��A����S���A�hALERT�T���A�����iAPPROVE
                SQL = "SELECT PRE.PERIOD_NAME,PRE.ORG,PRE.COST_CENTER,PRE.PRODUCT_NUM " & vbNewLine & _
                      "FROM " & vbNewLine & _
                      "( " & vbNewLine & _
                      "  SELECT DISTINCT A.PERIOD_NAME,A.ORG,A.COST_CENTER,A.PRODUCT_NUM " & vbNewLine & _
                      "  FROM FWEB_ONL_ONHAND A " & vbNewLine & _
                      "  WHERE A.PRODUCT_NUM = 'C00060001' " & vbNewLine & _
                      "  AND A.PERIOD_NAME=TO_DATE('" & edtDateFrom.Value & "','YYYY/MM/DD') " & vbNewLine & _
                      ") NOW " & vbNewLine & _
                      ",(" & vbNewLine & _
                      "  SELECT DISTINCT A.PERIOD_NAME,A.ORG,A.COST_CENTER,A.PRODUCT_NUM " & vbNewLine & _
                      "  FROM FWEB_ONL_ONHAND A " & vbNewLine & _
                      "  WHERE A.PRODUCT_NUM = 'C00060001' " & vbNewLine & _
                      "  AND A.PERIOD_NAME=ADD_MONTHS(TO_DATE('" & edtDateFrom.Value & "','YYYY/MM/DD'),-1) " & vbNewLine & _
                      ") PRE " & vbNewLine & _
                      "WHERE NOW.ORG(+)=PRE.ORG AND NOW.COST_CENTER(+)=PRE.COST_CENTER " & vbNewLine & _
                      "AND NOW.PERIOD_NAME IS NULL " & vbNewLine & _
                      "AND PRE.ORG=DECODE('" & txt_org_no.Value.ToString & "','',PRE.ORG,'" & txt_org_no.Value.ToString & "') " & vbNewLine & _
                      "AND PRE.COST_CENTER=DECODE('" & txt_cost_no.Value.ToString & "','',PRE.COST_CENTER,'" & txt_cost_no.Value.ToString & "') "
                TempDS = db.FillDataSet(SQL, 2)
                If TempDS.Tables(0).Rows.Count > 0 Then
                    For i As Integer = 0 To TempDS.Tables(0).Rows.Count - 1
                        StrMessage &= TempDS.Tables(0).Rows(i).Item("ORG").ToString & "�t" & TempDS.Tables(0).Rows(i).Item("COST_CENTER").ToString & "��������" & TempDS.Tables(0).Rows(i).Item("PRODUCT_NUM").ToString & "�Ƹ��W�����L�I��ơA�������S��!" & vbNewLine
                    Next i
                    Alert(StrMessage, Me)
                End If

            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try
            Return BooPass
        End Function
        Sub loadcost()
            Dim sqlstr As String
            Dim TempDS As New DataSet
            Try
                sqlstr = " SELECT DISTINCT A.COST_CENTER �s�X, B.COST_CENTER_NAME �W�� FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                         " WHERE A.ORG = '" + txt_org_no.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                         " AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
                         " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) " & _
                         " ORDER BY A.COST_CENTER "
                TempDS = db.FillDataSet(sqlstr, 2)
                dd_cost_name.DataSource = TempDS.Tables(0)
                dd_cost_name.DataValueField = "�s�X"
                dd_cost_name.DataTextField = "�W��"
                dd_cost_name.DataBind()
                dd_cost_name.Items.Insert(0, "")
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not TempDS Is Nothing Then
                    TempDS.Dispose()
                End If
            End Try
        End Sub

        Sub textbox_state(ByVal intnum As Int16)
            If intnum = 1 Then                 '�s�説�A 
                txt_org_no.Disabled = True
                dd_org_name.Disabled = True
                txt_cost_no.Disabled = True
                dd_cost_name.Disabled = True
                dg.Columns(0).Visible = False
                dg.Columns(1).Visible = False
                Text1.Disabled = True
                dd_list_yd.Enabled = False
                dd_select_on.Enabled = False
                TB1.Enabled = True
                TB1.Style.Add("BACKGROUND-COLOR", "lightcyan")
                TB2.Enabled = True
                TB2.Style.Add("BACKGROUND-COLOR", "lightcyan")
                txtbonded_now_onhand.Enabled = True
                txtbonded_now_onhand.Style.Add("BACKGROUND-COLOR", "lightcyan")

            Else                                   '��L���A
                txt_org_no.Disabled = False
                txt_org_no.Style.Add("BACKGROUND-COLOR", "beige")
                dd_org_name.Disabled = False
                dd_org_name.Style.Add("BACKGROUND-COLOR", "white")
                txt_cost_no.Disabled = False
                txt_cost_no.Style.Add("BACKGROUND-COLOR", "beige")
                dd_cost_name.Disabled = False
                dd_cost_name.Style.Add("BACKGROUND-COLOR", "white")
                dg.Columns(0).Visible = True
                dg.Columns(1).Visible = True
                Text1.Disabled = False
                dd_list_yd.Enabled = True
                dd_select_on.Enabled = True
                TB1.Enabled = False
                TB1.Style.Add("BACKGROUND-COLOR", "white")
                TB2.Enabled = False
                TB2.Style.Add("BACKGROUND-COLOR", "white")
                txtbonded_now_onhand.Enabled = False
                txtbonded_now_onhand.Style.Add("BACKGROUND-COLOR", "white")
            End If
        End Sub

        Sub cleartext(ByVal intstate As Int16)
            If intstate = 0 Then                     '�D�d�ߪ��A
                dd_org_name.SelectedIndex = -1
                dd_cost_name.SelectedIndex = -1
                txt_org_no.Value = ""
                txt_cost_no.Value = ""
                Text1.Value = ""
                dd_list_yd.SelectedItem.Text = ""
                dd_select_on.SelectedItem.Text = ""
                TB1.Text = ""
                TB2.Text = ""
                txtbonded_now_onhand.Text = ""
            Else
            End If
        End Sub

        Private Sub btn3_ab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3_ab.Click
            btn_state(3)
            textbox_state(2)
            cleartext(0)
            Text2.Value = ""
            Text3.Value = ""
        End Sub

        Private Sub btn2_sav_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2_sav.Click
            If TB2.Text = "" Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ƶ����i����');</script>")
                Exit Sub
            End If

            Dim CHECK_ONHAND_1 As String = (CDec(Text2.Value) + CDec(Text3.Value) - CDec(TB1.Text)).ToString
            Dim strsql3 As String
            Try
                strsql3 = String.Format("update FWEB_ONL_ONHAND set PRE_ONHAND='{1}', NOW_WASTE='{2}'," & _
                        " NOW_ONHAND='{3}', BONDED_NOW_ONHAND='{4}', CHECK_ONHAND='{5}',REMARK='{6}',MDATE=sysdate,MUSER='{7}'" & _
                        " where org = '{8}' and period_name = to_date('{0}','yyyy/MM/dd') and COST_CENTER = '{9}' and TRANSACTION_TYPE='{10}' and PRODUCT_NUM='{11}'", _
                        edtDateFrom.Value.Trim, Text2.Value.Trim, Text3.Value.Trim, TB1.Text, txtbonded_now_onhand.Text, CHECK_ONHAND_1, TB2.Text, Context.User.Identity.Name, _
                        txt_org_no.Value.Trim, txt_cost_no.Value.Trim, dd_list_yd.SelectedItem.Text, Text1.Value)
                db.ExecuteSQL(strsql3)
            Catch ex As Exception
                Throw ex
                Exit Sub
            End Try
            btn_state(4)
            textbox_state(2)
            cleartext(0)
            loaddata(ViewState("strsql"))
            Text2.Value = ""
            Text3.Value = ""
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ק令�\!');</script>")
        End Sub

        Sub sysdate()
            Dim ds As New DataSet
            Try
                Dim sqlstr As String
                sqlstr = " SELECT A.ORG, A.PERIOD_MOTH FROM FWEB_ONL_CALENDAR A,(SELECT T.ORG FROM FWEB_USER_ORGAU_D O, FWEB_ONL_DEPT T" & _
                         " WHERE O.USER_ID = '" + Context.User.Identity.Name + "' AND O.SYST_NO = 'FWEB' AND O.PROJ_NO = 'ONL' AND DECODE(O.ORG, 'ALL', T.ORG, O.ORG) = T.ORG " & _
                         " AND DECODE(O.COST_CENTER, 'ALL', T.COST_CENTER, O.COST_CENTER) = T.COST_CENTER AND ROWNUM = 1) B" & _
                         " WHERE A.ORG = B.ORG AND A.CLOSE_DATE IS NULL"
                ds = db.FillDataSet(sqlstr, 2)
                If ds.Tables(0).Rows.Count <> 0 Then
                    txt_org_no.Value = ds.Tables(0).Rows(0).Item("ORG")
                    edtDateFrom.Value = ds.Tables(0).Rows(0).Item("PERIOD_MOTH")
                End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
        End Sub

        Sub check_data2()
            Dim ds As New DataSet
            Try
                ds = db.FillDataSet(ViewState("strsql"), 2)
                If Not IsDBNull(ds.Tables(0).Rows(0).Item("org")) Then
                    txt_org_no.Value = ds.Tables(0).Rows(0).Item("org")
                End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
        End Sub

        Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
            dg.CurrentPageIndex = e.NewPageIndex
            loaddata(ViewState("strsql"))
        End Sub
        Private Sub btn5_excel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5_excel.Click
            Response.Write("<script>window.open(' " + EXPORT_EXCEL() + " ')</script>")
        End Sub

        Function EXPORT_EXCEL() As String       '(ByVal source, ByVal e)
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_APPROVE_EXCEL.xls"
            Dim savepath As String = PublicM.GetSessionDataRoot(Context) + "ONL_APPROVE_EXCEL.xls" 'xls�s����|,�n�PJSsavepath�P
            Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(Context) + "ONL_APPROVE_EXCEL.xls" 'JavaScript�}��xls���|,�n�Psavepath�P
            Try
                '�w�q�@�ӷs���u�@ï
                oBooks = oExcel.Workbooks
                oBooks.Open(sTemplate)
                oBook = oBooks.Item(1)
                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells
                '��R���
                Dim ds As DataSet
                ds = db.FillDataSet(ViewState("strsql"), 2)

                Dim x, y As Integer
                Dim i As Integer = ds.Tables(0).Rows.Count
                Dim j As Int16 = 0
                For y = 0 To ds.Tables(0).Columns.Count - 1
                    Select Case ds.Tables(0).Columns(y).ColumnName
                        Case "PERIOD_NAME"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("PERIOD_NAME").ToString.Substring(0, 10)
                                j = j + 1
                            Next
                        Case "ORG"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("ORG").ToString
                                j = j + 1
                            Next
                        Case "TRANSACTION_TYPE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 4) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER_NAME"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 5) = ds.Tables(0).Rows(x).Item("COST_CENTER_NAME").ToString
                                j = j + 1
                            Next
                        Case "BONDED_FLAG"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 6) = ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString

                                j = j + 1
                            Next
                        Case "PRODUCT_DESC"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                                j = j + 1
                            Next
                        Case "UOM"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString

                                j = j + 1
                            Next
                        Case "PRE_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString

                                j = j + 1
                            Next
                        Case "NOW_WASTE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString

                                j = j + 1
                            Next
                        Case "NOW_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString

                                j = j + 1
                            Next
                        Case "BONDED_NOW_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString

                                j = j + 1
                            Next
                        Case "CHECK_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("CHECK_ONHAND").ToString

                                j = j + 1
                            Next
                        Case "REMARK"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 15) = ds.Tables(0).Rows(x).Item("REMARK").ToString

                                j = j + 1
                            Next
                        Case "IMPORT_MARK"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 16) = ds.Tables(0).Rows(x).Item("IMPORT_MARK").ToString

                                j = j + 1
                            Next
                        Case "IMPORT_DATE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 17) = ds.Tables(0).Rows(x).Item("IMPORT_DATE").ToString

                                j = j + 1
                            Next
                        Case "IMPORT_USER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 18) = "'" + ds.Tables(0).Rows(x).Item("IMPORT_USER").ToString

                                j = j + 1
                            Next
                        Case "APPROVE_MARK"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 19) = ds.Tables(0).Rows(x).Item("APPROVE_MARK").ToString
                                j = j + 1
                            Next
                        Case "APPROVE_DATE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 20) = ds.Tables(0).Rows(x).Item("APPROVE_DATE").ToString
                                j = j + 1
                            Next
                        Case "APPROVE_USER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 21) = "'" + ds.Tables(0).Rows(x).Item("APPROVE_USER").ToString
                                j = j + 1
                            Next
                        Case "MDATE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 22) = "'" + ds.Tables(0).Rows(x).Item("MDATE").ToString
                                j = j + 1
                            Next
                        Case "MUSER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 23) = "'" + ds.Tables(0).Rows(x).Item("MUSER").ToString
                                j = j + 1
                            Next
                        Case "CDATE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 24) = "'" + ds.Tables(0).Rows(x).Item("CDATE").ToString
                                j = j + 1
                            Next
                        Case "CUSER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 25) = "'" + ds.Tables(0).Rows(x).Item("CUSER").ToString
                                j = j + 1
                            Next
                    End Select
                Next

                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                ' oExcel.DisplayAlerts = True

                Return JSsavepath
            Catch ex As Exception
                Throw ex
            Finally
                ' oExcel.Application.Quit()
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If

                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If

                'GC.Collect()

            End Try
            '  GC.Collect()
        End Function

        Private Sub btn7_form_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn7_form.Click
            '���ɮ榡
            Response.Write("<script>window.open('ONL_Template/ONL_APPROVE_SPEC.xls ')</script>")
        End Sub

        Private Sub btn6_tran_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn6_tran.Click
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "open", "<script language='JavaScript'>window.open('FWEB_FIND_INPUT3.aspx','','height=180,width=430') </script>")
            btn8_excel.Enabled = True
        End Sub

        Private Sub btn8_excel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn8_excel.Click
            Response.Write("<script>window.open(' " + EXPORT_EXCEL2() + " ')</script>")
        End Sub
        Function EXPORT_EXCEL2() As String       '(ByVal source, ByVal e)
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_APPROVE_ERROR.xls"
            Dim savepath As String = PublicM.GetSessionDataRoot(Context) + "ONL_APPROVE_ERROR.xls" 'xls�s����|,�n�PJSsavepath�P
            Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(Context) + "ONL_APPROVE_ERROR.xls" 'JavaScript�}��xls���|,�n�Psavepath�P


            Try
                '�w�q�@�ӷs���u�@ï
                oBooks = oExcel.Workbooks
                oBooks.Open(sTemplate)
                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                '��R���
                Dim ds As DataSet
                Dim sqlstr As String
                sqlstr = "select * from FWEB_ONL_TRANSFER_ERROR where MUSER='" + Context.User.Identity.Name + "' and FUNC_NO='ONL_APPROVE'"
                ds = db.FillDataSet(sqlstr, 2)

                Dim x, y As Integer
                Dim i As Integer = ds.Tables(0).Rows.Count
                Dim j As Int16 = 0
                'Try
                For y = 0 To ds.Tables(0).Columns.Count - 1
                    Select Case ds.Tables(0).Columns(y).ColumnName
                        Case "REASON"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("REASON").ToString
                                j = j + 1
                            Next
                        Case "PERIOD_NAME"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 2) = Format(ds.Tables(0).Rows(x).Item("PERIOD_NAME"), "yyyy/MM/dd").ToString
                                j = j + 1
                            Next
                        Case "ORG"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("ORG").ToString
                                j = j + 1
                            Next

                        Case "TRANSACTION_TYPE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 4) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 5) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                                j = j + 1
                            Next
                        Case "BONDED_FLAG"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 6) = "'" + ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_DESC"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                                j = j + 1
                            Next
                        Case "UOM"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString
                                j = j + 1
                            Next
                        Case "PRE_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString
                                j = j + 1
                            Next
                        Case "NOW_WASTE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString
                                j = j + 1
                            Next
                        Case "NOW_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString
                                j = j + 1
                            Next
                        Case "BONDED_NOW_ONHAND"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString
                                j = j + 1
                            Next
                        Case "REMARK"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("REMARK").ToString
                                j = j + 1
                            Next
                        Case "MDATE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 15) = "'" + Format(ds.Tables(0).Rows(x).Item("MDATE"), "yyyy/MM/dd").ToString
                                j = j + 1
                            Next
                        Case "MUSER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 16) = "'" + ds.Tables(0).Rows(x).Item("MUSER").ToString
                                j = j + 1
                            Next
                        Case "CDATE"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                If Not IsDBNull(ds.Tables(0).Rows(x).Item("CDATE")) Then
                                    oCells(j + 2, 17) = "'" + ds.Tables(0).Rows(x).Item("CDATE").ToString
                                Else
                                    oCells(j + 2, 17) = ""
                                End If
                                j = j + 1
                            Next
                        Case "CUSER"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 18) = "'" + ds.Tables(0).Rows(x).Item("CUSER").ToString
                                j = j + 1
                            Next

                    End Select
                Next
                'Catch ex As Exception
                '    Throw ex
                'End Try
                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                ' oExcel.DisplayAlerts = True

                Return JSsavepath
            Catch ex As Exception
                Throw ex
            Finally
                ' oExcel.Application.Quit()
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If


                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If

                GC.Collect()

            End Try
            GC.Collect()
        End Function



        Protected Sub dg_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg.SelectedIndexChanged

        End Sub
    End Class

End Namespace
