﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DB;
using Oracle.ManagedDataAccess.Client;


public partial class FWEB_ONL_IDLE2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }





    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = @"select case when (c.now_onhand-a.now_onhand)>0 then 'N'  else 'Y' end as 連續三月未領用,
        c.period_name,c.org,c.cost_center,c.product_num,c.product_desc,c.uom,a.now_onhand as 前月結存,
        a.now_waste as 前月領用,b.now_onhand as 上月結存"",b.now_waste as 上月領用
        from 
       (select * from fweb_onl_onhand_V where org='07' and cost_center='3081' and period_name =to_date('2021-12-01','yyyy-MM-dd'))c,
       (select * from fweb_onl_onhand_V where org='07' and cost_center='3081' and period_name =to_date('2021-12-01','yyyy-MM-dd'))b,
       (select * from fweb_onl_onhand_V where org='07' and cost_center='3081' and period_name =to_date('2021-10-01','yyyy-MM-dd'))a
       
       where c.product_num=b.product_num and b.product_num=a.product_num";
        bindData(sql);



    }

    private void bindData(string sql){
        GridView1.Dispose();

        GridView1.DataSource=getData(sql);
    
    }
    private DataTable getData(string sql) {
        DataTable dt = new DataTable();

        

        
        return dt;
    
    
    }
}

