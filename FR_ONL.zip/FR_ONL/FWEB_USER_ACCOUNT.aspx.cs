﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;



public partial class FWEB_USER_ACCOUNT : System.Web.UI.Page
{

    string sqltext;
    DataSet ds;
    DataView dv;

    OleDbConnection OLEDBCONN  =new OleDbConnection (System.Configuration.ConfigurationManager.AppSettings.Get("conn"));


    protected void Page_Load(object sender, EventArgs e)
    {
       

        //初始化
        if (!IsPostBack) {
            sqltext = "select * from fweb_user_login_m";
            bindData(sqltext);
            Check_State(1);       
        
        }

    }
    /// <summary>
    /// 更新各控制項狀態
    /// </summary>
    private void Check_State(int state){

        switch(state){
            case 1:
                User_LV_List.Enabled = false;
                User_Group_List.Enabled = false;
                Leave_Chk.Enabled = false;

                break;
            default:
                break;              
        }        
    }
    
    protected DataSet FillDataSet(string sql){
        DataSet ds=new DataSet();
        OleDbDataAdapter da =new OleDbDataAdapter(sql,OLEDBCONN);
        try{
            da.Fill(ds);
            
            }

            catch {}
       
        finally{
            OLEDBCONN.Close();
            if(ds!=null){
            
                ds.Dispose();
            }                            
        }
        return ds;

    }

    private void bindData(string sql) {

        GridView1.Dispose();
        
        ds = FillDataSet(sql);
        dv = ds.Tables[0].DefaultView;
        GridView1.DataSource = dv;
        GridView1.DataBind();
        GridView1.AllowPaging = true;

    }

    /// <summary>
    /// 搜尋
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>

    protected void Search_btn_Click(object sender, EventArgs e)
    {
        Dictionary<string, string> keys = new Dictionary<string, string>();
        keys.Add("USER_NAME",TXT_USER_NAME.Text);
        keys.Add("USER_ID", TXT_USER_ID.Text);
        keys.Add("E_MAIL", TXT_EMAIL.Text);
        keys.Add("USER_LEVEL", User_LV_List.SelectedValue);
        string sql = "select * from FWEB_USER_LOGIN_M where 1=1";
        foreach (var data in keys) {
            if (data.Value.ToString() != "" && data.Value != null) {
                sql += string.Format(" and {0} like '%{1}%'", data.Key, data.Value);            
            }        
        }
        System.Diagnostics.Debug.WriteLine("sql=" + sql);

        bindData(sql);
        Check_State(1);
        


    }


    protected void Add_btn_Click(object sender, EventArgs e)
    {

    }
    protected void Edit_btn_Click(object sender, EventArgs e)
    {
        //GridView1.SetEditRow(GridView1.SelectedRow.RowIndex);
       // GridView1.EditIndex = GridView1.SelectedRow.RowIndex;
        
    }
    protected void Delete_btn_Click(object sender, EventArgs e)
    {

    }


    protected void GV_Row_Edit() { 
    
    
    }
}