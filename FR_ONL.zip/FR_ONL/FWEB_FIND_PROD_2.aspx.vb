Imports System.Data.OleDb


Namespace FR

Partial Class FWEB_FIND_PROD_2
    Inherits System.Web.UI.Page

        'Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim strtype As String, strvalue As String
    Public ascxid As String = ""
    Public type As String = ""
    Public headloading As String = ""
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsNothing(Request.QueryString("ascxid")) Then
            ascxid = Request.QueryString("ascxid")
            type = Request.QueryString("type")
        End If
            If Not IsPostBack Then
                loadorg()
                strtype = DropDownList1.SelectedValue
                ViewState("string") = ""
                bind_data(ViewState("string"))
            End If
    End Sub
    Sub loadorg()
            'Dim sqlstr As String
            'sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
            '" WHERE A.ORG = B.ORG AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
            '" AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
            'dd_org_name.DataSource = db.FillDataSet(sqlstr).Tables(0)
            dd_org_name.DataSource = db.loadorg(Context.User.Identity.Name) '--2022 by kevin
            dd_org_name.DataValueField = "�s�X"
            dd_org_name.DataTextField = "�W��"
            dd_org_name.DataBind()
            dd_org_name.Items.Insert(0, "")
    End Sub
    Private Sub DataGrid1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.ItemCommand
        If e.CommandName = "ReturnValue" Then
            If type = "a" Or type = "" Then
                    If (Not Me.ClientScript.IsStartupScriptRegistered("supplier_ida")) Then
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "getida", "<script>window.dialogArguments.document.all('Text1').value='" & e.Item.Cells(1).Text & "';window.close(this);</script>")
                        'RegisterStartupScript("schserno", "<script>window.returnValue='" & e.Item.Cells(1).Text.Replace("'", "\'") & "';window.close(this);</script>")
                    End If
            End If
        End If
    End Sub
    Private Sub DataGrid1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            e.Item.Attributes.Add("onclick", "javascript:document.all('" & e.Item.Cells(0).Controls(1).ClientID & "').click();")
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub
    Sub bind_data(ByVal str1 As String)
        Dim strquery As String
        strquery = "SELECT C.ORG, A.SEGMENT1 AS PRODUCT_NUM, A.DESCRIPTION, A.PRIMARY_UOM_CODE AS UNIT FROM MTL_SYSTEM_ITEMS@PROD A, " & _
                   "(SELECT DISTINCT PRODUCT_NUM_FIRST FROM FWEB_ONL_TRANSACTION_TYPE) B, " & _
                   "UCCST_ORG_T C, FWEB_USER_ORGAU_D D WHERE A.ORGANIZATION_ID = C.ORG_ID " & _
                   "AND SUBSTR(A.SEGMENT1,1,1) = B.PRODUCT_NUM_FIRST AND C.ORG = DECODE(D.ORG,'ALL',C.ORG,D.ORG) " & _
                   "AND D.SYST_NO = 'FWEB' AND D.PROJ_NO = 'ONL' AND D.USER_ID = '" + context.User.Identity.Name + "' " & _
                   "AND C.ORG LIKE '" + Trim(txt_org_no.Value) + "%'" & str1 & _
                   "ORDER BY A.SEGMENT1, C.ORG"
        With db.FillDataSet(strquery).Tables(0)
            DataGrid1.DataSource = .DefaultView
            DataGrid1.DataBind()
            DataGrid1.Height = Unit.Pixel(1)
            AspNetPager1.RecordCount = .Rows.Count
            AspNetPager1.CustomInfoText = GetPageInfo(AspNetPager1)
        End With
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        DataGrid1.CurrentPageIndex = 0
        strtype = DropDownList1.SelectedValue
        strvalue = TextBox1.Text
        viewstate("string") = " and " & DropDownList1.SelectedValue & " like '" + Trim(TextBox1.Text) + "%'"
        bind_data(viewstate("string"))
        'bind_data(strtype, strvalue, DataGrid1)
    End Sub
    Private Sub AspNetPager1_PageChanged(ByVal src As System.Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs) Handles AspNetPager1.PageChanged
        DataGrid1.EditItemIndex = -1
        DataGrid1.CurrentPageIndex = 0
        DataGrid1.CurrentPageIndex = e.NewPageIndex - 1
        AspNetPager1.CurrentPageIndex = e.NewPageIndex
        bind_data(viewstate("string"))
    End Sub
    Function GetPageInfo(ByRef p As Wuqi.Webdiyer.AspNetPager) As String
        Return String.Format _
        ("��<font color=red><b>{0}</b></font>��&nbsp&nbsp�@<font color=blue><b>{1}</b></font>��<font color=blue><b>{2}</b></font>��", p.CurrentPageIndex.ToString, p.PageCount.ToString, p.RecordCount.ToString)
    End Function


        Protected Sub DataGrid1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged

        End Sub
    End Class

End Namespace
