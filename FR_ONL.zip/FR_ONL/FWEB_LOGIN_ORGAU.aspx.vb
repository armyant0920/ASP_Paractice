Imports System.TEXT


Namespace FR

Partial Class FWEB_LOGIN_ORGAU
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
                btn1.Attributes.Add("onclick", "var st=window.showModalDialog('FWEB_FIND_USER.aspx?level=a',window,'dialogTop=160px;dialogWidth=640px;dialogHeight=480px;help:no;status:no');if(st!=undefined){document.all('txtUserID').value=st;user_name();} else {return false;}")
            LoadProj()
            LoadOrg()
            LoadCostCenter()
        End If
    End Sub
#Region "�M��,�t�O,��������"

    '�M��
    Sub LoadProj()
        Dim sqlstr As String
        sqlstr = "SELECT distinct proj_no, proj_name " & _
                 "  FROM fweb_system s " & _
                 " WHERE s.syst_no = 'FWEB' "
        DL_projname.DataSource = db.FillDataSet(sqlstr).Tables(0)
        DL_projname.DataValueField = "proj_no"
        DL_projname.DataTextField = "proj_name"
        DL_projname.DataBind()
        DL_projname.Items.Insert(0, "")
    End Sub

    '�t�O
    Sub LoadOrg()
            Dim sqlstr As String = ""
        sqlstr = "SELECT ORG, ORG_NAME FROM UCCST_ORG_T " & _
                 "UNION " & _
                 "SELECT 'ALL' AS ORG, 'ALL' AS ORG_NAME FROM DUAL"

        DL_orgname.DataSource = db.FillDataSet(sqlstr).Tables(0)
        DL_orgname.DataValueField = "org"
        DL_orgname.DataTextField = "org_name"
        DL_orgname.DataBind()
        DL_orgname.Items.Insert(0, "")
    End Sub

    '��������
    Sub LoadCostCenter()
        Dim sqlstr As String
        sqlstr = "SELECT DISTINCT COST_CENTER, COST_CENTER_NAME FROM FWEB_CE_ALL_V WHERE COST_CENTER <> '0000' " & _
                 "UNION " & _
                 "SELECT 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM DUAL"

        DL_costname.DataSource = db.FillDataSet(sqlstr).Tables(0)
        DL_costname.DataValueField = "cost_center"
        DL_costname.DataTextField = "cost_center_name"
        DL_costname.DataBind()
        DL_costname.Items.Insert(0, "")
    End Sub
#End Region

    Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    '�d��
    Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
        Dim sqlstr As String
        L_frist.Text = "first"
        sqlstr = "SELECT DISTINCT D.USER_ID, M.USER_NAME, D.SYST_NO, S.SYST_NAME, D.PROJ_NO, S.PROJ_NAME, D.ORG, T.ORG_NAME, D.COST_CENTER, C.COST_CENTER_NAME" & _
                 "  FROM FWEB_USER_ORGAU_D D, " & _
                 "       FWEB_USER_LOGIN_M M, " & _
                 "       (SELECT DISTINCT SYST_NO, SYST_NAME, PROJ_NO, PROJ_NAME FROM FWEB_SYSTEM) S, " & _
                 "       (SELECT 'ALL' AS ORG, 'ALL' AS ORG_NAME FROM DUAL " & _
                 "        UNION " & _
                 "        SELECT ORG, ORG_NAME FROM UCCST_ORG_T) T, " & _
                 "       (SELECT 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM DUAL " & _
                 "        UNION " & _
                 "        SELECT DISTINCT COST_CENTER, COST_CENTER_NAME FROM FWEB_CE_ALL_V) C " & _
                 " WHERE D.USER_ID = M.USER_ID " & _
                 "   AND D.SYST_NO = S.SYST_NO " & _
                 "   AND D.PROJ_NO = S.PROJ_NO " & _
                 "   AND D.ORG = T.ORG(+) " & _
                 "   AND D.COST_CENTER = C.COST_CENTER(+) " & _
                 "   AND D.USER_ID LIKE '" + Me.txtUserID.Value + "%'" & _
                 "   AND D.PROJ_NO LIKE '" + Me.TB_projid.Value + "%'" & _
                 "   AND D.ORG LIKE '" + Me.Tb_orgid.Value + "%'" & _
                 "   AND D.COST_CENTER LIKE '" + Me.Tb_costid.Value + "%'" & _
                 " ORDER BY D.USER_ID, D.SYST_NO, D.PROJ_NO, D.ORG, D.COST_CENTER"
        ViewState("sqlstr") = sqlstr
        loaddata(sqlstr)
    End Sub

    Sub loaddata(ByVal sql As String)
        Dim ds As DataSet
        Dim dv As DataView
        ds = db.FillDataSet(sql)
        Aspnetpager1.RecordCount = ds.Tables(0).Rows.Count
        dv = ds.Tables(0).DefaultView
        dg.DataSource = dv
        dg.DataBind()
        dg.CurrentPageIndex = 0
        Label9.Text = "�@ <font face=verdana >" + ds.Tables(0).Rows.Count.ToString() + _
       "</font> ���O��<font face=verdana >," + (dg.CurrentPageIndex + 1).ToString() + _
       "</font> / <font face=verdana >" + dg.PageCount.ToString() + _
       "</font>��<font face=verdana>,&nbsp;</font>����<font face=verdana>" + dg.Items.Count.ToString() + "</font>���O��"
        dg.Height = Unit.Pixel(1)
    End Sub

    '�s�W
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
         L_edit_add.Text = "add"
        Me.txtUserID.Disabled = False
        textstate("edit")
    End Sub

    Function check_userlevel() As Boolean
        If Me.txtUserID.Value <> "" Then
            If db.FillDataSet("select *from fweb_user_login_m where user_id='" + Me.txtUserID.Value + "' and user_level='S' ").Tables(0).Rows.Count = 0 Then
                Return True
            Else
                Return False
            End If
            End If
            Return True
    End Function

    Sub textstate(ByVal ss As String)
        If ss = "edit" Then
            Me.txtUserID.Value = ""
            Me.txtUserID.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.txtUserName.Value = ""
            Me.txtUserName.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.Tb_orgid.Value = ""
            Me.Tb_orgid.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.DL_orgname.Value = ""
            Me.DL_orgname.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.Tb_costid.Value = ""
            Me.DL_costname.Items(Me.DL_costname.SelectedIndex).Text = ""
            Me.Tb_costid.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.DL_costname.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.TB_projid.Value = ""
            Me.DL_projname.Value = ""
            Me.TB_projid.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.DL_projname.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.txtUserName.Value = ""
        ElseIf ss = "cancel" Then
            Me.txtUserID.Value = ""
            Me.txtUserID.Style.Add("BACKGROUND-COLOR", "white")
            Me.txtUserName.Value = ""
            Me.txtUserName.Style.Add("BACKGROUND-COLOR", "white")
            Me.Tb_orgid.Style.Add("BACKGROUND-COLOR", "white")
            Me.DL_orgname.Style.Add("BACKGROUND-COLOR", "white")
            Me.Tb_costid.Style.Add("BACKGROUND-COLOR", "white")
            Me.DL_costname.Style.Add("BACKGROUND-COLOR", "white")
            Me.TB_projid.Style.Add("BACKGROUND-COLOR", "white")
            Me.DL_projname.Style.Add("BACKGROUND-COLOR", "white")
                Me.Tb_costid.Value = ""
                Me.DL_projname.Items(Me.DL_projname.SelectedIndex).Text = ""
            Me.TB_projid.Value = ""
                Me.Tb_orgid.Value = ""
                Me.DL_orgname.Items(Me.DL_orgname.SelectedIndex).Text = ""
            Me.DL_orgname.Value = ""
            Me.DL_costname.Items(Me.DL_costname.SelectedIndex).Text = ""
        End If

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim sqlstr As String
        If check_userlevel() = False Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('�ӥΤᤣ�ݭn�إ߼t�O���������v��!')</script>")
                Exit Sub
            End If
            If Me.txtUserID.Value <> "" And Me.TB_projid.Value <> "" And Me.Tb_orgid.Value <> "" And Me.Tb_costid.Value <> "" Then
                If Me.L_edit_add.Text = "add" Then
                    sqlstr = "insert into fweb_user_orgau_d(user_id,syst_no,proj_no,org,cost_center,muser,mdate) " & _
                    " values('" + Me.txtUserID.Value.Trim + "','" + Me.TextBox2.Text.Trim + "','" + Me.TB_projid.Value.Trim + "','" + Me.Tb_orgid.Value.Trim + "','" + Me.Tb_costid.Value.Trim + "','" + Context.User.Identity.Name + "',sysdate)"
                    db.ExecuteSQL(sqlstr)
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('�s�W���\!')</script>")
                    textstate("cancel")
                ElseIf Me.L_edit_add.Text = "edit" Then
                    sqlstr = "update fweb_user_orgau_d set proj_no='" + Me.TB_projid.Value.Trim + "',org='" + Me.Tb_orgid.Value.Trim + "',cost_center='" + Me.Tb_costid.Value.Trim + "' " & _
                    " where user_id='" + Me.txtUserID.Value.Trim + "' and proj_no='" + Me.L_proj_edit.Text.Trim + "' and org='" + Me.L_org_eidt.Text.Trim + "' and cost_center='" + Me.L_cost_edit.Text.Trim + "'"
                    db.ExecuteSQL(sqlstr)
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('�ק令�\!')</script>")
                    textstate("cancel")
                End If
                If L_frist.Text = "first" Then
                    loaddata(ViewState("sqlstr"))
                End If
            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('�ж�g���㪺���!')</script>")
            End If
    End Sub

    'Sub cleartext()
    '    Me.TB_projid.Value = ""
    '    Me.Tb_orgid.Value = ""
    '    Me.Tb_costid.Value = ""
    '    Me.DL_projname.Value = ""
    '    Me.DL_orgname.Value = ""
    '    Me.DL_costname.Value = ""
    'End Sub
    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        textstate("cancel")
        Me.txtUserID.Disabled = False
            Me.txtUserName.Disabled = False
            If ViewState("sqlstr") <> "" Then
                loaddata(ViewState("sqlstr"))
            End If
        End Sub

    Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
        If e.CommandName = "edit" Then
            Me.L_edit_add.Text = "edit"
            Me.txtUserID.Value = e.Item.Cells(2).Text
            Me.TB_projid.Value = e.Item.Cells(5).Text
            Me.DL_projname.Items(Me.DL_projname.SelectedIndex).Text = e.Item.Cells(6).Text
            Me.Tb_orgid.Value = e.Item.Cells(7).Text
            If Me.Tb_orgid.Value = "ALL" Then
                Me.DL_orgname.Items(Me.DL_orgname.SelectedIndex).Text = "ALL"
            Else
                Me.DL_orgname.Items(Me.DL_orgname.SelectedIndex).Text = e.Item.Cells(8).Text
            End If
            Me.Tb_costid.Value = e.Item.Cells(9).Text
            If Me.Tb_costid.Value = "ALL" Then
                Me.DL_costname.Items(Me.DL_costname.SelectedIndex).Text = "ALL"
            Else
                Me.DL_costname.Items(Me.DL_costname.SelectedIndex).Text = e.Item.Cells(10).Text
            End If
            L_proj_edit.Text = e.Item.Cells(5).Text
            L_org_eidt.Text = e.Item.Cells(7).Text
            L_cost_edit.Text = e.Item.Cells(9).Text
            Me.TB_projid.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.DL_projname.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.Tb_orgid.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.DL_orgname.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.Tb_costid.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.DL_costname.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Me.txtUserID.Disabled = True
            Me.txtUserName.Disabled = True
        Else
            If e.CommandName = "delete" Then
                Dim strsql As String
                strsql = "DELETE FROM FWEB_USER_ORGAU_D " & _
                         " WHERE USER_ID = '" + e.Item.Cells(2).Text + "'" & _
                         "   AND SYST_NO = '" + e.Item.Cells(3).Text + "'" & _
                         "   AND PROJ_NO = '" + e.Item.Cells(5).Text.Trim + "' " & _
                         "   AND ORG = '" + e.Item.Cells(7).Text.Trim + "' " & _
                         "   AND COST_CENTER = '" + e.Item.Cells(9).Text.Trim + "'"
                db.ExecuteSQL(strsql)
                If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                    dg.CurrentPageIndex -= 1
                    loaddata(viewstate("sqlstr"))
                Else
                    loaddata(viewstate("sqlstr"))
                End If
            End If
        End If
    End Sub

    '����
    Private Sub Aspnetpager1_PageChanged(ByVal src As Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs) Handles Aspnetpager1.PageChanged
        dg.CurrentPageIndex = 0
        dg.CurrentPageIndex = e.NewPageIndex - 1
        Aspnetpager1.CurrentPageIndex = e.NewPageIndex
        loaddata(ViewState("sqlstr"))
    End Sub

    '��Excel
    Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
        Dim vColData As String
            Dim i, j, ascii As Integer
        Dim ds As New DataSet

        Response.AddHeader("content-disposition", "attachment;filename=ORGAU.csv")
        Response.ContentType = "application/ms-excel" '"application/octet-stream"        
        Response.ContentEncoding = Encoding.UTF8
        Response.Charset = "utf-8"
        Dim sw As New System.IO.StreamWriter(Response.OutputStream, Encoding.UTF8)

        '���oQUERY�����
        ds = db.FillDataSet(ViewState("sqlstr"))

        '��J���W��
        For i = 0 To ds.Tables(0).Columns.Count - 1
            Select Case ds.Tables(0).Columns(i).ColumnName
                Case "USER_ID"
                    sw.Write("�ϥΪ̥N��")
                Case "USER_NAME"
                    sw.Write("�ϥΪ̦W��")
                Case "SYST_NO"
                    sw.Write("�t�ΥN�X")
                Case "SYST_NAME"
                    sw.Write("�t�ΦW��")
                Case "PROJ_NO"
                    sw.Write("�M�ץN�X")
                Case "PROJ_NAME"
                    sw.Write("�M�צW��")
                Case "ORG"
                    sw.Write("�t�O")
                Case "ORG_NAME"
                    sw.Write("�t�O�W��")
                Case "COST_CENTER"
                    sw.Write("��������")
                Case "COST_CENTER_NAME"
                    sw.Write("�������ߦW��")
            End Select
            sw.Write(",")
        Next
        sw.WriteLine()

        '��J��Ƥ��e
        For i = 0 To ds.Tables(0).Rows.Count - 1
            For j = 0 To ds.Tables(0).Columns.Count - 1
                vColData = ""
                '�N�S���r������,�H�K��Xxls�|����
                For Each vChar As Char In ds.Tables(0).Rows(i)(j).ToString.Replace(" ", "-").Replace(",", "-").ToCharArray
                    ascii = Convert.ToInt32(vChar)
                    If ascii >= 32 Then
                        vColData = vColData + vChar
                    End If
                Next

                sw.Write(Chr(27) & vColData)

                sw.Write(",")
            Next
            sw.WriteLine()
        Next

        sw.Close()
        Response.End()

    End Sub
End Class

End Namespace
