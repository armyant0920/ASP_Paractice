Imports System.Data.OleDb
Imports System.Xml
Imports System.Data


Namespace FR

Partial Class FRM_FILLORGNAME
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        Dim txtid As String = Server.UrlDecode(Request.QueryString("txtid"))
        Dim a As Array
        a = Split(txtid, ",")
        If a(0) = "" Then
            a(0) = ""
        End If
        If a(1) = "" Then
            a(1) = ""
        End If
        Dim sqltemp, sqltemp2 As String
        Dim TempDS As New DataSet
        Try
           sqltemp = " select * from FWEB_User_orgau_d d where d.user_id = '" + a(0) + "' and d.syst_no = 'FWEB' and d.proj_no = '" + a(1) + "'"
           TempDS = db.FillDataSet(sqltemp)
           If TempDS.Tables(0).Rows.Count = 0 Then
               sqltemp2 = "select * from (select 'ALL' org,'ALL' org_name,'1' id from dual union " & _
                          " SELECT distinct org, org_name,'2' id FROM uccst_org_t c  where not exists (select * from FWEB_User_orgau_d d" & _
                          " where d.user_id = '" + a(0) + "' and d.syst_no = 'FWEB' and d.proj_no = '" + a(1) + "' and d.org = c.org) order by org) order by id"
           Else
               sqltemp2 = "  SELECT distinct org, org_name FROM uccst_org_t c  where not exists (select * from FWEB_User_orgau_d d" & _
                          " where d.user_id = '" + a(0) + "' and d.syst_no = 'FWEB' and d.proj_no = '" + a(1) + "' and d.org = c.org) order by org"
           End If
           Dim con As OleDb.OleDbConnection = New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("conn").ToString())
           Dim da As New OleDbDataAdapter(sqltemp2, con)
           Dim ds As New DataSet("address")
           da.Fill(ds, "costname")
           Dim writer As XmlTextWriter = New XmlTextWriter(Response.OutputStream, Response.ContentEncoding)
           writer.Formatting = Formatting.Indented
           writer.Indentation = 4
           writer.IndentChar = " "
           ds.WriteXml(writer)
           writer.Flush()
           Response.End()
           writer.Close()
        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

End Class

End Namespace
