Namespace FR

Partial Class FWEB_LOGIN_ORGCE
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            btn1.Attributes.Add("onclick", "var st=window.showModalDialog('FWEB_FIND_ORG.aspx',window,'dialogTop=160px;dialogWidth=640px;dialogHeight=480px;help:no;status:no');if(st!=undefined){document.all('TXT_ORG_NO').value=st;document.Form1.btn1.click();} else {return false;}")
            TXT_ORG_NO.Attributes.Add("onblur", "if (document.all('TXT_ORG_NO').value !=''){document.Form1.Button5.click();}")

            viewstate("strquery") = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
                                    "FROM FWEB_CE_ALL_V WHERE ORG LIKE '%" + Trim(TXT_ORG_NO.Text) + "%' AND CODE='" + DD_CODE.SelectedValue + "' ORDER BY ORG,COST_CENTER"
            'btn1.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_ORG.aspx?type=a", 640, 480))
            bind_data()
            btn_state(0)
            TXT_USER_ID.Disabled = False
        End If

    End Sub

   
    Private Sub BN_SAV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SAV.Click
            Dim strsql As String
        Label()
        If check_text() = False Then
            Exit Sub
        End If
        '�s�説�A
        If TXT_ORG_NO.ReadOnly = True Then
            If TXT_MO.Text = "P" Then
                    strsql = String.Format("update UCAPP_ORG_CE_TYPE_T@UCST2 set CODE='{0}',USER_ID='{1}',COST_CENTER_NAME='{2}' where ORG='{3}' AND COST_CENTER='{4}'", Trim(DD_CODE.SelectedValue), Context.User.Identity.Name, Trim(TXT_CE_NAME.Value), Trim(TXT_ORG_NO.Text), Trim(TXT_CE.Value))
            Else
                    strsql = String.Format("update UCAPP_ORG_CE_TYPE_T@NCSTB set CODE='{0}',USER_ID='{1}',COST_CENTER_NAME='{2}' where ORG='{3}' AND COST_CENTER='{4}'", Trim(DD_CODE.SelectedValue), Context.User.Identity.Name, Trim(TXT_CE_NAME.Value), Trim(TXT_ORG_NO.Text), Trim(TXT_CE.Value))
            End If
            '�s�W���A
        Else
            If check_data() = False Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ӽt�P�������ߤw�s�b!');</script>")
                    Exit Sub
                End If
                TXT_USER_ID.Value = context.User.Identity.Name
                If TXT_MO.Text = "P" Then
                    strsql = String.Format("insert into  UCAPP_ORG_CE_TYPE_T@UCST2(ORG,COST_CENTER,CODE,COST_CENTER_NAME,LAST_UPDATE_DATE,USER_ID,COST_TYPE) values('{0}','{1}','{2}','{3}',sysdate,'{4}','Y')", Trim(TXT_ORG_NO.Text), Trim(TXT_CE.Value), Trim(DD_CODE.SelectedValue), Trim(TXT_CE_NAME.Value), Trim(TXT_USER_ID.Value))
                Else
                    strsql = String.Format("insert into  UCAPP_ORG_CE_TYPE_T@NCSTB(ORG,COST_CENTER,CODE,COST_CENTER_NAME,LAST_UPDATE_DATE,USER_ID,COST_TYPE) values('{0}','{1}','{2}','{3}',sysdate,'{4}','Y')", Trim(TXT_ORG_NO.Text), Trim(TXT_CE.Value), Trim(DD_CODE.SelectedValue), Trim(TXT_CE_NAME.Value), Trim(TXT_USER_ID.Value))
                End If
            End If
            db.ExecuteSQL(strsql)
            bindorgce(Trim(TXT_ORG_NO.Text), "", Trim(TXT_MO.Text), Trim(DD_CODE.SelectedValue))

            'viewstate("strquery") = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
            '                        "FROM FWEB_CE_ALL_V WHERE ORG ='" + Trim(TXT_ORG_NO.Text) + "' AND CODE='" + DD_CODE.SelectedValue + "' AND MO='" + TXT_MO.Text + "'  ORDER BY ORG,COST_CENTER"

            'TXT_ORG_NO.Text = ""
            'TXT_ORG_NAME.Text = ""
            'TXT_MO.Text = ""
            'TXT_CE.Value = ""
            'TXT_CE_NAME.Value = ""
            'DD_CODE.SelectedValue = "D"
            label()
            btn_state(0)
            btn1.Disabled = False
            TXT_ORG_NO.Enabled = True
            TXT_ORG_NO.ReadOnly = False
            Datagrid1.Columns(0).Visible = True
            Datagrid1.Columns(1).Visible = True
            'bind_data()
        End Sub

        Private Sub btn1_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.ServerClick, Button5.ServerClick
            bindorgce(Trim(TXT_ORG_NO.Text), Trim(TXT_CE.Value), Trim(TXT_MO.Text), Trim(DD_CODE.SelectedValue))
            'bind_dg(Trim(TXT_ORG_NO.Text), Trim(TXT_CE.Value), Trim(TXT_MO.Text), Trim(DD_CODE.SelectedValue))
        End Sub

        Sub bindorgce(ByVal strorgno As String, ByVal strce As String, ByVal strmo As String, ByVal strcode As String)
            Dim strsql1 As String
            strsql1 = "SELECT * FROM UCCST_ORG_T WHERE ORG = '" + strorgno + "'"
            Dim ds1 As New DataSet
            ds1 = db.FillDataSet(strsql1)
            If ds1.Tables(0).Rows.Count = 0 Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('�L���t�O.')</script>")
            Else
                Dim strsql As String
                strmo = IIf(ds1.Tables(0).Rows(0).Item("MO") = "C", "B", ds1.Tables(0).Rows(0).Item("MO"))
                strsql = "SELECT ORG, ORG_NAME, COST_CENTER, COST_CENTER_NAME, CODE, USER_ID, MO " & _
                         "  FROM FWEB_CE_ALL_V WHERE ORG ='" + strorgno + "' AND COST_CENTER LIKE '%" + strce + "%' AND MO LIKE '" + strmo + "' AND CODE='" + strcode + "' ORDER BY ORG,COST_CENTER"
                viewstate("strquery") = strsql

                TXT_ORG_NO.Text = ds1.Tables(0).Rows(0).Item("ORG")
                TXT_ORG_NAME.Text = ds1.Tables(0).Rows(0).Item("ORG_NAME")
                TXT_MO.Text = ds1.Tables(0).Rows(0).Item("MO")
                TXT_USER_ID.Disabled = True
                TXT_USER_ID.Value = context.User.Identity.Name
                bind_data()
            End If
        End Sub

    Function GetPageInfo(ByRef p As Wuqi.Webdiyer.AspNetPager) As String
        Return String.Format _
        ("��<font color=red><b>{0}</b></font>��&nbsp&nbsp�@<font color=blue><b>{1}</b></font>��<font color=blue><b>{2}</b></font>��", p.CurrentPageIndex.ToString, p.PageCount.ToString, p.RecordCount.ToString)
    End Function

    Private Sub AspNetPager1_PageChanged(ByVal src As System.Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs) Handles AspNetPager1.PageChanged
        Datagrid1.EditItemIndex = -1
        Datagrid1.CurrentPageIndex = 0
        Datagrid1.CurrentPageIndex = e.NewPageIndex - 1
        AspNetPager1.CurrentPageIndex = e.NewPageIndex
        bind_data()
    End Sub
    'DB �P ASPNETPAGER �A�s�@�� DB
    Sub bind_data()
        With db.FillDataSet(viewstate("strquery")).Tables(0)
            Datagrid1.DataSource = .DefaultView
            Datagrid1.DataBind()
            Datagrid1.Height = Unit.Pixel(1)
            AspNetPager1.RecordCount = .Rows.Count
            AspNetPager1.CustomInfoText = GetPageInfo(AspNetPager1)
        End With
    End Sub
    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�D�s�説�A
            BN_QUR.Enabled = True
            BN_ADD.Enabled = True
            BN_SAV.Enabled = False
            BN_CAN.Enabled = False
        Else                                   '�s�説�A
            BN_QUR.Enabled = False
            BN_ADD.Enabled = False
            BN_SAV.Enabled = True
            BN_CAN.Enabled = True

        End If
    End Sub

    Private Sub BN_QUR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_QUR.Click
        Dim strorgno As String, strce As String, strcode As String

        btn_state(0)
        strorgno = Trim(TXT_ORG_NO.Text)
        strce = Trim(TXT_CE.Value)
        strcode = Trim(DD_CODE.SelectedValue)

        bind_dg_query(strorgno, strce, strcode)
    End Sub

    Private Sub BN_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_ADD.Click
        btn_state(1)
        btn1.Disabled = False
        'TXT_ORG_NO.Text = ""
        'TXT_ORG_NAME.Text = ""
        'TXT_MO.Text = ""
        TXT_CE.Value = ""
        TXT_CE_NAME.Value = ""
        DD_CODE.SelectedValue = "D"
        TXT_USER_ID.Value = context.User.Identity.Name
        Datagrid1.Columns(0).Visible = False
        Datagrid1.Columns(1).Visible = False

    End Sub

    Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CAN.Click
        viewstate("strquery") = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
                                "FROM FWEB_CE_ALL_V WHERE CODE ='" + Trim(DD_CODE.SelectedValue) + "' ORDER BY ORG,COST_CENTER"
        cancel()
        bind_data()
    End Sub

    Private Sub DataGrid1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles Datagrid1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��" & e.Item.Cells(3).Text & "��?');")
        End If
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
            'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.TEXT='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_CE.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';DD_CODE.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub DataGrid1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles Datagrid1.ItemCommand
        Dim str As String

        '�R��
        If e.CommandName = "delete" Then
            If TXT_MO.Text = "P" Then
                str = "DELETE UCAPP_ORG_CE_TYPE_T@UCST2 WHERE ORG='" + e.Item.Cells(2).Text + "' AND COST_CENTER='" + e.Item.Cells(6).Text + "'"
            Else
                str = "DELETE UCAPP_ORG_CE_TYPE_T@NCSTB WHERE ORG='" + e.Item.Cells(2).Text + "' AND COST_CENTER='" + e.Item.Cells(6).Text + "'"
            End If

            Try
                db.ExecuteSQL(str)
            Catch ex As Exception
                Throw ex

            Finally
                'viewstate("strquery") = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
                '                        "FROM FWEB_CE_ALL_V WHERE ORG='" + Trim(TXT_ORG_NO.Text) + "' AND CODE='" + Trim(DD_CODE.SelectedValue) + "' ORDER BY ORG,COST_CENTER"
                'cancel()
                'bind_data()
                bindorgce(Trim(TXT_ORG_NO.Text), "", Trim(TXT_MO.Text), Trim(DD_CODE.SelectedValue))

            End Try
        Else  '�s��
            'bindorgce(e.Item.Cells(2).Text, e.Item.Cells(6).Text, e.Item.Cells(4).Text, e.Item.Cells(5).Text)
            TXT_ORG_NO.Enabled = False
            TXT_ORG_NO.ReadOnly = True
            TXT_ORG_NO.Text = e.Item.Cells(2).Text
            TXT_ORG_NAME.Text = e.Item.Cells(3).Text
            TXT_MO.Text = e.Item.Cells(4).Text
            TXT_CE.Disabled = True
            TXT_CE.Value = e.Item.Cells(6).Text
            TXT_CE_NAME.Value = e.Item.Cells(7).Text
            DD_CODE.SelectedValue = e.Item.Cells(5).Text
            btn1.Disabled = True
            btn_state(1)
            Datagrid1.Columns(0).Visible = False
            Datagrid1.Columns(1).Visible = False
            TXT_USER_ID.Value = context.User.Identity.Name
            TXT_USER_ID.Disabled = True
        End If
    End Sub
    ''�NSQL �A�@��DG �P ASPNETPAGER
    'Sub bind_dg(ByVal strorgno As String)
    '    Dim strsql As String
    '    strsql = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
    '             "FROM FWEB_CE_ALL_V WHERE ORG ='" + strorgno + "' ORDER BY ORG,COST_CENTER"
    '    viewstate("strquery") = strsql
    '    bind_data()
    'End Sub

    Sub bind_dg_query(ByVal strorgno As String, ByVal strce As String, ByVal strcode As String)
        Dim strsql As String
        strsql = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
                 "FROM FWEB_CE_ALL_V WHERE ORG LIKE '%" + strorgno + "%' AND COST_CENTER LIKE '%" + strce + "%' AND CODE ='" + strcode + "' ORDER BY ORG,COST_CENTER"
        viewstate("strquery") = strsql
        bind_data()
    End Sub
    Function check_text() As Boolean
        If Trim(TXT_ORG_NO.Text) = "" Then
            Label5.Visible = True
        End If
        If Trim(TXT_ORG_NAME.Text) = "" Then
            Label4.Visible = True
        End If
        If Trim(TXT_CE.Value) = "" Then
            Label3.Visible = True
        End If
        If Trim(TXT_CE_NAME.Value) = "" Then
            Label2.Visible = True
        End If
        If Label5.Visible = True Or Label4.Visible = True Or Label3.Visible = True Or Label2.Visible = True Then
            Return False
        Else
            Return True
        End If
    End Function
    Sub label()
        Label5.Visible = False
        Label4.Visible = False
        Label3.Visible = False
        Label2.Visible = False
    End Sub
    Sub cancel()
        btn_state(0)
        label()
        Datagrid1.Columns(0).Visible = True
        Datagrid1.Columns(1).Visible = True
        TXT_ORG_NO.Enabled = True
        TXT_ORG_NO.ReadOnly = False
        TXT_ORG_NO.Text = ""
        TXT_MO.Text = ""
        TXT_ORG_NAME.Text = ""
        TXT_CE.Value = ""
        TXT_CE_NAME.Value = ""
        DD_CODE.SelectedValue = "D"
        'TXT_USER_ID.Value = context.User.Identity.Name
        btn1.Disabled = False
    End Sub

    '�ˬO�����s�W���,�O�_�s�b��Ʈw��
    Function check_data() As Boolean
        Dim strsql As String
        strsql = "SELECT ORG,ORG_NAME,COST_CENTER,COST_CENTER_NAME,CODE,USER_ID,MO " & _
                 "FROM FWEB_CE_ALL_V WHERE ORG='" + Trim(TXT_ORG_NO.Text) + "' AND COST_CENTER='" + Trim(TXT_CE.Value) + "' AND CODE='" + Trim(DD_CODE.SelectedValue) + "' AND MO='" + Trim(TXT_MO.Text) + "' ORDER BY ORG,COST_CENTER"
        If db.GetExecuteScalar(strsql) > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub TXT_ORG_NO_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TXT_ORG_NO.TextChanged

    End Sub

    Private Sub Button5_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.ServerClick

    End Sub
End Class

End Namespace
