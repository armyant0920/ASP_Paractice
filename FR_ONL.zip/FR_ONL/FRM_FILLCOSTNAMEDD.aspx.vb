Imports System.Data.OleDb
Imports System.Xml
Imports System.Data


Namespace FR

Partial Class FRM_FILLCOSTNAMEDD
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        Dim costid As String = Server.UrlDecode(Request.QueryString("costid"))
        Dim a As Array
        a = Split(costid, ",")
        If a(0) = "" Then
            a(0) = ""
        End If
        If a(1) = "" Then
            a(1) = ""
        End If
        If a(2) = "" Then
            a(3) = ""
        End If
        Dim sqltemp, sqltemp2 As String
        sqltemp = "select *from FWEB_User_orgau_d d where d.user_id='" + a(0) + "' and d.syst_no='FWEB' and d.proj_no='" + a(1) + "'"
        If db.FillDataSet(sqltemp).Tables(0).Rows.Count = 0 Then
            sqltemp2 = "select * from (select 'ALL' cost_center,'ALL' cost_center_name,'1' id from dual union " & _
            " SELECT distinct cost_center,cost_center_name,'2' id FROM fweb_cost_center_v c where c.org='" + a(2) + "' and not " & _
            " exists(select *from FWEB_User_orgau_d d where d.user_id='" + a(0) + "' and d.syst_no='FWEB' and d.proj_no='" + a(1) + "' and d.cost_center=c.cost_center and d.org=c.org) order by cost_center) order by id"
        Else
            sqltemp2 = "SELECT distinct cost_center,cost_center_name FROM fweb_cost_center_v c where c.org='" + a(2) + "' and not " & _
        " exists(select *from FWEB_User_orgau_d d where d.user_id='" + a(0) + "' and d.syst_no='FWEB' and d.proj_no='" + a(1) + "' and d.cost_center=c.cost_center and d.org=c.org) order by cost_center"
        End If
            Dim con As OleDb.OleDbConnection = New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("conn").ToString())
        Dim da As New OleDbDataAdapter(sqltemp2, con)
        Dim ds As New DataSet("address")
        da.Fill(ds, "costname")
        Dim writer As XmlTextWriter = New XmlTextWriter(Response.OutputStream, Response.ContentEncoding)
        writer.Formatting = Formatting.Indented
        writer.Indentation = 4
        writer.IndentChar = " "
        ds.WriteXml(writer)
        writer.Flush()
        Response.End()
        writer.Close()
    End Sub

End Class

End Namespace
