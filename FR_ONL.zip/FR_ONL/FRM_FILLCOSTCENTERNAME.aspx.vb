Imports System.Data.OleDb
Imports System.Xml
Imports System.Data

Namespace FR

Partial Class FRM_FILLCOSTCENTERNAME
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
            Dim sqltemp As String = Server.UrlDecode(Request.QueryString("sqltemp"))
            Dim jq As String = Server.UrlDecode(Request.QueryString("jquery"))



            Dim con As OleDb.OleDbConnection = New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("conn").ToString())
            Dim da As New OleDbDataAdapter(sqltemp, con)
            Dim ds As New DataSet("address")
            da.Fill(ds, "costname")

            If jq = "y" Then

                Response.Write(ds.Tables(0).Rows(0).Item("PERIOD_MOTH"))


            Else


                Dim writer As XmlTextWriter = New XmlTextWriter(Response.OutputStream, Response.ContentEncoding)
                writer.Formatting = Formatting.Indented
                writer.Indentation = 4
                writer.IndentChar = " "
                ds.WriteXml(writer)
                writer.Flush()

                writer.Close()

            End If

            Response.End()

       

    End Sub

End Class

End Namespace
