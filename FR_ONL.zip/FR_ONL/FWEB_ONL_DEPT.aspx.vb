Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math
Imports Excel


Namespace FR

Partial Class FWEB_ONL_DEPT
    Inherits System.Web.UI.Page

    'Public str1 As String
    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            loadorg()
            loadcost()
            btn_state(3)
            'loaddata("")
        End If
    End Sub

    Sub loadorg()
        Dim sqlstr As String
        Dim TempDS As New DataSet
        Try
           sqlstr = "SELECT distinct ORG �s��,ORG_NAME �W�� FROM UCCST_ORG_T ORDER BY ORG"
           TempDS = db.FillDataSet(sqlstr, 2)
           dd_org_name.DataSource = TempDS.Tables(0)
           dd_org_name.DataValueField = "�s��"
           dd_org_name.DataTextField = "�W��"
           dd_org_name.DataBind()
           dd_org_name.Items.Insert(0, "")
        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

    Sub loadcost()
        Dim sqlstr As String
        Dim TempDS As New DataSet
        Try

           sqlstr = "SELECT distinct a.COST_CENTER  �s��, a.COST_CENTER_NAME �W��, a.CODE FROM FWEB_CE_ALL_V a order by A.COST_CENTER "
           TempDS = db.FillDataSet(sqlstr, 2)
           dd_cost_name.DataSource = TempDS.Tables(0)
           dd_cost_name.DataValueField = "�s��"
           dd_cost_name.DataTextField = "�W��"
           dd_cost_name.DataBind()
           dd_cost_name.Items.Insert(0, "")
        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�D�s�説�A
            btnInq.Enabled = True
            BN_ADD.Enabled = True
            BN_SAV.Enabled = False
            BN_CAN.Enabled = False
            Btnexcel.Enabled = True
        Else
            If intnum = 3 Then
                btnInq.Enabled = True
                BN_ADD.Enabled = True
                BN_SAV.Enabled = False
                BN_CAN.Enabled = False
                Btnexcel.Enabled = False
            Else                          '�s�説�A
                btnInq.Enabled = False
                BN_ADD.Enabled = False
                BN_SAV.Enabled = True
                BN_CAN.Enabled = True
                Btnexcel.Enabled = False
            End If
        End If
    End Sub

    Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
        btn_state(0)
        cleartext(1)
        textbox_state(2)
        Dim strsql As String
        strsql = "select  T.ORG,T.COST_CENTER,M.COST_CENTER_NAME,to_char(T.MDATE,'yyyy/mm/dd') as MDATE,T.MUSER,to_char(T.CDATE,'yyyy/mm/dd') as CDATE,T.CUSER" & _
        " from FWEB_ONL_DEPT T, FWEB_CE_ALL_V M where T.ORG like '%" + txt_org_no.Value.Trim + "%' and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'" & _
        " AND T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER  order by t.org "
        Dim strsql4 As String = "select  count(*) from FWEB_ONL_DEPT T, FWEB_CE_ALL_V M where T.ORG like '%" + txt_org_no.Value.Trim + "%' and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'" & _
        " AND T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER "
        viewstate("strsql4") = strsql4
        viewstate("strsql") = strsql
        dg.CurrentPageIndex = 0
        loaddata(viewstate("strsql"))
        Label4.Text = ""
    End Sub

    Sub loaddata(ByVal strsql As String)
        Dim ds As New DataSet
        Dim dv As New DataView
        Try
           If strsql <> "" Then

               ds = db.FillDataSet(strsql, 2)
               'Aspnetpager1.RecordCount = ds.Tables(0).Rows.Count
               dv = ds.Tables(0).DefaultView
               dg.DataSource = dv
               dg.DataBind()
           End If
           'Label9.Text = "�@<font face=verdana >" + dv.Count.ToString() + _
           '              "</font>���O��<font face=verdana >," + (dg.CurrentPageIndex + 1).ToString() + _
           '              "</font> / <font face=verdana >" + dg.PageCount.ToString() + _
           '              "</font>��<font face=verdana>,&nbsp;</font>����<font face=verdana>" + dg.Items.Count.ToString() + "</font>���O��"
           'dg.Height = Unit.Pixel(1)
           'If strsql <> "" Then
           '    If ds.Tables(0).Rows.Count >= 1 Then
           '        btnApprove.Enabled = True
           '    Else
           '        btnApprove.Enabled = False
           '    End If
           'Else
           '    btnApprove.Enabled = False
           'End If
           GetPageInfo()
        Catch ex As Exception
          Alert(ex.ToString, Me)
        Finally
           If Not dv Is Nothing Then
              dv.Dispose()
           End If
           If Not ds Is Nothing Then
              ds.Dispose()
           End If
        End Try
    End Sub

    Private Sub BN_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_ADD.Click
        Label1.Text = 1
        btn_state(1)
        cleartext(0)
        textbox_state(0)
        Label4.Text = ""
    End Sub

    Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
            'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
        If e.CommandName = "delete" Then

            Dim str As String = "delete from FWEB_ONL_DEPT T where T.ORG = '" + e.Item.Cells(2).Text.Trim + "' and T.COST_CENTER = '" + e.Item.Cells(3).Text.Trim + "'"
            Try

                db.ExecuteSQL(str)

            Catch ex As Exception
                Throw ex

            Finally
                If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                    dg.CurrentPageIndex -= 1
                    loaddata(viewstate("strsql"))
                Else
                    loaddata(viewstate("strsql"))
                End If

            End Try
            btn_state(0)
            textbox_state(2)
        End If
        If e.CommandName = "edit" Then
            Label1.Text = 0
            btn_state(1)
            cleartext(0)
            textbox_state(1)
            txt_org_no.Value = e.Item.Cells(2).Text.Trim
            dd_org_name.Value = e.Item.Cells(2).Text.Trim 'e.Item.Cells(3).Text.Trim
            txt_cost_no.Value = e.Item.Cells(3).Text.Trim
            dd_cost_name.Value = e.Item.Cells(3).Text.Trim 'e.Item.Cells(5).Text.Trim
            Label2.Text = e.Item.Cells(3).Text.Trim
            Label3.Text = e.Item.Cells(2).Text.Trim
            Label4.Text = e.Item.Cells(2).Text.Trim
        End If
    End Sub

    Sub textbox_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�s�W���A  
            txt_org_no.Disabled = False
            txt_org_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_org_name.Disabled = False
            dd_org_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
            txt_cost_no.Disabled = False
            txt_cost_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_cost_name.Disabled = False
            dd_cost_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dg.Columns(0).Visible = False
                dg.Columns(1).Visible = False





        ElseIf intnum = 1 Then                 '�s�説�A 
            txt_org_no.Disabled = True
            dd_org_name.Disabled = True
            txt_cost_no.Disabled = False
            txt_cost_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_cost_name.Disabled = False
            dd_cost_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dg.Columns(0).Visible = False
                dg.Columns(1).Visible = False



        Else                                   '��L���A
            txt_org_no.Disabled = False
            txt_org_no.Style.Add("BACKGROUND-COLOR", "beige")
            dd_org_name.Disabled = False
            dd_org_name.Style.Add("BACKGROUND-COLOR", "white")
            txt_cost_no.Disabled = False
            txt_cost_no.Style.Add("BACKGROUND-COLOR", "beige")
            dd_cost_name.Disabled = False
            dd_cost_name.Style.Add("BACKGROUND-COLOR", "white")
                dg.Columns(0).Visible = True

                '�ݬ�s�p��ʺA�[�Jcolumns�ó]�w���e
                'dg.Columns(1).Visible = True
                'Dim tc = New TemplateColumn
                'tc.HeaderText = "TEST"
                'Dim tf = New TemplateField


                'tc.ItemTemplate = New ITem "<asp:LinkButton ID='btnedit' runat='server' Text='����' CommandName='edit' CausesValidation='false'>�s��</asp:LinkButton>"






                'dg.Columns.Add(tc)
                'dg.Columns.AddAt(0, tc)




            End If
        End Sub

    Private Sub BN_SAV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SAV.Click
        Dim strsql As String
        Dim strsql3 As String
        Dim ds As New DataSet
        Try
           If check_data() = False Then
               Exit Sub
           End If

           strsql3 = "SELECT COUNT(*) AS COUNT FROM FWEB_CE_ALL_V WHERE ORG = '" + txt_org_no.Value.Trim + "' AND COST_CENTER = '" + txt_cost_no.Value.Trim + "' AND CODE <> 'D'"
           ds = db.FillDataSet(strsql3, 2)
           If ds.Tables(0).Rows(0).Item("COUNT") <> 0 Then
                   Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�����z�A���������ߤ��O������������!');</script>")
               End If

               Try
                   If Label1.Text = 1 Then                '�s�W
                       strsql = String.Format(" insert into  FWEB_ONL_DEPT(org,cost_center,cdate,cuser) " & _
                      " values('{0}','{1}',sysdate,'{2}')", txt_org_no.Value.Trim, txt_cost_no.Value.Trim, Context.User.Identity.Name)
                   Else                                                 '�s��
                       strsql = String.Format("update FWEB_ONL_DEPT set cost_center='{0}',cdate=sysdate,cuser='{1}' where org = '{2}' and cost_center='{3}'", _
                       txt_cost_no.Value, Context.User.Identity.Name, txt_org_no.Value, Label2.Text)
                   End If
                   db.ExecuteSQL(strsql)
               Catch ex As Exception
                   Throw ex
                   Exit Sub
               End Try
               If Label1.Text = 1 Then
                   btn_state(0)
                   textbox_state(2)
                   cleartext(0)
                   loaddata(ViewState("strsql"))
               ElseIf Label3.Text <> "" Then
                   Dim strsql2 As String = " select *from FWEB_ONL_DEPT T, FWEB_COST_CENTER_V M where T.ORG like '%" + Label3.Text.Trim + "%'  AND T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER  order by t.org "
                   btn_state(0)
                   textbox_state(2)
                   cleartext(0)
                   loaddata(strsql2)
                   Label3.Text = ""
               End If
            Catch ex As Exception
               Alert(ex.ToString, Me)
            Finally
               If Not ds Is Nothing Then
                  ds.Dispose()
               End If
            End Try
        End Sub

        Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CAN.Click
            btn_state(0)
            textbox_state(2)
            cleartext(0)
        End Sub

        Function check_data() As Boolean
            Dim inti As Int16 = 0
            If txt_org_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
                Return False
            End If
            If txt_cost_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������ߤ��i����!');</script>")
                Return False
            End If
            If txt_org_no.Value <> "" Then
                Dim str1 As String = "select count(*) From UCCST_ORG_T where ORG='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(str1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���~�A�Э��s��J!');</script>")
                    Return False
                End If
            End If
            If txt_cost_no.Value <> "" Then
                Dim str2 As String = "select count(*) From FWEB_CE_ALL_V where COST_CENTER='" + txt_cost_no.Value.Trim + "' AND ORG = '" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(str2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������߿��~�A�Э��s��J!');</script>")
                    Return False
                End If
            End If
            If txt_org_no.Value <> "" And txt_cost_no.Value <> "" Then

                Dim strsql As String = " select count(*) from FWEB_ONL_DEPT where ORG='" + txt_org_no.Value.Trim + "' and COST_CENTER='" + txt_cost_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql) > 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��Ƥw�s�b!');</script>")
                    Return False
                End If
            End If

            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function

    Sub cleartext(ByVal intstate As Int16)
        If intstate = 0 Then                     '�D�d�ߪ��A
            txt_org_no.Value = ""
            txt_cost_no.Value = ""
            dd_org_name.Value = ""
            dd_cost_name.Value = ""
        End If
    End Sub

    Sub bind_data()
        Dim TempDS As New DataSet
        Try
           TempDS = db.FillDataSet(ViewState("strsql"), 2)
           With TempDS.Tables(0)
               dg.DataSource = .DefaultView
               dg.DataBind()
               dg.Height = Unit.Pixel(1)
           End With

        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub

    Sub GetPageInfo()
        Dim strsql As String
        strsql = "select count(*) from FWEB_ONL_DEPT T, FWEB_CE_ALL_V M,UCCST_ORG_T N where T.ORG like '%" + txt_org_no.Value.Trim + "%' and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'" & _
        " AND T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER and T.ORG=N.ORG order by t.org"
        Dim strsql1 As String = db.GetExecuteScalar(viewstate("strsql4")).ToString
        Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
    End Sub

    Private Sub Btnexcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnexcel.Click
        Label4.Text = ""
        Response.Write("<script>window.open('ONL/" + EXPORT_EXCEL() + ".xls')</script>")
        'GC.Collect()
    End Sub

    Function EXPORT_EXCEL() As String       '(ByVal source, ByVal e)
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
        Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL1.xls"
        Dim fileNameTmp As String = "temp001"
        Dim savepath As String = Server.MapPath("~") & "\ONL\" + fileNameTmp + ".xls"


        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

            '��R���
            Dim ds As DataSet
            'Dim sqlstr As String
            'sqlstr = "select distinct t.org,t.cost_center, m.cost_center_name,t.mdate,t.muser,t.cdate,t.cuser from FWEB_ONL_DEPT t,UCAPP_CE_TYPE_T m" & _
            '" where t.ORG like '%" + txt_org_no.Value.Trim + "%' and t.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%' AND T.COST_CENTER=M.COST_CENTER "

            ds = db.FillDataSet(ViewState("strsql"), 2)
                Dim y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case (ds.Tables(0).Columns(y).ColumnName).ToLower
                    Case "org"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(i).Item("org").ToString
                            j = j + 1
                        Next
                    Case "cost_center"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 2) = ds.Tables(0).Rows(i).Item("cost_center").ToString
                            j = j + 1
                        Next
                    Case "cost_center_name"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(i).Item("cost_center_name").ToString
                            j = j + 1
                        Next
                    Case "mdate"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 4) = ds.Tables(0).Rows(i).Item("mdate").ToString
                            j = j + 1
                        Next
                    Case "muser"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 5) = ds.Tables(0).Rows(i).Item("muser").ToString
                            j = j + 1
                        Next
                    Case "cdate"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 6) = "'" + ds.Tables(0).Rows(i).Item("cdate").ToString
                            j = j + 1
                        Next
                    Case "cuser"
                        j = 0
                        For i = 0 To i - 1
                            oCells(j + 2, 7) = "'" + ds.Tables(0).Rows(i).Item("cuser").ToString
                            j = j + 1
                        Next
                End Select
            Next
            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            ' oExcel.DisplayAlerts = True

            Return fileNameTmp
        Catch ex As Exception
            Throw ex
        Finally
            ' oExcel.Application.Quit()
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If
            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If

            'GC.Collect()

        End Try
        '  GC.Collect()
    End Function

    Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
        dg.CurrentPageIndex = e.NewPageIndex
        If Label4.Text <> "" Then
            Dim strsql2 As String = "select * from FWEB_ONL_DEPT T, FWEB_CE_ALL_V M where T.ORG like '%" + Label4.Text.Trim + "%' AND T.ORG=M.ORG AND T.COST_CENTER=M.COST_CENTER  order by t.org"
            viewstate("strsql2") = strsql2
            loaddata(viewstate("strsql2"))
        Else
            'dg.CurrentPageIndex = e.NewPageIndex
            'Dim strsql3 As String = "select distinct * from FWEB_ONL_DEPT T, UCAPP_CE_TYPE_T M,UCCST_ORG_T N where T.ORG like '%" + txt_org_no.Value.Trim + "%' and T.COST_CENTER like '%" + txt_cost_no.Value.Trim + "%'" & _
            '" AND T.COST_CENTER=M.COST_CENTER and T.ORG=N.ORG order by t.org"
            'viewstate("strsql3") = strsql3
            loaddata(viewstate("strsql"))
        End If
    End Sub

    'Private Sub Aspnetpager1_PageChanged(ByVal src As System.Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs)
    '    dg.CurrentPageIndex = 0
    '    dg.CurrentPageIndex = e.NewPageIndex - 1
    '    Aspnetpager1.CurrentPageIndex = e.NewPageIndex
    '    loaddata(viewstate("strsql"))
    'End Sub
End Class

End Namespace
