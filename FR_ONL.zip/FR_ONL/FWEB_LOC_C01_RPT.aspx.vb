Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math


Namespace FR

Partial Class FWEB_LOC_C01_RPT
    Inherits System.Web.UI.Page

    Dim oExcel As Excel.Application
    Dim oBooks As Excel.Workbooks
    Dim oBook As Excel.Workbook
    Dim oSheets As Excel.Sheets
    Dim oSheet As Excel.Worksheet
    Dim oCells As Excel.Range
    Dim pReportNo As String
    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Me.txtUserID.Value = context.User.Identity.Name
            LoadOrg()
            LoadCostCenter()
            LoadDate()
            btnExcel.Attributes.Add("onclick", "return loading();")
        End If
    End Sub

#Region "�t�O�B�������ߡB���"

    '�t�O
    Sub LoadOrg()
        Dim ds As New DataSet
        ds = GetOrgDataSet(txt_org_no1.Value)
        dd_org_name1.DataSource = ds.Tables(0)
        dd_org_name1.DataValueField = "ORG"
        dd_org_name1.DataTextField = "ORG_NAME"
        dd_org_name1.DataBind()
        dd_org_name1.Items.Insert(0, "")        
    End Sub

    '��������
    Sub LoadCostCenter()
        Dim sqlstr As String
        Dim ds As New DataSet
        sqlstr = "SELECT DISTINCT CE.COST_CENTER, CE.COST_CENTER_NAME" & _
                 "  FROM FWEB_CE_ALL_V CE," & _
                 "       FWEB_USER_ORGAU_V V " & _
                 " WHERE V.USER_ID = '" + Context.User.Identity.Name + "' " & _
                 "   AND (V.SYST_NO = 'ALL' OR V.SYST_NO = 'FWEB') " & _
                 "   AND (V.PROJ_NO = 'ALL' OR V.PROJ_NO = 'LOC') " & _
                 "   AND CE.ORG = DECODE(V.ORG,'ALL',CE.ORG,V.ORG) " & _
                 "   AND CE.COST_CENTER = DECODE(V.COST_CENTER,'ALL',CE.COST_CENTER,V.COST_CENTER) " & _
                 "   AND CE.ORG LIKE '" + txt_org_no1.Value + "'||'%' " & _
                 "   AND CE.CODE = 'D'" & _
                 "   AND CE.COST_CENTER <> '0000' "
        ds = db.FillDataSet(sqlstr)
        ddCostCenter1.DataSource = ds.Tables(0)
        ddCostCenter1.DataValueField = "COST_CENTER"
        ddCostCenter1.DataTextField = "COST_CENTER_NAME"
        ddCostCenter1.DataBind()
        ddCostCenter1.Items.Insert(0, "")
        ddCostCenter2.DataSource = ds.Tables(0)
        ddCostCenter2.DataValueField = "COST_CENTER"
        ddCostCenter2.DataTextField = "COST_CENTER_NAME"
        ddCostCenter2.DataBind()
        ddCostCenter2.Items.Insert(0, "")
    End Sub

    '���
    Sub LoadDate()
        Dim sqlstr As String
        Dim ds As New DataSet
        sqlstr = " SELECT ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-4) as RMOTH_S, " & _
                 "        LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-1)) as RMOTH_E, " & _
                 "        ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),+0) as FMOTH_S, " & _
                 "        TRUNC(SYSDATE)-1 as FMOTH_E  " & _
                 "   FROM DUAL A"
        ds = db.FillDataSet(sqlstr)
        txtRSdate.Value = ds.Tables(0).Rows(0).Item("RMOTH_S")
        txtREdate.Value = ds.Tables(0).Rows(0).Item("RMOTH_E")
        txtFSdate.Value = ds.Tables(0).Rows(0).Item("FMOTH_S")
        txtFEdate.Value = ds.Tables(0).Rows(0).Item("FMOTH_E")
    End Sub

#End Region

    '��EXCEL
    Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
        Dim filename As String = "LOC_C01_EXCEL" + Now.ToString("yyyyMMddHHmmss") + ".xls"
        Dim savepath As String = PublicM.GetSessionDataRoot(context) + filename 'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(context) + filename 'JavaScript�}��xls���|,�n�Psavepath�P  
            Dim vSheetNo As Integer
        Dim ds As New DataSet
        Dim dt As New DataTable
        Dim row As Integer
        Dim vHeaderArray(0) As String

        If CheckData() = True Then

            '����SP,���XExcel
            If ExecSP() = True Then

                Try

                    CreateExcel(3)

                    '��Ʃ�JDataTable
                    dt = TransferTable()
                    '��Excel
                    row = 1
                    vSheetNo = 1
                    TranToExcel(vSheetNo, dt, row, vHeaderArray, "N")
                    row = row + 1

                    SaveExcel(savepath)
                    Response.Write("<script>window.open(' " + JSsavepath + " ')</script>")

                    ShowErrorReport() '�ˬd�O�_�����`

                Catch ex As Exception
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('���ͳ����o�Ϳ��~! " & PublicM.TrimMessage(ex.Message) & "')</script>")
                    Finally
                        ReleaseExcel()
                    End Try

                Else
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('����SP�o�Ϳ��~!')</script>")
                End If

            End If

        End Sub

        '���`����
        Private Sub btnError_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnError.Click
            Dim csExcel As New CSPrintExcel
            Dim filename As String = "PAL_P01_ERROREXCEL" + Now.ToString("yyyyMMddHHmmss") + ".xls"
            Dim savepath As String = PublicM.GetSessionDataRoot(context) + filename  'xls�s����|,�n�PJSsavepath�P
            Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(context) + filename 'JavaScript�}��xls���|,�n�Psavepath�P        
            Try
                Dim ds As New DataSet
                Dim strsql As String
                strsql = GetErrorReportString()
                ds = db.FillDataSet(strsql)
                csExcel.CreateExcel()
                csExcel.SetDisplayColName("���`��]", "�t�O", "���", "���", "�l��", "�N��", "�N���W��")
                csExcel.SetDisplayCol("REASON", "ORG", "MOTH", "ACCOUNT", "SUB_ACCOUNT", "IS_KIND", "IS_KIND_NAME")
                csExcel.SetDisplayColType(0, 0, 1, 0, 0, 0, 0)
                csExcel.PutExcelData(ds.Tables(0), 1, 1, True, True)
                csExcel.SaveExcel(savepath)
            Catch ex As Exception
                Throw ex
            Finally
                csExcel.ReleaseExcel()
            End Try
            Response.Write("<script>window.open(' " + JSsavepath + " ')</script>")
        End Sub

        '�ˬd���`����
        Sub ShowErrorReport()
            Dim ds As New DataSet
            Dim strsql As String
            strsql = GetErrorReportString()
            ds = db.FillDataSet(strsql)
            If ds.Tables(0).Rows.Count > 0 Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('�����`�A���ˬd���`����!')</script>")
            End If
        End Sub

        '���o���`������QueryString
        Function GetErrorReportString() As String
            Dim sqlstr As String
            sqlstr = "SELECT * FROM FWEB_PAL_P01_CHECKERR_RPT_TMP " & _
                     " WHERE MUSER = '" + Context.User.Identity.Name + "' " & _
                     " ORDER BY ORG, MOTH "
            Return sqlstr
        End Function

        '���o�t�O
        Function GetOrgDataSet(ByVal org1 As String) As DataSet
            Dim sqlstr As String
            Dim ds As DataSet

            sqlstr = "SELECT DISTINCT A.ORG, A.ORG_NAME " & _
                     "  FROM UCCST_ORG_T A, " & _
                     "       FWEB_USER_ORGAU_V V " & _
                     " WHERE V.USER_ID = '" + Context.User.Identity.Name + "' " & _
                     "   AND (V.SYST_NO = 'ALL' OR V.SYST_NO = 'FWEB') " & _
                     "   AND (V.PROJ_NO = 'ALL' OR V.PROJ_NO = 'LOC') " & _
                     "   AND A.ORG = DECODE(V.ORG,'ALL',A.ORG,V.ORG) " & _
                     "   AND A.ORG LIKE '" + txt_org_no1.Value + "'||'%' "

            ds = db.FillDataSet(sqlstr)

            Return ds
        End Function

#Region "CheckData:�ˬd���"
        '�ˬd���
        Function CheckData() As Boolean
            Dim sqlstr As String
            Dim inti As Int16 = 0

            '����p�A�j �X�{
            Dim Sdate As DateTime = Me.txtRSdate.Value
            Dim Edate As DateTime = Me.txtREdate.Value
            If Edate < Sdate Then
                Me.txtREdate.Value = Sdate.ToString("yyyy/MM") + "/01"
                Me.txtRSdate.Value = Edate.ToString("yyyy/MM") + "/01"
            End If
            Sdate = Me.txtFSdate.Value
            Edate = Me.txtFEdate.Value
            If Edate < Sdate Then
                Me.txtFEdate.Value = Sdate.ToString("yyyy/MM") + "/01"
                Me.txtFSdate.Value = Edate.ToString("yyyy/MM") + "/01"
            End If

            '�������ߤp�A�j �X�{
            Dim SCostCenter As String = Me.txtCostCenter1.Value
            Dim ECostCenter As String = Me.txtCostCenter2.Value
            If ECostCenter < SCostCenter Then
                Me.txtCostCenter2.Value = SCostCenter
                Me.txtCostCenter1.Value = ECostCenter
            End If

            If (Me.txtRSdate.Value = "" Or Me.txtREdate.Value = "") And inti = 0 Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�п�J��ڤ���_��!');</script>")
            End If

            If (Me.txtFSdate.Value = "" Or Me.txtFEdate.Value = "") And inti = 0 Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�п�J�w������_��!');</script>")
            End If

            If txt_org_no1.Value <> "" And inti = 0 Then
                sqlstr = "SELECT COUNT(*) FROM UCCST_ORG_T WHERE ORG = '" + txt_org_no1.Value.Trim + "' "
                If db.GetExecuteScalar(sqlstr) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�L���t�O���!');</script>")
                End If
            End If

            If txtCostCenter1.Value <> "" And inti = 0 Then
                sqlstr = "SELECT COUNT(*) FROM FWEB_CE_ALL_V WHERE ORG LIKE '" + txt_org_no1.Value.Trim + "'||'%'  "
                If db.GetExecuteScalar(sqlstr) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�L���������߸��!');</script>")
                End If
            End If

            If txtCostCenter2.Value <> "" And inti = 0 Then
                sqlstr = "SELECT COUNT(*) FROM FWEB_CE_ALL_V WHERE ORG LIKE '" + txt_org_no1.Value.Trim + "'||'%' "
                If db.GetExecuteScalar(sqlstr) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�L���������߸��!');</script>")
                End If
            End If

            If Me.txt_org_no1.Value <> "" And inti = 0 Then
                'CHECK�O�_���t�O�v��
                sqlstr = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_V " & _
                         " WHERE USER_ID='" + Context.User.Identity.Name + "' " & _
                         "   AND DECODE(SYST_NO,'ALL','FWEB',SYST_NO) = 'FWEB' " & _
                         "   AND DECODE(PROJ_NO,'ALL','LOC',PROJ_NO) = 'LOC' " & _
                         "   AND DECODE(ORG,'ALL','" + txt_org_no1.Value.Trim + "',ORG)='" + txt_org_no1.Value.Trim + "'"
                If db.GetExecuteScalar(sqlstr) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���]�ȼW�[!');</script>")
                End If
            End If

            If Me.txtCostCenter1.Value <> "" And inti = 0 Then
                'CHECK�O�_�����������v��
                sqlstr = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_V " & _
                         " WHERE USER_ID='" + Context.User.Identity.Name + "' " & _
                         "   AND DECODE(SYST_NO,'ALL','FWEB',SYST_NO) = 'FWEB' " & _
                         "   AND DECODE(PROJ_NO,'ALL','LOC',PROJ_NO) = 'LOC' " & _
                         "   AND DECODE(ORG,'ALL','" + txt_org_no1.Value.Trim + "',ORG) LIKE '" + txt_org_no1.Value.Trim + "'||'%' " & _
                         "   AND DECODE(COST_CENTER,'ALL','" + txtCostCenter1.Value.Trim + "',COST_CENTER) = '" + txtCostCenter1.Value.Trim + "'"
                If db.GetExecuteScalar(sqlstr) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                End If
            End If

            If Me.txtCostCenter2.Value <> "" And inti = 0 Then
                'CHECK�O�_�����������v��
                sqlstr = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_V " & _
                         " WHERE USER_ID='" + Context.User.Identity.Name + "' " & _
                         "   AND DECODE(SYST_NO,'ALL','FWEB',SYST_NO) = 'FWEB' " & _
                         "   AND DECODE(PROJ_NO,'ALL','LOC',PROJ_NO) = 'LOC' " & _
                         "   AND DECODE(ORG,'ALL','" + txt_org_no1.Value.Trim + "',ORG) LIKE '" + txt_org_no1.Value.Trim + "'||'%' " & _
                         "   AND DECODE(COST_CENTER,'ALL','" + txtCostCenter2.Value.Trim + "',COST_CENTER) = '" + txtCostCenter2.Value.Trim + "'"
                If db.GetExecuteScalar(sqlstr) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                End If
            End If

            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function
#End Region

#Region "ExecSP:����StoreProcedure"
        Function ExecSP() As Boolean
            Dim cmd As New OleDbCommand
            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_LOC_C01_RPT_SP"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn
                    cmd.Parameters.Add(New OleDbParameter("P_ORG", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_COST_CENTER_S", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_COST_CENTER_E", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_RSDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_REDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_FSDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_FEDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_HASE_OUT", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_HASE_OAY", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_HASE_EXPENSE", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_USER_ID", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_MESSAGE", OleDbType.VarChar, 100)).Direction = ParameterDirection.Output

                    cmd.Parameters("P_ORG").Value = txt_org_no1.Value
                    cmd.Parameters("P_COST_CENTER_S").Value = txtCostCenter1.Value
                    cmd.Parameters("P_COST_CENTER_E").Value = txtCostCenter2.Value
                    cmd.Parameters("P_RSDATE").Value = txtRSdate.Value
                    cmd.Parameters("P_REDATE").Value = txtREdate.Value
                    cmd.Parameters("P_FSDATE").Value = txtFSdate.Value
                    cmd.Parameters("P_FEDATE").Value = txtFEdate.Value
                    cmd.Parameters("P_HASE_OUT").Value = rblHase_Out.SelectedValue
                    cmd.Parameters("P_HASE_OAY").Value = rblHase_Oay.SelectedValue
                    cmd.Parameters("P_HASE_EXPENSE").Value = rblHase_Expense.SelectedValue
                    cmd.Parameters("P_USER_ID").Value = Context.User.Identity.Name
                    cmd.Parameters("P_MESSAGE").Value = ""

                    cmd.ExecuteNonQuery()

                    Dim V_Message As String = cmd.Parameters("P_MESSAGE").Value.ToString
                    If V_Message <> "" Then
                        Response.Write("<script>alert('" & V_Message.Replace("'", "-").Replace("\n", "").Replace("\r", "") & "')</script>")
                        Return False
                    Else
                        Return True
                    End If

                Catch ex As Exception
                    Response.Write("<script>alert('" & ex.Message.Replace("'", "-").Replace("\n", "").Replace("\r", "") & "')</script>")
                    Return False
                Finally
                    cn.Close()
                End Try
            End If
            Return True
        End Function
#End Region

#Region "TransferTable:�����c�ഫ(�d�ߵ��G�����ഫ�)"

    '�����c�ഫ(�d�ߵ��G�����ഫ�)"
    Function TransferTable() As DataTable
        Dim crtTable As New CSCreatTable
        Dim dtTemp As New DataTable

        '�T�w���Y
        crtTable.AddFixColumn("ORG", "ORG_NAME", "COST_CENTER", "COST_CENTER_NAME", "ORI_ORG", "ORI_COST_CENTER", "ITEM_ID", "ITEM_NAME", "ITEM_FORMAT")

        '���ʪ��Y-���
        crtTable.AddVarColumn(txtRSdate.Value, txtREdate.Value, "R@AMOUNT@", "R@PERC@")

        '���ʪ��Y-�w��
        crtTable.AddVarColumn(txtFSdate.Value, txtFEdate.Value, "F@AMOUNT@", "F@PERC@")

        '�]�w-���ʪ��Y�n��������, (PS.���ʪ��Y�P���ʪ����n��������W�٨�Ӽƶ��۹���)
        crtTable.SetVarGetColName("HEAD_AMOUNT", "HEAD_PERC")

        '�]�w-���ʪ����n��������,(PS.���ʪ��Y�P���ʪ����n��������W�٨�Ӽƶ��۹���)
        crtTable.SetVarGetCol("BODY_AMOUNT", "BODY_PERC")

        '��J���
        Dim sqlstr As String
        sqlstr = "SELECT A.SEQ, A.ORG, A.ORG_NAME, A.COST_CENTER, A.COST_CENTER_NAME, A.ORI_ORG, A.ORI_COST_CENTER, " & _
                 "       A.ITEM_ID, A.ITEM_NAME, A.ITEM_FORMAT, " & _
                 "       A.COST_TYPE||'@AMOUNT@'||TO_CHAR(A.MOTH,'YYYY/MM') AS HEAD_AMOUNT, " & _
                 "       A.AMOUNT                                           AS BODY_AMOUNT, " & _
                 "       A.COST_TYPE||'@PERC@'||TO_CHAR(A.MOTH,'YYYY/MM') AS HEAD_PERC, " & _
                 "       A.PERC                                           AS BODY_PERC  " & _
                 "  FROM FWEB_LOC_C01_RPT_TMP A " & _
                 " WHERE A.MUSER = '" + Context.User.Identity.Name + "'"
        crtTable.FillTable(sqlstr, "ORG, COST_CENTER, ORI_ORG, ORI_COST_CENTER, SEQ, ITEM_ID ASC")

        dtTemp = crtTable.GetTable

        Return dtTemp
    End Function

#End Region

#Region "��X��EXCEL"

    '��X��Excel
    Sub TranToExcel(ByVal Sheetno As Integer, ByVal P_dt As DataTable, ByRef P_row As Integer, ByVal HeaderArray() As String, ByVal PrintHeaderFlag As String)
        Try
                Dim i, Headrow As Integer

            '�]�w�ثe�u�@��
            oSheet = oSheets.Item(Sheetno)
            oSheet.Activate()
            oCells = oSheet.Cells

            '�]�w�㭶�C��
            If P_row = 1 Then
                ExcelColor("PAGE")
            End If

            '��J���D
            Headrow = P_row
            If PrintHeaderFlag = "Y" Then
                For i = 0 To HeaderArray.Length - 1
                    oCells(Headrow, 1) = HeaderArray(i)
                    ExcelColor(vType:="USER", sRow:=Headrow, sCol:=1, eRow:=Headrow, eCol:=1, vFontBold:=True)
                    Headrow = Headrow + 1
                Next
            End If
            P_row = Headrow

            '��JEXCEL���
            PutExcelData(P_dt, P_row)

            '��e�۰ʽվ�
            Dim oColumns As Excel.Range
            oColumns = oSheet.Columns
            oColumns.AutoFit()
            ReleaseExcelObject(oColumns)

            '�]�w��ܤ��
            Dim oWindow As Excel.Window
            oWindow = oExcel.ActiveWindow
            oWindow.Zoom = 75
            ReleaseExcelObject(oWindow)

        Catch ex As Exception
            Throw ex
        Finally
            ReleaseExcelObject(oCells)
            ReleaseExcelObject(oSheet)
        End Try
    End Sub

#Region "  PutexcelData:��JEXCEL���"
    '��JEXCEL���
    Sub PutExcelData(ByVal P_dt As DataTable, ByRef P_row As Integer)
        Dim i, j As Integer
            Dim row, col, sMergeCol As Integer
        Dim arrayColName() As String
        Dim vCompareCostType, vCompareMoth, vCompareOrg, vCompareCostCenter, vCompareOriOrg, vCompareOriCostCenter As String

        '��J���        
        col = 1
        vCompareCostType = ""
        vCompareMoth = ""

        '�]�w�榡
        ExcelDrawLine(sRow:=P_row, sCol:=1, eRow:=P_row + 1 + P_dt.Rows.Count, eCol:=P_dt.Columns.Count - 2, vVerticalBorder:=True, vHorizontalBorder:=True)  'ITEM_FORMAT,ITEM_ID�����,�ҥHColumns.Count-2
        ExcelColor(vType:="HEAD", sRow:=P_row, sCol:=col, eRow:=P_row + 1, eCol:=P_dt.Columns.Count - 2)

        For i = 0 To P_dt.Columns.Count - 1

            If P_dt.Columns(i).ColumnName <> "ITEM_FORMAT" And P_dt.Columns(i).ColumnName <> "ITEM_ID" Then  'ITEM����ܮ榡�]�w�ΥN��,����ܦbEXCEL�W 

                row = P_row
                arrayColName = P_dt.Columns(i).ColumnName.Split("@")

                '����Y -----------------------------------------------------------
                If arrayColName(0) = "R" Or arrayColName(0) = "F" Then '���ʪ��Y
                    If vCompareCostType <> arrayColName(0) Or vCompareMoth <> arrayColName(2) Then
                        sMergeCol = col
                        oCells(row, col) = "'" + arrayColName(2)
                        vCompareCostType = arrayColName(0)
                        vCompareMoth = arrayColName(2)
                    End If
                    If arrayColName(1) = "AMOUNT" Then
                        oCells(row + 1, col) = IIf(arrayColName(0) = "R", "Actual", "�w��")                        
                    Else
                        oCells(row + 1, col) = "%"
                    End If
                    ExcelMergeCell(row, sMergeCol, row, col)
                    ExcelMergeCell(row + 1, col, row + 1, col)
                Else        '�T�w���Y
                    Select Case P_dt.Columns(i).ColumnName
                        Case "ORG"
                            oCells(row, col) = "�t�O"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                        Case "ORG_NAME"
                            oCells(row, col) = "�t�O�W��"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                        Case "COST_CENTER"
                            oCells(row, col) = "��������"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                        Case "COST_CENTER_NAME"
                            oCells(row, col) = "�������ߦW��"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                        Case "ORI_ORG"
                            oCells(row, col) = "�֯��e�t�O"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                        Case "ORI_COST_CENTER"
                            oCells(row, col) = "�֯��e��������"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                        Case "ITEM_NAME"
                            oCells(row, col) = "����"
                            ExcelFormat(P_row, col, P_row + 1 + P_dt.Rows.Count, col, "S")
                    End Select                    
                    ExcelMergeCell(row, col, row + 1, col)
                End If

                ExcelWrapText(row, col, row, P_dt.Columns.Count - 2) '���Y����r�]�w�i�۰ʴ���
                ExcelWrapText(row + 1, col, row + 1, P_dt.Columns.Count - 2) '���Y����r�]�w�i�۰ʴ���

                row = row + 2
                '����� -----------------------------------------------------------
                For j = 0 To P_dt.Rows.Count - 1

                    '�]�w�w���ι�ڤ�����A�̶��ؤ��P���C�C�榡
                    If arrayColName(0) = "R" Or arrayColName(0) = "F" Then '���ʪ��Y
                        If col = 8 Then
                            ExcelFormat(row, col, row, P_dt.Columns.Count - 2, P_dt.Rows(j).Item("ITEM_FORMAT"))
                        End If
                        If arrayColName(1) = "PERC" Then
                            ExcelFormat(row, col, row, col, "P")
                        End If
                    End If

                    '����
                    oCells(row, col) = P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName)


                    '���P�������߮�,�e���u;���P�֯��e�������߮�,�e�Žu
                    Select Case P_dt.Columns(i).ColumnName

                        Case "ORG"

                            If vCompareOrg <> P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName) Then
                                If vCompareOrg <> "" Then
                                    ExcelDrawLine(sRow:=row, sCol:=1, eRow:=row, eCol:=P_dt.Columns.Count - 2, vTopBorder:=True, vTopLineStyle:=1, vTopWeight:=3, vTopColorIndex:=3, vVerticalBorder:=True)
                                End If
                                vCompareOrg = P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName)
                            End If

                        Case "COST_CENTER"

                            If vCompareCostCenter <> P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName) Then
                                If vCompareCostCenter <> "" Then
                                    ExcelDrawLine(sRow:=row, sCol:=1, eRow:=row, eCol:=P_dt.Columns.Count - 2, vTopBorder:=True, vTopLineStyle:=1, vTopWeight:=3, vTopColorIndex:=3, vVerticalBorder:=True)
                                End If
                                vCompareCostCenter = P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName)
                            End If

                        Case "ORI_ORG"

                            If vCompareOriOrg <> P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName) Then
                                If vCompareOriOrg <> "" And vCompareOriOrg <> "�X�p" Then
                                    ExcelDrawLine(sRow:=row, sCol:=5, eRow:=row, eCol:=P_dt.Columns.Count - 2, vTopBorder:=True, vTopLineStyle:=1, vTopWeight:=3, vTopColorIndex:=5, vVerticalBorder:=True)
                                End If
                                vCompareOriOrg = P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName)
                            End If

                        Case "ORI_COST_CENTER"

                            If vCompareOriCostCenter <> P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName) Then
                                If vCompareOriCostCenter <> "" And vCompareOriCostCenter <> "�X�p" Then
                                    ExcelDrawLine(sRow:=row, sCol:=5, eRow:=row, eCol:=P_dt.Columns.Count - 2, vTopBorder:=True, vTopLineStyle:=1, vTopWeight:=3, vTopColorIndex:=5, vVerticalBorder:=True)
                                End If
                                vCompareOriCostCenter = P_dt.Rows(j).Item(P_dt.Columns(i).ColumnName)
                            End If

                    End Select

                    row = row + 1
                Next

                col = col + 1

            End If
        Next

        '��Ƶ� 
        row = row + 1
        oCells(row, 1) = "��:1.��-�w��:�����ERP�������,�L����h��PO���"
        oCells(row + 1, 1) = "     2.��-���:�]�t�u�W���s�F��-�w��:�]�t����u�W���s"
        oCells(row + 2, 1) = "     3.�u�O-�w��:�ΤW����ڤu�O�a�J"
        oCells(row + 3, 1) = "     4.�u�O-���:���t�t�����J"
        ExcelMergeCell(row, 1, row, P_dt.Columns.Count, "LEFT", "CENTER")
        ExcelMergeCell(row + 1, 1, row + 1, P_dt.Columns.Count, "LEFT", "CENTER")
        ExcelMergeCell(row + 2, 1, row + 2, P_dt.Columns.Count, "LEFT", "CENTER")
        ExcelMergeCell(row + 3, 1, row + 3, P_dt.Columns.Count, "LEFT", "CENTER")

        row = row + 4

        P_row = row
    End Sub
#End Region

#Region "  ExcelGetCellAddress:���X�x�s�檺Address"
    Function ExcelGetcelladdress(ByVal row As Integer, ByVal col As Integer) As String
        Dim oRange As Excel.Range
        Dim oCellx As Excel.Range
        Dim celladdr As String

        oRange = oSheet.Cells
        oCellx = oRange.Item(row, col)
        celladdr = oCellx.Address

        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oRange)

        Return celladdr
    End Function
#End Region

#Region "  ExcelFormula:�x�s�檺����"
    '�]�w�x�s�檺����
    Sub ExcelFormula(ByVal row As Integer, ByVal col As Integer, ByVal formulaString As String)
        Dim oRange As Excel.Range
        Dim oCellx As Excel.Range

        oRange = oSheet.Cells
        oCellx = oRange.Item(row, col)

        oCellx.Formula = formulaString

        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oRange)
    End Sub
#End Region

#Region "  ExcelColor:�x�s�歶���r��έ����C��"
    '�x�s��Φr���C��,����
    Sub ExcelColor(ByVal vType As String, _
                   Optional ByVal sRow As Integer = 1, Optional ByVal sCol As Integer = 1, _
                   Optional ByVal eRow As Integer = 1, Optional ByVal eCol As Integer = 1, _
                   Optional ByVal vInteriorColorIndex As Integer = 2, Optional ByVal vFontColorIndex As Integer = 0, _
                   Optional ByVal vFontBold As Boolean = False)
        Dim oRange As Excel.Range
        Dim oRangePage As Excel.Range
        Dim oCellx As Excel.Range
        Dim oCelly As Excel.Range
        Dim oInterior As Excel.Interior
        Dim oFont As Excel.Font

        oRange = oSheet.Cells
        oCellx = oRange.Item(sRow, sCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Cells
        oCelly = oRange.Item(eRow, eCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Range(oCellx, oCelly)
        oRangePage = oSheet.Cells  '�㶵�]�w��

        Select Case vType.ToUpper
            Case "PAGE"  '�㭶                
                oInterior = oRangePage.Interior
                oInterior.ColorIndex = 2
            Case "HEAD"  '���Y
                oInterior = oRange.Interior
                oFont = oRange.Font
                oInterior.ColorIndex = 36
                oFont.ColorIndex = vFontColorIndex
                oFont.Bold = True
            Case "USER"  '��L,��USER���w�榡
                oInterior = oRange.Interior
                oFont = oRange.Font
                oInterior.ColorIndex = vInteriorColorIndex
                oFont.ColorIndex = vFontColorIndex
                oFont.Bold = vFontBold
        End Select


        ReleaseExcelObject(oFont)
        ReleaseExcelObject(oInterior)
        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oCelly)
        ReleaseExcelObject(oRangePage)
        ReleaseExcelObject(oRange)
    End Sub
#End Region

#Region "  ExcelDrawLine:�e��u"
    '�e��u
    Sub ExcelDrawLine(ByVal sRow As Integer, ByVal sCol As Integer, ByVal eRow As Integer, ByVal eCol As Integer, _
                      Optional ByVal vTopBorder As Boolean = True, Optional ByVal vTopLineStyle As Integer = 1, Optional ByVal vTopWeight As Integer = 2, Optional ByVal vTopColorIndex As Integer = 1, _
                      Optional ByVal vButtomBorder As Boolean = True, Optional ByVal vButtomLineStyle As Integer = 1, Optional ByVal vButtomWeight As Integer = 2, Optional ByVal vButtomColorIndex As Integer = 1, _
                      Optional ByVal vLeftBorder As Boolean = True, Optional ByVal vLeftLineStyle As Integer = 1, Optional ByVal vLeftWeight As Integer = 2, Optional ByVal vLeftColorIndex As Integer = 1, _
                      Optional ByVal vRightBorder As Boolean = True, Optional ByVal vRightLineStyle As Integer = 1, Optional ByVal vRightWeight As Integer = 2, Optional ByVal vRightColorIndex As Integer = 1, _
                      Optional ByVal vVerticalBorder As Boolean = False, Optional ByVal vVerticalLineStyle As Integer = 1, Optional ByVal vVerticalWeight As Integer = 2, Optional ByVal vVerticalColorIndex As Integer = 1, _
                      Optional ByVal vHorizontalBorder As Boolean = False, Optional ByVal vHorizontalLineStyle As Integer = 1, Optional ByVal vHorizontalWeight As Integer = 2, Optional ByVal vHorizontalColorIndex As Integer = 1)
        Dim oRange As Excel.Range
        Dim oCellx As Excel.Range
        Dim oCelly As Excel.Range
        Dim oBorders As Excel.Borders
        Dim oBorder As Excel.Border

        oRange = oSheet.Cells
        oCellx = oRange.Item(sRow, sCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Cells
        oCelly = oRange.Item(eRow, eCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Range(oCellx, oCelly)
        oBorders = oRange.Borders

        With oBorders
            '�W��u
            If vTopBorder = True Then
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeTop)
                With oBorder
                    .LineStyle = vTopLineStyle
                    .Weight = vTopWeight
                    .ColorIndex = vTopColorIndex
                End With
                ReleaseExcelObject(oBorder)
            Else
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeTop)
                oBorder.LineStyle = Excel.XlLineStyle.xlLineStyleNone
                ReleaseExcelObject(oBorder)
            End If
            '�U��u
            If vButtomBorder = True Then
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeBottom)
                With oBorder
                    .LineStyle = vButtomLineStyle
                    .Weight = vButtomWeight
                    .ColorIndex = vButtomColorIndex
                End With
                ReleaseExcelObject(oBorder)
            Else
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeBottom)
                oBorder.LineStyle = Excel.XlLineStyle.xlLineStyleNone
                ReleaseExcelObject(oBorder)
            End If
            '����u
            If vLeftBorder = True Then
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeLeft)
                With oBorder
                    .LineStyle = vLeftLineStyle
                    .Weight = vLeftWeight
                    .ColorIndex = vLeftColorIndex
                End With
                ReleaseExcelObject(oBorder)
            Else
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeLeft)
                oBorder.LineStyle = Excel.XlLineStyle.xlLineStyleNone
                ReleaseExcelObject(oBorder)
            End If
            '�k��u
            If vRightBorder = True Then
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeRight)
                With oBorder
                    .LineStyle = vRightLineStyle
                    .Weight = vRightWeight
                    .ColorIndex = vRightColorIndex
                End With
                ReleaseExcelObject(oBorder)
            Else
                oBorder = .Item(Excel.XlBordersIndex.xlEdgeRight)
                oBorder.LineStyle = Excel.XlLineStyle.xlLineStyleNone
                ReleaseExcelObject(oBorder)
            End If
            '������u
            If vVerticalBorder = True Then
                oBorder = .Item(Excel.XlBordersIndex.xlInsideVertical)
                With oBorder
                    .LineStyle = vVerticalLineStyle
                    .Weight = vVerticalWeight
                    .ColorIndex = vVerticalColorIndex
                End With
                ReleaseExcelObject(oBorder)
            Else
                oBorder = .Item(Excel.XlBordersIndex.xlInsideVertical)
                oBorder.LineStyle = Excel.XlLineStyle.xlLineStyleNone
                ReleaseExcelObject(oBorder)
            End If
            '������u
            If vHorizontalBorder = True Then
                oBorder = .Item(Excel.XlBordersIndex.xlInsideHorizontal)
                With oBorder
                    .LineStyle = vHorizontalLineStyle
                    .Weight = vHorizontalWeight
                    .ColorIndex = vHorizontalColorIndex
                End With
                ReleaseExcelObject(oBorder)
            Else
                oBorder = .Item(Excel.XlBordersIndex.xlInsideHorizontal)
                oBorder.LineStyle = Excel.XlLineStyle.xlLineStyleNone
                ReleaseExcelObject(oBorder)
            End If
        End With

        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oCelly)
        ReleaseExcelObject(oBorders)
        ReleaseExcelObject(oRange)
    End Sub

#End Region

#Region "  ExcelFormat:�x�s���Ʈ榡"
    '�x�s���Ʈ榡,���x�s��]�w
    Sub ExcelFormat(ByVal sRow As Integer, ByVal sCol As Integer, ByVal eRow As Integer, ByVal eCol As Integer, _
                    ByVal vFormatType As String, Optional ByVal vFormatString As String = "")
        Dim oRange As Excel.Range
        Dim oCellx As Excel.Range
        Dim oCelly As Excel.Range

        oRange = oSheet.Cells
        oCellx = oRange.Item(sRow, sCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Cells
        oCelly = oRange.Item(eRow, eCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Range(oCellx, oCelly)
        With oRange
            Select Case vFormatType.ToUpper
                Case "A" '�|�p�M�ή榡,�p���I2��,�Ÿ��L
                    .NumberFormatLocal = "_-* #,##0.00_-;-* #,##0.00_-;_-* ""-""??_-;_-@_-"
                Case "C" '�Ӧ��,��ܨ�p���I2��
                    .NumberFormatLocal = "0.00_);[����](0.00)"
                Case "D" '�Ӧ��,�d��@�J�����
                    .NumberFormatLocal = "#,##0_);[����](#,##0)"
                Case "E" '����d��,�d��@�J�����
                    .NumberFormatLocal = "#,###,;[����](#,###,)"
                Case "P" '�ʤ������
                    .NumberFormatLocal = "0.0%"
                Case "S" '��r���
                    .NumberFormatLocal = "@"
                Case "U" '��L,��USER���w�榡
                    If vFormatString <> "" Then
                        .NumberFormatLocal = vFormatString
                    End If
            End Select
        End With
        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oCelly)
        ReleaseExcelObject(oRange)
    End Sub
#End Region

#Region "  ExcelMergeCell:�X���x�s��"
    '�X���x�s��
    Sub ExcelMergeCell(ByVal sRow As Integer, ByVal sCol As Integer, ByVal eRow As Integer, ByVal eCol As Integer, _
                       Optional ByVal horAlignment As String = "CENTER", Optional ByVal VerticalAlignment As String = "CENTER")
        Dim oRange As Excel.Range
        Dim oCellx As Excel.Range
        Dim oCelly As Excel.Range

        oRange = oSheet.Cells
        oCellx = oRange.Item(sRow, sCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Cells
        oCelly = oRange.Item(eRow, eCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Range(oCellx, oCelly)
        With oRange
            .MergeCells = True
            If horAlignment.ToUpper = "LEFT" Then
                .HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft
            ElseIf horAlignment.ToUpper = "RIGHT" Then
                .HorizontalAlignment = Excel.XlHAlign.xlHAlignRight
            ElseIf horAlignment.ToUpper = "CENTER" Then
                .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            End If
            If VerticalAlignment.ToUpper = "TOP" Then
                .VerticalAlignment = Excel.XlVAlign.xlVAlignTop
            ElseIf VerticalAlignment.ToUpper = "BOTTOM" Then
                .VerticalAlignment = Excel.XlVAlign.xlVAlignBottom
            ElseIf VerticalAlignment.ToUpper = "CENTER" Then
                .VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
            End If
        End With

        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oCelly)
        ReleaseExcelObject(oRange)
    End Sub
#End Region

#Region "  ExcelWrapText:�x�s���r�۰ʴ��C"
    '�x�s���Ʈ榡,���x�s��]�w
    Sub ExcelWrapText(ByVal sRow As Integer, ByVal sCol As Integer, ByVal eRow As Integer, ByVal eCol As Integer)
        Dim oRange As Excel.Range
        Dim oCellx As Excel.Range
        Dim oCelly As Excel.Range

        oRange = oSheet.Cells
        oCellx = oRange.Item(sRow, sCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Cells
        oCelly = oRange.Item(eRow, eCol)
        ReleaseExcelObject(oRange)

        oRange = oSheet.Range(oCellx, oCelly)
        With oRange
            .WrapText = True
        End With
        ReleaseExcelObject(oCellx)
        ReleaseExcelObject(oCelly)
        ReleaseExcelObject(oRange)
    End Sub
#End Region

#End Region

#Region "CreateExcel:�w�q�@�ӷs���u�@ï"
    Sub CreateExcel(Optional ByVal TotalSheet As Int16 = 1)
        oExcel = New Excel.Application
        oBooks = oExcel.Workbooks
        oBook = oBooks.Add
        oSheets = oBook.Worksheets

        Dim oSheetx As Excel.Worksheet

        '�s�W�u�@��
        Dim i As Int16
        If TotalSheet > 3 Then
            For i = 1 To TotalSheet - 3
                oSheetx = CType(oSheets.Add(), Excel.Worksheet)
                ReleaseExcelObject(oSheetx)
            Next
        End If

    End Sub
#End Region

#Region "SaveExcel:�x�sExcel"
    Sub SaveExcel(ByVal savepath As String)
        '�s��
        If File.Exists(savepath) Then
            File.Delete(savepath)
        End If

        oBook.SaveAs(savepath)
        oBook.Close()
    End Sub
#End Region

#Region "ReleaseExcel:����Excel�귽"
    Sub ReleaseExcel()
        Try
            oExcel.Quit()
            ReleaseExcelObject(oCells)
            ReleaseExcelObject(oSheet)
            ReleaseExcelObject(oSheets)
            ReleaseExcelObject(oBook)
            ReleaseExcelObject(oBooks)
            ReleaseExcelObject(oExcel)
        Catch ex As Exception
            Throw ex
        Finally
            GC.Collect()
        End Try
    End Sub
#End Region

#Region "ReleaseExcelObject:������XExcel�Ψ쪺����"
    Sub ReleaseExcelObject(ByVal o As Object)
        Try
            If Not o Is Nothing Then
                Marshal.ReleaseComObject(o)
            End If
        Finally
            o = Nothing
        End Try
    End Sub
#End Region

End Class

End Namespace
