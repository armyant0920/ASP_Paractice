Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math


Namespace FR


Partial Class FWEB_ONLB_TRANSFER
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If txt_org_no.Value <> "" Then
            LoadCost()
            Me.dd_cost_name.Value = Me.txt_cost_no.Value
        End If
        If Not Page.IsPostBack Then
            btn_state(0)
            txt_state()
            sysdate()
            LoadOrg()
            Me.dd_org_name.Value = Me.txt_org_no.Value
            LoadCost()
            btn1_find.Attributes.Add("onclick", "return loading();")
        End If
    End Sub
    Sub LoadOrg()
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONLB_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = B.ORG AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                 " AND C.PROJ_NO = 'ONLB' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
        dd_org_name.DataSource = db.FillDataSet(sqlstr).Tables(0)
        dd_org_name.DataValueField = "�s�X"
        dd_org_name.DataTextField = "�W��"
        dd_org_name.DataBind()
        dd_org_name.Items.Insert(0, "")
    End Sub
    Sub LoadCost()
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.COST_CENTER �s�X, B.COST_CENTER_NAME �W�� FROM FWEB_ONLB_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = '" + txt_org_no.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                 " AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONLB' " & _
                 " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) " & _
                 " ORDER BY A.COST_CENTER "
        dd_cost_name.DataSource = db.FillDataSet(sqlstr).Tables(0)
        dd_cost_name.DataValueField = "�s�X"
        dd_cost_name.DataTextField = "�W��"
        dd_cost_name.DataBind()
        dd_cost_name.Items.Insert(0, "")
    End Sub
    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�D�s�説�A
            btn1_find.Enabled = True
            btn2_ex.Enabled = True
            btn3_inp.Enabled = True
            btn4_ex.Enabled = True
            btn5_tran.Enabled = True
        End If
    End Sub
    Sub txt_state()
        dd_org_name.Disabled = False
        dd_cost_name.Disabled = False
        txt_org_no.Disabled = False
        txt_cost_no.Disabled = False
    End Sub

    Private Sub btn1_find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1_find.Click
        Dim ds As New DataSet
        Dim dv As New DataView
        Dim strsql As String

        '�d�߻�Ω���
        If CheckData() = False Then
            Exit Sub
        End If
        Try
            ExecSP()
            strsql = "SELECT TO_CHAR(T.PERIOD_NAME,'yyyy/mm/dd') PERIOD_NAME, T.ORG, T.TRANSACTION_TYPE, T.COST_CENTER, T.COST_NAME, T.BONDED_FLAG, T.PRODUCT_NUM, T.PRODUCT_DESC, T.UOM, T.PRE_ONHAND, T.NOW_WASTE" & _
                     " FROM FWEB_ONL_WASTERPT_TMP T WHERE T.MUSER='" + Context.User.Identity.Name + "'"
            If strsql <> "" Then
                ds = db.FillDataSet(strsql)
                dv = ds.Tables(0).DefaultView
                dg.DataSource = dv
                dg.DataBind()
            End If
            GetPageInfo()
        Catch ex As Exception
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('���X�����X��.')</script>")
                Exit Sub
        Finally
           If Not ds Is Nothing Then
              ds.Dispose()
           End If
        End Try
            btn_state(0)
        End Sub

        Sub GetPageInfo()
            Dim strsql As String
            strsql = "select count(*) from FWEB_ONL_WASTERPT_TMP T  where MUSER='" + context.User.Identity.Name + "'"
            Dim strsql1 As String = db.GetExecuteScalar(strsql).ToString
            Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
        End Sub
        Sub ExecSP()
            '����StoreProcedure
            Dim cmd As New OleDbCommand
            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_ONLB_WASTERPT_SP"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn
                    cmd.Parameters.Add(New OleDbParameter("P_ORG", OleDbType.VarChar, 15))
                    cmd.Parameters.Add(New OleDbParameter("P_SDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_EDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_COST_CENTER", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_USER_ID", OleDbType.VarChar, 15))

                    cmd.Parameters("P_ORG").Value = txt_org_no.Value
                    cmd.Parameters("P_SDATE").Value = Text1.Value
                    cmd.Parameters("P_EDATE").Value = Text2.Value.Trim
                    cmd.Parameters("P_COST_CENTER").Value = txt_cost_no.Value
                    cmd.Parameters("P_USER_ID").Value = Context.User.Identity.Name
                    cmd.ExecuteNonQuery()
                Catch ex As Exception
                    Response.Write("<script>alert('" & ex.Message.Replace("'", "-") & "')</script>")
                Finally
                    cn.Close()
                End Try
            End If
        End Sub
        Function CheckData() As Boolean
            '�ˬd�d�߱���
            Dim inti As Int16 = 0
            If txt_org_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
                Return False
            End If
            If txt_org_no.Value <> "" Then
                'CHECK�O�_���u�W���s�L�I���t�O
                Dim strsql1 As String = "SELECT COUNT(*) FROM FWEB_ONLB_DEPT where org='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���t�O�D�u�W���s_�s�׫O�|�L�I���t�O�A��CHECK! �Y���s�W���L�I���t�O�A�гq���s�ת��ޤ�IT���s�W!');</script>")
                End If
                'CHECK�O�_���t�O�v��
                Dim strsql2 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                        "AND PROJ_NO = 'ONLB' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���s�ת��ޤ�IT���s�W!');</script>")
                End If

                If txt_cost_no.Value <> "" Then
                    'CHECK�O�_���u�W���s�L�I����������
                    Dim strsql3 As String = "SELECT COUNT(*) FROM FWEB_ONLB_DEPT WHERE ORG ='" + txt_org_no.Value.Trim + "' AND COST_CENTER = '" + txt_cost_no.Value.Trim + "'"
                    If db.GetExecuteScalar(strsql3) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���s�ת��ޤ�IT���s�W!');</script>")
                    End If
                    'CHECK�O�_�����������v��
                    Dim strsql4 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                            "AND PROJ_NO = 'ONLB' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "' " & _
                                            "AND DECODE(COST_CENTER,'ALL','" + txt_cost_no.Value.Trim + "',COST_CENTER)='" + txt_cost_no.Value.Trim + "' "
                    If db.GetExecuteScalar(strsql4) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���s�ת��ޤ�IT���s�W!');</script>")
                    End If
                End If
            End If
            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function

    Private Sub btn2_ex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2_ex.Click
        '��Ω�����Excel
        Response.Write("<script>window.open(' " + TranToExcel() + " ')</script>")
    End Sub
    Function TranToExcel() As String
        '��Ω�����Excel
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
        Dim sTemplate As String = Server.MapPath("~") & "\ONLB_Template\ONLB_TRANSFER_EXCEL.xls"
        Dim savepath As String = PublicM.GetSessionDataRoot_Bond(context) + "ONLB_TRANSFER_EXCEL.xls" 'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot_Bond(context) + "ONLB_TRANSFER_EXCEL.xls" 'JavaScript�}��xls���|,�n�Psavepath�P

        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

            '��R���
            Dim ds As DataSet
            Dim sqlstr As String
            sqlstr = "SELECT TO_CHAR(t.PERIOD_name,'YYYY/MM/DD') PERIOD_NAME, T.ORG, T.TRANSACTION_TYPE, T.COST_CENTER, T.COST_NAME, T.BONDED_FLAG, T.PRODUCT_NUM, T.PRODUCT_DESC, T.UOM, T.PRE_ONHAND, T.NOW_WASTE" & _
                     " FROM FWEB_ONL_WASTERPT_TMP T WHERE MUSER='" + context.User.Identity.Name + "'"
            ds = db.FillDataSet(sqlstr)

            Dim x, y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "PERIOD_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("PERIOD_NAME").ToString
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("ORG").ToString
                            j = j + 1
                        Next
                    Case "TRANSACTION_TYPE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 4) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "COST_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 5) = ds.Tables(0).Rows(x).Item("COST_NAME").ToString
                            j = j + 1
                        Next
                    Case "BONDED_FLAG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 6) = ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_NUM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_DESC"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                            j = j + 1
                        Next
                    Case "UOM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString
                            j = j + 1
                        Next
                    Case "PRE_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "NOW_WASTE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            Return JSsavepath
        Catch ex As Exception
            Throw ex
        Finally
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If


            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If
            'GC.Collect()
        End Try
    End Function

    Private Sub btn4_ex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4_ex.Click
        '���`����
        Response.Write("<script>window.open(' " + TranToExcelError() + " ')</script>")
    End Sub
    Function TranToExcelError() As String
        '���`����
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
        Dim sTemplate As String = Server.MapPath("~") & "\ONLB_Template\ONLB_TRANSFER_ERROR.xls"
        Dim savepath As String = PublicM.GetSessionDataRoot_Bond(context) + "ONLB_TRANSFER_ERROR.xls" 'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot_Bond(context) + "ONLB_TRANSFER_ERROR.xls" 'JavaScript�}��xls���|,�n�Psavepath�P

        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

            '��R���
            Dim ds As DataSet
            Dim sqlstr As String
            sqlstr = "SELECT * FROM FWEB_ONLB_TRANSFER_ERROR WHERE MUSER='" + context.User.Identity.Name + "' AND FUNC_NO='ONLB_TRANSFER'"
            ds = db.FillDataSet(sqlstr)

            Dim x, y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "REASON"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("REASON").ToString
                            j = j + 1
                        Next
                    Case "PERIOD_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            If Not IsDBNull(ds.Tables(0).Rows(x).Item("PERIOD_NAME")) Then
                                oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("PERIOD_NAME")
                            Else
                                oCells(j + 2, 2) = ""
                            End If
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("ORG").ToString
                            j = j + 1
                        Next

                    Case "TRANSACTION_TYPE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 4) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 5) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "BONDED_FLAG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 6) = "'" + ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_NUM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_DESC"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                            j = j + 1
                        Next
                    Case "UOM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString
                            j = j + 1
                        Next
                    Case "PRE_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "NOW_WASTE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString
                            j = j + 1
                        Next
                    Case "NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString
                            j = j + 1
                        Next
                        'Case "BONDED_NOW_ONHAND"
                        '    j = 0
                        '    For x = 0 To ds.Tables(0).Rows.Count - 1
                        '        oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString
                        '        j = j + 1
                        '    Next
                    Case "REMARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("REMARK").ToString
                            j = j + 1
                        Next
                    Case "MDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            If Not IsDBNull(ds.Tables(0).Rows(x).Item("MDATE")) Then
                                oCells(j + 2, 14) = "'" + ds.Tables(0).Rows(x).Item("MDATE").ToString.Substring(0, 10)
                            Else
                                oCells(j + 2, 14) = ""
                            End If
                            j = j + 1
                        Next
                    Case "MUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 15) = "'" & ds.Tables(0).Rows(x).Item("MUSER").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            Return JSsavepath
        Catch ex As Exception
            Throw ex
        Finally
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If
            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If
            'GC.Collect()
        End Try
    End Function
        Sub sysdate()
            Dim sqlstr As String
            sqlstr = "SELECT A.ORG,A.START_DATE,A.END_DATE FROM FWEB_ONLB_CALENDAR A,(SELECT T.ORG FROM FWEB_USER_ORGAU_D O, FWEB_ONLB_DEPT T" & _
                 " WHERE O.USER_ID = '" + Context.User.Identity.Name + "' AND O.SYST_NO = 'FWEB' AND O.PROJ_NO = 'ONLB' AND DECODE(O.ORG, 'ALL', T.ORG, O.ORG) = T.ORG " & _
                 " AND DECODE(O.COST_CENTER, 'ALL', T.COST_CENTER, O.COST_CENTER) = T.COST_CENTER AND ROWNUM = 1) B" & _
                 " WHERE A.ORG = B.ORG AND A.CLOSE_DATE IS NULL"
            Dim ds As New DataSet
            ds = db.FillDataSet(sqlstr)
            If ds.Tables(0).Rows.Count <> 0 Then
                txt_org_no.Value = ds.Tables(0).Rows(0).Item("ORG")
                Text1.Value = ds.Tables(0).Rows(0).Item("START_DATE")
                Text2.Value = ds.Tables(0).Rows(0).Item("END_DATE")
            End If
        End Sub
    Sub GetLastOfMonthDate()
        Dim NewDate As Date
        Dim TheYear As String
        Dim TheMonth As String

        NewDate = DateAdd("m", 1, Now())
        TheYear = Year(NewDate)
        TheMonth = Month(NewDate)

        NewDate = DateAdd("d", -1, CDate(TheYear & "-" & TheMonth & "-01"))
        Text2.Value = Format(NewDate, "yyyy/MM/dd")
    End Sub

    Private Sub btn5_tran_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5_tran.Click
        '���ɮ榡
        Response.Write("<script>window.open('ONLB_Template/ONLB_TRANSFER_SPEC.xls ')</script>")
    End Sub

    Private Sub btn3_inp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3_inp.Click
        '�����u�W���s������J
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "open", "<script language='JavaScript'>window.open('FWEB_ONLB_TRANSFER_EXCELIN.aspx','','height=180,width=430') </script>")
    End Sub


    Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
        dg.CurrentPageIndex = e.NewPageIndex
        Dim ds As New DataSet
        Dim dv As New DataView
        Dim strsql As String
        strsql = "SELECT TO_CHAR(T.PERIOD_NAME,'YYYY/MM/DD') PERIOD_name,T.ORG,T.TRANSACTION_TYPE,T.COST_CENTER,T.COST_NAME,T.PRODUCT_NUM,T.PRODUCT_DESC,T.UOM,T.PRE_ONHAND,T.NOW_WASTE " & _
                 "FROM FWEB_ONL_WASTERPT_TMP T WHERE T.MUSER='" + context.User.Identity.Name + "'"
        If strsql <> "" Then
            ds = db.FillDataSet(strsql)
            dv = ds.Tables(0).DefaultView
            dg.DataSource = dv
            dg.DataBind()
        End If
        GetPageInfo()
    End Sub

    Private Sub txt_org_no_DataBinding(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_org_no.DataBinding

    End Sub

    Private Sub txt_org_no_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_org_no.Disposed

    End Sub
End Class

End Namespace
