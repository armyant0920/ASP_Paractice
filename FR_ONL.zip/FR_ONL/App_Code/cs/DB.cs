﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using Oracle.ManagedDataAccess.Client;

namespace DB
{
    public class DbHelperOra
    {
        public static string ConnString;  

        //Exists:執行SQL語句,傳回存在否
        public static bool Exists(string strSql)
        {
            object obj = GetSingle(strSql);
            int cmdresult;
            if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
            {
                cmdresult = 0;
            }
            else
            {
                cmdresult = int.Parse(obj.ToString());
            }
            if (cmdresult == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
     
        //Exists:執行SQL語句,傳回存在否
        public static Boolean Exists(string strSql, OracleParameter[] sqlParams)
        {
            Object obj = GetSingle(strSql, sqlParams);
            int cmdresult;
            if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
            {
                cmdresult = 0;
            }
            else
            {
                cmdresult = int.Parse(obj.ToString());
            }
            if (cmdresult == 0) {return false;} else {return true;}
        }

   
        //ExecuteSql:執行SQL語句，傳回影響的記錄數
        public static int ExecuteSql(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
          {
              using (OracleCommand cmd = new OracleCommand(SQLString, connection))
              {
                  try 
                  {
                      connection.Open();
                      cmd.BindByName = true;//2022/03/07 kevin
                      int rows = cmd.ExecuteNonQuery();
                      return rows;
                  }
                  catch (OracleException E)
                  {
                      connection.Close();
                      throw new Exception(E.Message);
                  }
              }
          }
       }
        
        //ExecuteSql:執行SQL語句，傳回影響的記錄數
        public static int ExecuteSql(string SQLString, params OracleParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                using (OracleCommand cmd = new OracleCommand())
                {
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                    cmd.Connection = connection;
                    cmd.CommandText = SQLString;
                    cmd.BindByName = true;//2022/03/07 kevin
                    if (cmdParms != null)
                    {
                        cmd.Parameters.AddRange(cmdParms);
                    }
                    OracleTransaction tx = connection.BeginTransaction();
                    cmd.Transaction = tx;
                    try
                    {
                        Console.WriteLine(cmd.CommandText);
                        int a = cmd.ExecuteNonQuery();
                       
                        tx.Commit();
                        return a;
                    }
                    catch (OracleException E)
                    {
                        tx.Rollback();
                        System.Diagnostics.Debug.WriteLine("Exception info:"+E.Message);
                        throw new Exception(E.Message); //--這裡沒有處理Exception,會造成程式中斷
                        
                        connection.Close();
                      
                        return 0;
                    }
                }
            }
        }

        //ExecuteScalarSQL:執行SQL語句,傳回結果
        public static Object ExecuteScalarSQL(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                using (OracleCommand cmd = new OracleCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        Object scalar = cmd.ExecuteScalar();
                        return scalar;
                    }
                    catch (OracleException E)
                    {
                        connection.Close();
                        throw new Exception(E.Message);
                    }
                }
            }
        }

        //ExecuteSqlTran:執行一條SQL語句
        public static void ExecuteSqlTran(string SQLString)
        {
            using (OracleConnection conn = new OracleConnection(ConnString))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                OracleTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    cmd.CommandText = SQLString;
                    cmd.ExecuteNonQuery();
                    tx.Commit();
                }
                catch (OracleException E)
                {
                    tx.Rollback();
                    throw new Exception(E.Message);
                }
            }
        }   

        //ExecuteSqlTran:執行多條SQL語句
        public static void ExecuteSqlTran(ArrayList SQLStringList)
        {
            using (OracleConnection conn = new OracleConnection(ConnString))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                OracleTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n=0; n < SQLStringList.Count;n++)
                    {
                        string strsql = (string)SQLStringList[n];
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }                        
                    }
                    tx.Commit();
                }
                catch (OracleException e)
                {
                    tx.Rollback();
                    throw new Exception(e.Message);
                }
            }
        }


        //ExecuteSqlTran:執行多條SQL語句
        //<param name="SQLStringList">SQL語句的Hashtable（key為sql語句，value是该語句的Parameter[]）</param>
        public static void ExecuteSqlTran(Hashtable SQLStringList)
        {
            using (OracleConnection conn = new OracleConnection(ConnString))
            {
                conn.Open();
                using (OracleTransaction trans = conn.BeginTransaction())
                {
                    OracleCommand cmd = new OracleCommand();
                    try 
                    {
                        foreach (DictionaryEntry myDE in SQLStringList)
                        {
                            string cmdText = myDE.Key.ToString();
                            OracleParameter[] cmdParms = myDE.Value as OracleParameter[];  //使用as關鍵字,若轉型失敗會回傳null
                            PrepareCommand(cmd, conn, trans, cmdText, cmdParms);
                            int val = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();

                            trans.Commit();
                        }
                    }
                    catch 
                    {
                        trans.Rollback();
                        throw;
                    }
                }
            }
        }

        //GetDataTables:執行多個SQL語句,傳回資料至DataSet
        public static DataSet GetDataTables(ArrayList SQLStringList)
        {
            DataSet ds = new DataSet();
            using (OracleConnection conn = new OracleConnection(ConnString))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        ds.Tables.Add();
                        string strsql = Convert.ToString(SQLStringList[n]);
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            da.Fill(ds.Tables[n]);
                        }
                    }
                }
            }
            return ds;
        }
        
        //GetSingle:執行一條計算查詢结果語句，返回查詢结果（object）
        public static Object GetSingle(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                using (OracleCommand cmd = new OracleCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        Object obj = cmd.ExecuteScalar();
                         if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
                         {
                             return null;
                         }
                         else
                         {
                             return obj;
                         }
                    }
                    catch (OracleException e)
                    {
                        connection.Close();
                        throw new Exception(e.Message);
                    }
                }
            }
        }

       //GetSingle:執行一條計算查詢结果語句，返回查詢结果（object）
        public static Object GetSingle(string SQLString, params OracleParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                using (OracleCommand cmd = new OracleCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                        Object obj = cmd.ExecuteScalar();
                        cmd.Parameters.Clear();

                        if ((@Object.Equals(obj, null)) || (@Object.Equals(obj, System.DBNull.Value)))
                        {
                            return null;
                        }
                        else
                        {
                            return obj;
                        }
                    }
                    catch (OracleException E)
                    {
                        throw new Exception(E.Message);
                    }
                }
            }

        }

        //Query:執行查詢語句，傳回DataSet    
        public static DataSet Query(string SQLString)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                DataSet ds = new DataSet();
                try
                {
                   connection.Open();
                   OracleDataAdapter command = new OracleDataAdapter(SQLString, connection);
                   command.Fill(ds, "ds");
                }
                catch (OracleException ex)
                {
                   throw new Exception(ex.Message);
                }
                return ds;
            }
        }

        //Query:執行查詢語句，傳回DataSet   
        public static DataSet Query(string SQLString, params OracleParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                OracleCommand cmd = new OracleCommand();
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (OracleException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    return ds;
                }
            }
        }

        //RunProcedure:執行sp,傳回結果(DataSet)    
        public static DataSet RunProcedure(String storedProcName, IDataParameter[] cmdParms)
        {
           using (OracleConnection connection = new OracleConnection(ConnString))
          {
            DataSet ds = new DataSet();
            connection.Open();
            OracleTransaction trans = connection.BeginTransaction();
            OracleDataAdapter da = new OracleDataAdapter();
            da.SelectCommand = BuildQueryCommand(connection, storedProcName, cmdParms);
            da.SelectCommand.Transaction = trans;
            try
            {
               da.Fill(ds);
               trans.Commit();
            }
            catch (OracleException ex)
            {
               trans.Rollback();
               throw ex;
            }
            finally
            {
              connection.Close();
            }
            return ds;
          }
        }

        //ExecuteProcedureNoMessage:執行sp,沒有傳回Message
        public static void ExecuteProcedureNoMessage(string storedProcName, IDataParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                if (connection.State != ConnectionState.Open)
                {
                   connection.Open();
                }
                OracleCommand command = BuildQueryCommand(connection, storedProcName, cmdParms);
                command.ExecuteNonQuery();
            }            
        }

        //ExecuteProcedure:執行sp,傳回Message
        public static string ExecuteProcedure(string storedProcName, IDataParameter[] cmdParms)
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                string V_Message;
                if (connection.State != ConnectionState.Open)
                {
                   connection.Open();
                }
                OracleCommand command = BuildQueryCommand(connection, storedProcName, cmdParms);
                command.ExecuteNonQuery();
                V_Message = Convert.ToString(command.Parameters["P_MESSAGE"].Value);
                return V_Message;
            }
        }

        //ExecuteProcedure:執行sp,傳回要回傳的Params
        public static string ExecuteProcedure(string storeProcName, IDataParameter[] cmdParms, int cmdOutParms) 
        {
            using (OracleConnection connection = new OracleConnection(ConnString))
            {
                string V_Message;
                if (connection.State != ConnectionState.Open)
                {
                   connection.Open();
                }
                OracleCommand command = BuildQueryCommand(connection, storeProcName, cmdParms);
                command.ExecuteNonQuery();
                V_Message = Convert.ToString(command.Parameters[cmdOutParms].Value);
                return V_Message;
            }
        }

        //BuildQueryCommand:建立OleDBCommand(用來傳回一個DataSet，而不是一個整數值)
        //<param name="connection">資料庫連接</param>
        //<param name="storeProcName">StoreProcedure</param>
        //<param name="cmdParms">參數</param>
        //<returns>OleDBCommand</returns>
        private static OracleCommand BuildQueryCommand(OracleConnection connection, string storedProcName, IDataParameter[] cmdParms)
        {
            OracleCommand command = new OracleCommand(storedProcName, connection);
            command.CommandType = CommandType.StoredProcedure;
            if (cmdParms != null)
            {
                foreach (OracleParameter parm in cmdParms)
                {
                    command.Parameters.Add(parm);
                }
            }
            return command;
        }

        //CheckParameters:給sp參數時，不能有nothing值  
        public static IDataParameter[] CheckParameters(IDataParameter[] parameters)
        {
            foreach (OracleParameter p in parameters)
          {
              if (((p.Direction == ParameterDirection.Input) || (p.Direction ==  ParameterDirection.InputOutput)) && (p.Value == null))
              {
                    p.Value = DBNull.Value;
              }              
          }
          return parameters;
        }

       //PrepareCommand
        private static void PrepareCommand(OracleCommand cmd, OracleConnection conn, OracleTransaction trans, string cmdText, IDataParameter[] cmdParms)
       {
           if (conn.State != ConnectionState.Open)
           {
              conn.Open();
           }
           cmd.Connection = conn;
           cmd.CommandText = cmdText;
           if (trans != null)
           {
               cmd.Transaction = trans;
           }
           cmd.CommandType = CommandType.Text;
           if (cmdParms != null)
           {
               foreach (OracleParameter parm in cmdParms)
               {
                   if (parm.Value == System.DBNull.Value)
                   {}
                   else
                   {
                       if (((parm.Direction ==  ParameterDirection.Input) || (parm.Direction == ParameterDirection.InputOutput)) && (parm.Value == null))
                       {
                           parm.Value = DBNull.Value;
                       }
                   }
                   cmd.Parameters.Add(parm);
               }
           }
       }

        //PrepareCommand2
        private static void Preparecommand2(OracleCommand cmd, OracleConnection conn, OracleTransaction trans, string cmdText, IDataParameter[] cmdParms)
        {
              if (conn.State != ConnectionState.Open)
              {
                  conn.Open();
              }
            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null) 
            {
                cmd.Transaction = trans;
            }
            cmd.CommandType = CommandType.Text;
            if (cmdParms != null)
            {
                cmd.Parameters.AddRange(cmdParms);
            }
        }

    }
}
