﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Data;
using OfficeOpenXml;
using System.Diagnostics;
using Oracle.ManagedDataAccess.Client;
using DB;

namespace PublicUMethod
{
    class PublicU
    {

#region SetConnString:設定連線字串
        public static string SetConnString(string[] InputParam)
        {
            string connString;
            connString ="User Id="+InputParam[3]+";Password="+InputParam[4]+";Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST="+InputParam[0]+")(PORT="+InputParam[2]+")))(CONNECT_DATA=(SERVICE_NAME="+InputParam[1]+")))";            
            
            return connString;
        }
#endregion

#region CheckNull:檢查空值
        public static Boolean CheckNull(params Object[] aSender)
        {
            for (int i=0; i < aSender.Length; i++)
            {                
                switch (Convert.ToString(aSender[i].GetType().Name).ToUpper())
                {
                    case "TEXTBOX":
                        {
                            TextBox myObj = (TextBox)aSender[i];
                            if (myObj.Text == "")
                            {
                                MessageBox.Show("欄位不可為空白!");
                                myObj.Focus();
                                aSender[i] = myObj;
                                return false;                                  
                            }
                            break;
                        }
                    case "COMBOBOX":
                        {
                            ComboBox myObj = (ComboBox)aSender[i];  
                            string selectvalue;
                            if (myObj.DataSource  == null)
                            {
                                selectvalue = myObj.SelectedItem.ToString();
                                
                            }
                            else
                            {
                                if (myObj.SelectedValue == null)
                                {
                                    selectvalue = "";
                                }
                                else
                                {
                                    selectvalue = myObj.SelectedValue.ToString();
                                }
                            }
                            if (selectvalue == "") 
                            {
                                MessageBox.Show("欄位不可為空白!");
                                myObj.Focus();
                                aSender[i] = myObj;
                                return false;                             
                            }
                            break;
                        }
                }
            }
            return true;
        }
#endregion

#region NullToStr:將NULL值改為""[string空白]
        public static string NullToStr(object eText)
        {
            string vText;
            if (eText == null)
            {
                vText = "";
            }
            else
            {
                vText = Convert.ToString(eText);
            }
            return vText;
        }
#endregion

#region TextToDouble:將文字改為數值
        public static double TextToDouble(string eText)
        {
            double vResult;
            if ((eText == null) || (eText == ""))
            {
                vResult = 0;
            }
            else
            {
                vResult = Convert.ToDouble(eText);
            }
            return vResult;
        }
#endregion

#region IsNumber:是否為數字
        public static Boolean IsNumber(string eText)
        {
            int cnt = 0;
            for (int i = 0; i < eText.Length; i++)
            {
                if ((i == 0) && (eText.Substring(i, 1) == "-"))
                {
                    continue;
                }
                else if (eText.Substring(i, 1) == ".")
                {
                    cnt = cnt + 1;
                    if (cnt > 1)
                    {
                        return false;
                    }
                }
                else
                {
                    if (!((eText.Substring(i, 1) == "0") || (eText.Substring(i, 1) == "1") || (eText.Substring(i, 1) == "2") ||
                          (eText.Substring(i, 1) == "3") || (eText.Substring(i, 1) == "4") || (eText.Substring(i, 1) == "5") ||
                          (eText.Substring(i, 1) == "6") || (eText.Substring(i, 1) == "7") || (eText.Substring(i, 1) == "8") ||
                          (eText.Substring(i, 1) == "9") ))
                        return false;
                }                
            }
            return true;
        }
#endregion

#region IsDate:是否為日期
        public static Boolean IsDate(string eText)
        {
            try
            {
                DateTime d1 = DateTime.ParseExact(eText, "yyyy/MM/dd", null);
                return true;
            }
            catch (Exception)
            {
                return false;
            }            
        }
#endregion

#region SetToolStripButtonState:設定ToolBoxButton
        public static void SetToolStripButtonState(ToolStripButton[] tsb, Boolean bol)
        {
            for (int i = 0; i < tsb.Length; i++)
            {
                tsb[i].Enabled = bol;
            }
        }
#endregion

#region SetTextBoxDisabled:設定TextBox為Disabled
        public static void SetTextBoxDisabled(params TextBox[] eAry)
        {
            for (int i=0; i < eAry.Length; i++)
            {
                eAry[i].ReadOnly = true;
                eAry[i].TabStop = false;
                eAry[i].BackColor = Color.LightYellow;
            }
        }    
#endregion

#region SetTextBoxEnabled:設定TextBox為Enabled
        public static void SetTextBoxEnabled(params TextBox[] eAry)
        {
            for (int i=0; i < eAry.Length; i++)
            {
                eAry[i].ReadOnly = false;
                eAry[i].TabStop = true;
                eAry[i].BackColor = Color.White;
            }
        }   
#endregion

#region SetComboBoxDisabled:設定ComboBox為Disabled
        public static void SetComboBoxDisabled(params ComboBox[] eAry)
        {
            for (int i = 0; i < eAry.Length; i++)
            {
                eAry[i].Enabled = false;
                eAry[i].TabStop = false;                
            }
        }
#endregion

#region SetComboBoxEnabled:設定ComboBox為Enabled
        public static void SetComboBoxEnabled(params ComboBox[] eAry)
        {
            for (int i=0; i < eAry.Length; i++)
            {
                eAry[i].Enabled = true;
                eAry[i].TabStop = true;
                eAry[i].BackColor = Color.White;
            }
        }    
#endregion

#region ComboBoxBind綁定ComboBox的資料來源
        public static void ComboBoxBind(ComboBox cbo, Dictionary<string, string> dic)
        {
            BindingSource bs = new BindingSource(dic, "");
            cbo.DataSource = bs;
            cbo.DisplayMember = "Value";
            cbo.ValueMember = "Key";
        }
#endregion

#region BuildDictionary:綁定Dictionary
     /*1.param name="dic_Key"    ：Dictionary的Key
      2.param name="dic_value1" ：Dictionary的Value      
     */
        public static Dictionary<string, string> BuildDictionary(string[] dic_key, string[] dic_value)
        {
            Dictionary<string, string> dic = new Dictionary<string,string>();
            for (int i = 0; i < dic_key.Length; i++)
            {
                dic.Add(dic_key[i], dic_value[i]);
            }
            return dic;
        }    
#endregion

#region InitField:畫面欄位初始值
        public static void InitField(params Object[] eAry)
        {
            for (int i=0; i < eAry.Length; i++)
            {                
                switch (Convert.ToString(eAry[i].GetType().Name).ToUpper())
                {
                    case "TEXTBOX":
                        {
                            TextBox myObj = (TextBox)eAry[i];
                            myObj.Text = "";
                            break;
                        }
                    case "COMBOBOX":
                        {
                            ComboBox myObj = (ComboBox)eAry[i];
                            myObj.Text = "";
                            break;
                        }
                }
            }
        }
#endregion

#region DataGridViewHeaderName:設定DataGridView的表頭名稱
        public static void DataGridViewHeaderName(ref DataGridView TargetView, string[] Col, string[] ColName)
        {
            for (int i = 0; i < Col.Length; i++)
            {
                TargetView.Columns[Col[i]].HeaderText = ColName[i].ToString();
            }
            return;
        }
#endregion

#region JumpToRecord:移到DataGridView資料至指定位置
    public static void JumpToRecord(ref DataGridView TargetView, int JumpType, bool bolCheckDisplay = true)
    {
       int intCurrentIndex = -1;
       int intFirstIndex = TargetView.FirstDisplayedScrollingRowIndex;
       if (TargetView.SelectedRows.Count == 1) intCurrentIndex = TargetView.SelectedRows[0].Index;

       switch (JumpType)
       {
          case 0: //首筆
            if (intCurrentIndex != 0)
            {
                TargetView.Rows[0].Selected = true;
                TargetView.FirstDisplayedScrollingRowIndex = 0;
            }
            break;
          case 1: //上筆
            if (intCurrentIndex == 0) return;
            TargetView.Rows[intCurrentIndex - 1].Selected = true;
            if ((!TargetView.SelectedRows[0].Displayed) && bolCheckDisplay)
            {
                TargetView.FirstDisplayedScrollingRowIndex = TargetView.SelectedRows[0].Index;
            }
            break;
          case 2: //下筆
            if ((intCurrentIndex + 1) >= TargetView.Rows.Count) return;
            TargetView.Rows[intCurrentIndex + 1].Selected = true;

            if (bolCheckDisplay)
            {
                if (!TargetView.SelectedRows[0].Displayed)
                {
                    TargetView.FirstDisplayedScrollingRowIndex = TargetView.SelectedRows[0].Index - TargetView.DisplayedRowCount(false);
                }

                if ((TargetView.DisplayedRowCount(true) != TargetView.DisplayedRowCount(false)) &&
                    ((intCurrentIndex + 2 - TargetView.FirstDisplayedScrollingRowIndex) == TargetView.DisplayedRowCount(true)))
                {
                    TargetView.FirstDisplayedScrollingRowIndex = TargetView.FirstDisplayedScrollingRowIndex + 1;
                }
            }
            break;
          case 3: //末筆
            if ((intCurrentIndex + 1) >= TargetView.Rows.Count) return;
            TargetView.Rows[TargetView.Rows.Count - 1].Selected = true;

            if (bolCheckDisplay)
            {
                if ((TargetView.Rows.Count - TargetView.DisplayedRowCount(false) - 1) < 0)
                {
                    TargetView.FirstDisplayedScrollingRowIndex = 0;
                }
                else
                {
                    TargetView.FirstDisplayedScrollingRowIndex = TargetView.Rows.Count - TargetView.DisplayedRowCount(false) - 1;
                }

                if ((TargetView.DisplayedRowCount(true) != TargetView.DisplayedRowCount(false)) &&
                    ((TargetView.Rows.Count - TargetView.FirstDisplayedScrollingRowIndex) == TargetView.DisplayedRowCount(true)))
                {
                    TargetView.FirstDisplayedScrollingRowIndex = TargetView.FirstDisplayedScrollingRowIndex + 1;
                }
            }
            break;
          default:
            return;
        }
    }

#endregion

#region ExcelFile:轉出Excel
       public static void ExcelFile(DataTable dt, string[] Col, string[] ColType, string[] ColName, string Filename, bool AutoWidthFit=false)       
       {
           string pathname = @"C:\Report\" + Filename + ".xlsx";
           FileStream fsTarget = new FileStream(pathname, FileMode.Create, FileAccess.Write);
           ExcelPackage oEp = new ExcelPackage(fsTarget);
           ExcelWorksheet oSheet;
           
           string exitflag = "N";
           int row;           
           int drow = 0;   //記錄資料總筆數
           int p1 = dt.Rows.Count / 1048000;
           int p2 = dt.Rows.Count % 1048000;
           if (p2 > 0)
           {
               p1 = p1 + 1;  //總共幾個sheet
           }

           try
           {
               if (p1 == 0)
               {
                   row = 1;
                   oEp.Workbook.Worksheets.Add("工作表1");
                   oSheet = oEp.Workbook.Worksheets[1];
                   for (int i = 0; i < ColName.Length; i++)
                   {
                       oSheet.Cells[row, i + 1].Value = ColName[i];
                   }
                   //欄位名稱粗體
                   ExcelRange oRangeHead = oSheet.Cells[row, 1, row, ColName.Length];
                   oRangeHead.Style.Font.Bold = true;
                   oEp.Save();
                   fsTarget.Close();
               }
               else
               {
                   for (int i = 1; i <= p1; i++)
                   {
                       row = 1;
                       exitflag = "N";
                       string sheetname = "工作表" + i.ToString();
                       oEp.Workbook.Worksheets.Add(sheetname);
                       oSheet = oEp.Workbook.Worksheets[i];
                       //欄位名稱
                       for (int j = 0; j < ColName.Length; j++)
                       {
                           oSheet.Cells[row, j + 1].Value = ColName[j];                                                     
                       }  
                       ExcelRange oRangeHead = oSheet.Cells[row, 1, row, ColName.Length];
                       //oRangeHead.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;  //必填
                       //oRangeHead.Style.Fill.BackgroundColor.SetColor(Color.LightSkyBlue);
                       oRangeHead.Style.Font.Bold = true;
                       //資料
                       while ((exitflag == "N") && (drow < dt.Rows.Count))
                       {
                           row = row + 1;
                           for (int j = 0; j < Col.Length; j++)
                           {
                               if (ColType[j] == "" || ColType[j] == "D")
                               {
                                   oSheet.Cells[row, j + 1].Value = dt.Rows[drow][Col[j]].ToString();
                               }
                               else
                               {
                                   oSheet.Cells[row, j + 1].Value = dt.Rows[drow][Col[j]];
                               } 
                           }                           
                           drow = drow + 1;
                           if (row > 104800)
                           {
                               exitflag = "Y";
                           }
                       }
                       //欄位型態
                       for (int j = 0; j < ColType.Length; j++)
                       {
                           ExcelRange oRange = oSheet.Cells[2, j + 1, row, j + 1];
                           switch (ColType[j])
                           {
                               case "":  //文字
                                   oRange.Style.Numberformat.Format = "@";
                                   break;
                               case "Y": //數字                                   
                                   break;
                               case "Q": //數字,個位數,顯示到小數點2位
                                   oRange.Style.Numberformat.Format = "0.00_);[Red](0.00)";
                                   break;
                               case "D":  //數字,個位數,千位一撇的顯示
                                   oRange.Style.Numberformat.Format = "#,##0_);[Red](#,##0)";
                                   break;
                               case "E":  //數字,取到千元,千位一撇的顯示
                                   oRange.Style.Numberformat.Format = "#,###,;[Red](#,###,)";
                                   break;
                               case "P":  //百分比
                                   oRange.Style.Numberformat.Format = "0.0%";
                                   break;
                               case "T":  //日期
                                   oRange.Style.Numberformat.Format = "yyyy/mm/dd";
                                   break;
                               default:
                                   break;
                           }
                           if (AutoWidthFit == true)
                           {
                               oSheet.Column(j+1).AutoFit(); //自動欄寬
                           }
                       }
                   }
                   oEp.Save();
                   fsTarget.Close();
               }
               Process.Start(pathname); //開啟檔案
           }
           catch (Exception E)
           {               
               fsTarget.Close();
               throw new Exception(E.Message);
           }                    
       }
#endregion

#region ExcelFile:轉出Excel(不同sheet)
       static FileStream fsTarget;
       static ExcelPackage oEp;
       public static void ExcelFile(DataTable dt, string[] Col, string[] ColType, string[] ColName, int sheetno, string sheetname, string Filename, Boolean openfile, bool AutoWidthFit=false)       
       {
           string pathname = @"C:\Report\" + Filename + ".xlsx";           
           if (sheetno == 1)
           {
               fsTarget = new FileStream(pathname, FileMode.Create, FileAccess.Write);
               oEp = new ExcelPackage(fsTarget);
           }           
           ExcelWorksheet oSheet;
           oEp.Workbook.Worksheets.Add(sheetname);
           oSheet = oEp.Workbook.Worksheets[sheetno];
           
           try
           {
               int row = 1;
               //欄位名稱
               for (int i = 0; i < ColName.Length; i++)
               {
                   oSheet.Cells[row, i + 1].Value = ColName[i];
               }
               //欄位名稱粗體
               ExcelRange oRangeHead = oSheet.Cells[row, 1, row, ColName.Length];                              
               //oRangeHead.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;  //必填
               //oRangeHead.Style.Fill.BackgroundColor.SetColor(Color.LightSkyBlue);
               oRangeHead.Style.Font.Bold = true;
               //資料
               row = row + 1;
               for (int i = 0; i < dt.Rows.Count; i++)
               {
                   for (int j = 0; j < Col.Length; j++)
                   {
                       if (ColType[j] == "" || ColType[j] == "D")
                       {
                           oSheet.Cells[row, j + 1].Value = dt.Rows[i][Col[j]].ToString();
                       }
                       else
                       {
                           oSheet.Cells[row, j + 1].Value = dt.Rows[i][Col[j]];
                       }
                   }
                   row = row + 1;
               }
               //欄位型態
               for (int i = 0; i < ColType.Length; i++)
               {
                   ExcelRange oRange = oSheet.Cells[2, i + 1, row, i + 1];
                   switch (ColType[i])
                   {
                       case "":  //文字
                           oRange.Style.Numberformat.Format = "@";
                           break;
                       case "Y": //數字                                   
                           break;
                       case "Q": //數字,個位數,顯示到小數點2位
                           oRange.Style.Numberformat.Format = "0.00_);[Red](0.00)";
                           break;
                       case "D":  //數字,個位數,千位一撇的顯示
                           oRange.Style.Numberformat.Format = "#,##0_);[Red](#,##0)";
                           break;
                       case "E":  //數字,取到千元,千位一撇的顯示
                           oRange.Style.Numberformat.Format = "#,###,;[Red](#,###,)";
                           break;
                       case "P":  //百分比
                           oRange.Style.Numberformat.Format = "0.0%";
                           break;
                       case "T":  //日期
                           oRange.Style.Numberformat.Format = "yyyy/mm/dd";
                           break;
                       default:
                           break;
                   }
                   if (AutoWidthFit == true)
                   {
                       oSheet.Column(i + 1).AutoFit(); //自動欄寬
                   }
               }               
               if (openfile == true)
               {
                   oEp.Save();               
                   fsTarget.Close();
                   Process.Start(pathname); //開啟檔案
               }
           }
           catch (Exception E)
           {               
               fsTarget.Close();
               throw new Exception(E.Message);           
           }
       }
#endregion

#region ExcelFile:轉出Excel(指定欄位顏色)
       public static void ExcelFile(DataTable dt, string[] Col, string[] ColType, string[] ColName, Dictionary<string, Color> dicColor, string Filename, bool AutoWidthFit = false)
       {
           string pathname = @"C:\Report\" + Filename + ".xlsx";
           FileStream fsTarget = new FileStream(pathname, FileMode.Create, FileAccess.Write);
           ExcelPackage oEp = new ExcelPackage(fsTarget);
           ExcelWorksheet oSheet;

           string exitflag = "N";
           int row;
           int drow = 0;   //記錄資料總筆數
           int p1 = dt.Rows.Count / 1048000;
           int p2 = dt.Rows.Count % 1048000;
           if (p2 > 0)
           {
               p1 = p1 + 1;  //總共幾個sheet
           }

           try
           {
               if (p1 == 0)
               {
                   row = 1;
                   oEp.Workbook.Worksheets.Add("工作表1");
                   oSheet = oEp.Workbook.Worksheets[1];
                   for (int i = 0; i < ColName.Length; i++)
                   {
                       oSheet.Cells[row, i + 1].Value = ColName[i];
                       //顏色
                       ExcelRange oRangeColor= oSheet.Cells[row, i + 1, row, i + 1];
                       if (dicColor.ContainsKey(Col[i]) == true)
                       {
                           oRangeColor.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;  //必填
                           oRangeColor.Style.Fill.BackgroundColor.SetColor(dicColor[Col[i]]);
                       }
                   }
                   //欄位名稱粗體
                   ExcelRange oRangeHead = oSheet.Cells[row, 1, row, ColName.Length];
                   oRangeHead.Style.Font.Bold = true;                   
                   oEp.Save();
                   fsTarget.Close();
               }
               else
               {
                   for (int i = 1; i <= p1; i++)
                   {
                       row = 1;
                       exitflag = "N";
                       string sheetname = "工作表" + i.ToString();
                       oEp.Workbook.Worksheets.Add(sheetname);
                       oSheet = oEp.Workbook.Worksheets[i];
                       //欄位名稱
                       for (int j = 0; j < ColName.Length; j++)
                       {
                           oSheet.Cells[row, j + 1].Value = ColName[j];
                       }
                       //欄位名稱粗體
                       ExcelRange oRangeHead = oSheet.Cells[row, 1, row, ColName.Length];                       
                       oRangeHead.Style.Font.Bold = true;
                       //資料
                       while ((exitflag == "N") && (drow < dt.Rows.Count))
                       {
                           row = row + 1;
                           for (int j = 0; j < Col.Length; j++)
                           {
                               if (ColType[j] == "" || ColType[j] == "D")
                               {
                                   oSheet.Cells[row, j + 1].Value = dt.Rows[drow][Col[j]].ToString();
                               }
                               else
                               {
                                   oSheet.Cells[row, j + 1].Value = dt.Rows[drow][Col[j]];
                               }
                           }
                           drow = drow + 1;
                           if (row > 104800)
                           {
                               exitflag = "Y";
                           }
                       }                                             
                       //欄位型態及顏色
                       for (int j = 0; j < ColType.Length; j++)
                       {
                           ExcelRange oRange = oSheet.Cells[2, j + 1, row, j + 1];
                           //顏色
                           if (dicColor.ContainsKey(Col[j]) == true)
                           {
                               oRange.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;  //必填
                               oRange.Style.Fill.BackgroundColor.SetColor(dicColor[Col[j]]);
                           }
                           //型態
                           switch (ColType[j])
                           {
                               case "":  //文字
                                   oRange.Style.Numberformat.Format = "@";
                                   break;
                               case "Y": //數字                                   
                                   break;
                               case "Q": //數字,個位數,顯示到小數點2位
                                   oRange.Style.Numberformat.Format = "0.00_);[Red](0.00)";
                                   break;
                               case "D":  //數字,個位數,千位一撇的顯示
                                   oRange.Style.Numberformat.Format = "#,##0_);[Red](#,##0)";
                                   break;
                               case "E":  //數字,取到千元,千位一撇的顯示
                                   oRange.Style.Numberformat.Format = "#,###,;[Red](#,###,)";
                                   break;
                               case "P":  //百分比
                                   oRange.Style.Numberformat.Format = "0.0%";
                                   break;
                               case "T":  //日期
                                   oRange.Style.Numberformat.Format = "yyyy/mm/dd";
                                   break;
                               default:
                                   break;
                           }
                           if (AutoWidthFit == true)
                           {
                               oSheet.Column(j + 1).AutoFit(); //自動欄寬
                           }
                       }
                   }
                   oEp.Save();
                   fsTarget.Close();
               }
               Process.Start(pathname); //開啟檔案
           }
           catch (Exception E)
           {
               fsTarget.Close();
               throw new Exception(E.Message);
           }
       }
#endregion

#region ReadFromExcel:Excel資料轉入
       /*參數:
         *Filename:要開啟的Excel檔案
         *keyCol:必要輸入欄位,放置excel的col位置(ex:1,2,3)
         *dicSql:Key[D]:刪除資料sql
                 Key[C]:檢查資料sql
                 Key[U]:修改資料sql
                 Key[I]:新增資料sql
         *dicParam:Key[D]:刪除資料參數
                   Key[C]:檢查資料參數
                   Key[U]:修改資料參數
                   Key[I]:新增資料參數
         *dicValue:Key[D]:刪除資料參數值,放置excel的col位置(ex:1,2,3)
                   Key[C]:檢查資料參數值,放置excel的col位置(ex:1,2,3)
                   Key[U]:修改資料參數值,放置excel的col位置(ex:1,2,3)
                   Key[I]:新增資料參數值,放置excel的col位置(ex:1,2,3)
         *dicColCheck:檢查資料: Key[excle的col位置] Value[符合資料]
        */
       public static Boolean ReadFromExcel(string Filename, int[] keyCol, Dictionary<string, string> dicSql, Dictionary<string, OracleParameter[]> dicParam, Dictionary<string,int[]> dicValue, Dictionary<int,string[]> dicColCheck)
       {
           using (FileStream fsSource = new FileStream(Filename, FileMode.Open, FileAccess.Read))
           {
               using (ExcelPackage ep = new ExcelPackage(fsSource))
               {
                   ExcelWorksheet oSheet = ep.Workbook.Worksheets[1];
                   int rowcount = oSheet.Dimension.End.Row;
                   OracleParameter[] paras;

                   //刪除資料(D)
                   if (dicSql.ContainsKey("D") == true)
                   {
                       if (dicParam.ContainsKey("D") == true)
                       {
                           paras = dicParam["D"];
                           DbHelperOra.ExecuteSql(dicSql["D"],dicParam["D"]);
                       }
                       else
                       {
                          DbHelperOra.ExecuteSql(dicSql["D"]);
                       }
                   }

                   for (int i = 2; i <= rowcount; i++)
                    {                                                
                        //檢查必要欄位是否有輸入
                        int KeyCount = 0;
                        for (int j = 0; j < keyCol.Length; j ++)
                        {                            
                            if ((Convert.ToString(oSheet.Cells[i,  keyCol[j]].Value) != "") && (Convert.ToString(oSheet.Cells[i,  keyCol[j]].Value) != null))
                            {
                                KeyCount = KeyCount+1;
                            }
                        }
                       //必要欄位皆有輸入才能繼續執行
                        if (KeyCount == keyCol.Length)
                        {
                            //檢查excel資料
                            string CheckOKFlag = "Y";
                            int CheckOK = 0;
                            foreach (KeyValuePair<int, string[]> kvp in dicColCheck)
                            {
                                switch (kvp.Value[0])
                                {
                                    case "NUMBER": //必須為數字                                     
                                        if (IsNumber(NullToStr(oSheet.Cells[i, kvp.Key].Value)) == false)
                                        {
                                            CheckOKFlag = "N";
                                        }
                                        break;
                                    case "NUMBER&MUST": //必須為數字且不能空白
                                        if (NullToStr(oSheet.Cells[i, kvp.Key].Value) == "")
                                        {
                                            CheckOKFlag = "N";
                                        }
                                        else
                                        {
                                            if (IsNumber(NullToStr(oSheet.Cells[i, kvp.Key].Value)) == false)
                                            {
                                                CheckOKFlag = "N";
                                            }
                                        }
                                        break;                          
                                    default:
                                        for (int k = 0; k < kvp.Value.Length; k++)
                                        {
                                            if (NullToStr(oSheet.Cells[i, kvp.Key].Value) == kvp.Value[k])
                                            {
                                                CheckOK = CheckOK + 1;
                                            }
                                        }
                                        if (CheckOK == 0)
                                        {
                                            CheckOKFlag = "N";
                                        }
                                        break;
                                }                                
                            }
                            if (CheckOKFlag == "Y")
                            {
                                string HaseFlag = "N";
                                //檢查資料是否存在(C)
                                if (dicSql.ContainsKey("C") == true)
                                {
                                    if (dicParam.ContainsKey("C") == true)
                                    {
                                        paras = dicParam["C"];
                                        int[] col = dicValue["C"];
                                        for (int j = 0; j < col.Length; j++)
                                        {
                                            paras[j].Value = oSheet.Cells[i, col[j]].Value;
                                        }
                                        if (DbHelperOra.Exists(dicSql["C"], paras))
                                        {
                                            HaseFlag = "Y";
                                        }
                                    }
                                    else
                                    {
                                        if (DbHelperOra.Exists(dicSql["C"]))
                                        {
                                            HaseFlag = "Y";
                                        }
                                    }
                                }
                                //有資料修改(U)
                                if ((HaseFlag == "Y") && (dicSql.ContainsKey("U") == true))
                                {
                                    paras = dicParam["U"];
                                    int[] col = dicValue["U"];
                                    for (int j = 0; j < col.Length; j++)
                                    {
                                        paras[j].Value = oSheet.Cells[i, col[j]].Value;
                                    }
                                    DbHelperOra.ExecuteSql(dicSql["U"], paras);
                                }
                                //無資料新增(I)
                                if ((HaseFlag == "N") && (dicSql.ContainsKey("I") == true))
                                {
                                    paras = dicParam["I"];
                                    int[] col = dicValue["I"];
                                    for (int j = 0; j < col.Length; j++)
                                    {
                                        paras[j].Value = oSheet.Cells[i, col[j]].Value;
                                    }
                                    DbHelperOra.ExecuteSql(dicSql["I"], paras);
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
               }
           }
           return true;
       }
#endregion

#region IsFileLocked:查看檔案是否被佔用
       public static bool IsFileLocked(string Filename)
       {
           try
           {
               using (File.Open(Filename, FileMode.Open, FileAccess.Write, FileShare.None))
               {
                   return false;
               }
           }
           catch (IOException exception)
           {
               var errorCode = Marshal.GetHRForException(exception) & 65535;
               return errorCode == 32 || errorCode == 33;
           }
           catch (Exception)
           {
               return false;
           }
       }
#endregion

    }
}
