﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;

/// <summary>
/// SQLInjectTest 的摘要描述
/// </summary>
public class SQLInjectTest
{
	/*public SQLInjectTest()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
	}*/

    public static bool validUrlData(string request) {

        bool result = false;
        if (request == "POST")
        {

            for (int i = 0; i < HttpContext.Current.Request.Form.Count; i++)
            {
                result = validData(HttpContext.Current.Request.Form[i].ToString());
                

                if (result)
                    break;
            }
        }
        else {
            for (int i = 0; i < HttpContext.Current.Request.QueryString.Count; i++) {

                result = validData(HttpContext.Current.Request.QueryString[i].ToString());

                if (result)
                    break;            
            }
            
        }
        
        return result;
    }


    private static bool validData(string input) {

        if (Regex.IsMatch(input, getRex())) {
            return true;
        
        
        }else{
            return false;

        }
    
    }


    private static string getRex() {


        string[] badstr = { "and", "exec", "insert", "select", "delete", "update", "or", "%", "-", ";","'" };
        string str_rex=".*(";
        for(int i=0;i<badstr.Length;i++){
            str_rex+=badstr[i]+"|";

        }
        str_rex+=").*";
        Console.WriteLine("str_rex={0}",str_rex);
        return  str_rex;
        

    
    
    
    
    }
    
}