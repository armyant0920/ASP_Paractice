Namespace FR

Public Class TextColumn
    Implements ITemplate
    Dim mstrColumnName As String
    Dim mintWidth As Integer = 100
    Dim mintRows As Integer = 3
    Dim mblnEnable As Boolean = True

    Dim WithEvents objTextBox As TextBox

    Public Sub New(ByVal strColumnName As String, Optional ByVal intWidth As Integer = 100, Optional ByVal intRows As Integer = 3, Optional ByVal blnEnable As Boolean = True)
        mstrColumnName = strColumnName
        mintWidth = intWidth
        mintRows = intRows
        mblnEnable = blnEnable
    End Sub
    Public Sub InstantiateIn(ByVal container As System.Web.UI.Control) Implements System.Web.UI.ITemplate.InstantiateIn
        objTextBox = New TextBox
        objTextBox.ID = "txt" & mstrColumnName
        objTextBox.Width = System.Web.UI.WebControls.Unit.Pixel(mintWidth)
        objTextBox.TextMode = TextBoxMode.SingleLine
        objTextBox.Rows = mintRows
        container.Controls.Add(objTextBox)

        Dim objValid As RegularExpressionValidator = New RegularExpressionValidator
        objValid.ControlToValidate = objTextBox.ID
        objValid.Display = ValidatorDisplay.Dynamic
        objValid.ErrorMessage = "*"
        objValid.ValidationExpression = "^\d+$"
        container.Controls.Add(objValid)
    End Sub


    Private Sub objTextBox_DataBinding(ByVal sender As Object, ByVal e As System.EventArgs) Handles objTextBox.DataBinding
        Dim objTextBox As TextBox = CType(sender, TextBox)
        Dim container As DataGridItem = CType(objTextBox.NamingContainer, DataGridItem)

        objTextBox.Text = "" 'mdlCommon.GetFieldValue(CType(container.DataItem, DataRowView).Item(mstrColumnName))
    End Sub
   
End Class

End Namespace

