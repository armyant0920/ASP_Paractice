Imports System.Data
Imports System.Data.OleDb

Namespace FR

    Public Module db
        Public OLEDBCONN As New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("conn").ToString())
        Public OLEDBCONN1 As New OleDbConnection(System.Configuration.ConfigurationManager.AppSettings("ncst1_conn").ToString())

        Sub ExecuteSQL(ByVal SQL As String)
            Dim Comm As New OleDbCommand(SQL, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                Comm.ExecuteNonQuery()
            Catch ex As Exception
                Throw ex
            Finally
                Comm.Dispose()
                OLEDBCONN.Close()
            End Try
        End Sub

        Sub ExecuteSQL(ByVal conn As OleDbConnection, ByVal SQL As String)
            Dim Comm As New OleDbCommand(SQL, conn)
            Try
                If conn.State = ConnectionState.Closed Then conn.Open()
                Comm.ExecuteNonQuery()
            Catch ex As Exception
                Throw ex
            Finally
                Comm.Dispose()
                conn.Close()
            End Try
        End Sub

        Function Get_ExecuteSQL_Result(ByVal SQL As String) As Integer
            Dim Comm As New OleDbCommand(SQL, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                Return Comm.ExecuteNonQuery()
            Catch ex As Exception
                Throw ex
            Finally
                Comm.Dispose()
                OLEDBCONN.Close()
            End Try
        End Function

        Function GetExecuteScalar(ByVal sqlstr As String) As Object
            Dim comm As New OleDbCommand(sqlstr, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                GetExecuteScalar = comm.ExecuteScalar
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                OLEDBCONN.Close()
            End Try
        End Function

        Function GetExecuteScalar(ByVal conn As OleDbConnection, ByVal sqlstr As String) As Object
            Dim comm As New OleDbCommand(sqlstr, conn)
            Try
                If conn.State = ConnectionState.Closed Then conn.Open()
                GetExecuteScalar = comm.ExecuteScalar
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                conn.Close()
            End Try
        End Function

        '�N�`�μ�����ƫ��O�إߦb�@������
        '��sql�ߤ@�ݭn����Ouserid-Kevin 2022/02/24
        Function loadorg(ByVal userid As String) As DataTable

            Dim sqlstr As String
            sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                     " WHERE A.ORG = B.ORG AND C.USER_ID = '" + userid + "' AND C.SYST_NO = 'FWEB' " & _
                     " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
            Return db.FillDataSet(sqlstr).Tables(0)



        End Function

        'Function FillDataSet(ByVal sql As String, ByVal tablename As String) As DataSet
        '    Try
        '        Dim ds As New DataSet
        '        Dim da As New OleDbDataAdapter(sql, OLEDBCONN)
        '        da.Fill(ds, tablename)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        OLEDBCONN.Close()
        '    End Try
        'End Function

        'Function FillDataSet(ByVal sql As String, ByVal tablename As String, ByVal ds As DataSet) As DataSet
        '    Try
        '        Dim da As New OleDbDataAdapter(sql, OLEDBCONN)
        '        da.Fill(ds, tablename)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        OLEDBCONN.Close()
        '    End Try
        'End Function


        Function FillDataSet(ByVal SQL As String) As DataSet
            Dim ds As New DataSet
            Dim da As New OleDbDataAdapter(SQL, OLEDBCONN)
            Try
                da.Fill(ds)
                Return ds
            Catch ex As Exception
                Throw ex
            Finally
                OLEDBCONN.Close()
                If Not ds Is Nothing Then
                   ds.Dispose()
                End If
            End Try
        End Function

        Function FillDataSet(ByVal sql As String, ByVal IntConnectType As Integer) As DataSet
            Dim ds As New DataSet
            Try
                Select Case IntConnectType
                       Case 1  'NCST1
                        Dim da As New OleDbDataAdapter(sql, OLEDBCONN1)
                            da.Fill(ds)
                            da.Dispose()
                       Case 2  'NCST2
                            Dim da As New OleDbDataAdapter(sql, OLEDBCONN)
                            da.Fill(ds)
                            da.Dispose()
                End Select
                Return ds
            Catch ex As Exception
                Throw ex
            Finally
                 Select Case 1
                       Case 1
                            OLEDBCONN1.Close()
                       Case 2
                            OLEDBCONN.Close()
                 End Select
                 If Not ds Is Nothing Then
                    ds.Dispose()
                 End If
            End Try
        End Function

        Function FillDataSet(ByVal querysql As String, ByVal dict As Dictionary(Of String, String), ByVal IntConnectType As Integer) As DataSet
            Dim ds As New DataSet
            Dim da As New OleDbDataAdapter()
            System.Diagnostics.Debug.WriteLine("4")
            Try
                Select Case IntConnectType
                    Case 1  'NCST1

                        da = New OleDbDataAdapter(querysql, OLEDBCONN1)
                    Case 2  'NCST2
                        da = New OleDbDataAdapter(querysql, OLEDBCONN)
                End Select

                'For Each kvp As KeyValuePair(Of String, String) In dict
                '    da.SelectCommand.Parameters.Add("@" + kvp.Key, OleDbType.VarChar).Value = "'" + kvp.Value + "'"

                '    System.Diagnostics.Debug.WriteLine("key=" + kvp.Key + ",value=" + kvp.Value)
                '    System.Diagnostics.Debug.WriteLine(da.SelectCommand.CommandText.ToString
                '                                       )
                'Next
                da.SelectCommand.Parameters.Add("@USER_ID", OleDbType.VarChar).Value = "'A1630'"
                System.Diagnostics.Debug.WriteLine(da.SelectCommand.CommandText.ToString)
                System.Diagnostics.Debug.WriteLine(da.SelectCommand.Parameters.ToString)

                da.Fill(ds)
                da.Dispose()


                Return ds
            Catch ex As Exception
                Throw ex
            Finally
                Select Case 1
                    Case 1
                        OLEDBCONN1.Close()
                    Case 2
                        OLEDBCONN.Close()
                End Select
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try



        End Function

        Function FillDataSet(ByVal querysql As String, ByVal infos As String(), ByVal IntConnectType As Integer) As DataSet
            Dim ds As New DataSet
            Dim da As New OleDbDataAdapter()

            System.Diagnostics.Debug.WriteLine("3")
            Try
                'Dim command As OleDbCommand



                Select Case IntConnectType
                    Case 1  'NCST1
                        'command = New OleDbCommand(querysql, OLEDBCONN1)
                        da = New OleDbDataAdapter(querysql, OLEDBCONN1)


                        'command = New OleDbCommand(querysql, OLEDBCONN1)

                        'da.SelectCommand.Connection = OLEDBCONN1


                    Case 2  'NCST2
                        da = New OleDbDataAdapter(querysql, OLEDBCONN)
                        'command = New OleDbCommand(querysql, OLEDBCONN)
                        'da.SelectCommand.Connection = OLEDBCONN

                End Select


                da.SelectCommand.Parameters.Add("@USER_ID", OleDbType.VarChar).Value = "'" + infos(0) + "'"

                da.SelectCommand.Parameters.Add("@PASSWORD", OleDbType.VarChar).Value = "'" + infos(1) + "'"
                System.Diagnostics.Debug.WriteLine("TEST " + da.SelectCommand.CommandText.ToString)
                'System.Diagnostics.Debug.WriteLine("TEST2 " + da.SelectCommand.Parameters("USER_ID").Value)
                'da.SelectCommand.Parameters("password").Value = infos(1)



                da.Fill(ds)
                da.Dispose()


                Return ds
            Catch ex As Exception
                Throw ex
            Finally
                Select Case 1
                    Case 1
                        OLEDBCONN1.Close()
                    Case 2
                        OLEDBCONN.Close()
                End Select
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try



        End Function







        'Function FillDataSet(ByVal conn As OleDbConnection, ByVal sql As String, ByVal tablename As String) As DataSet
        '    Try
        '        Dim ds As New DataSet
        '        Dim da As New OleDbDataAdapter(sql, conn)
        '        da.Fill(ds, tablename)
        '        Return ds
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        conn.Close()
        '    End Try
        'End Function

        Sub GetDataReader(ByRef dr As OleDbDataReader, ByVal sqlstr As String)         '�ե�datareader,�Ф��O�ϥ�byref �ޥΤ覡()
            Dim comm As New OleDbCommand(sqlstr, OLEDBCONN)
            Try
                If OLEDBCONN.State = ConnectionState.Closed Then OLEDBCONN.Open()
                dr = comm.ExecuteReader
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                'OLEDBCONN.Close()
            End Try
        End Sub

        Sub GetDataReader(ByVal conn As OleDbConnection, ByRef dr As OleDbDataReader, ByVal sqlstr As String)        '�ե�datareader,�Ф��O�ϥ�byref �ޥΤ覡()
            Dim comm As New OleDbCommand(sqlstr, conn)
            Try
                If conn.State = ConnectionState.Closed Then conn.Open()
                dr = comm.ExecuteReader
            Catch ex As Exception
                Throw ex
            Finally
                comm.Dispose()
                conn.Close()
            End Try
        End Sub

        Public Function GetDataReader(ByVal SQLText As String, ByVal Num As Integer) As String
            Dim myCMD As OleDbCommand = New OleDbCommand(SQLText, OLEDBCONN)
            Dim str As String = ""
            If OLEDBCONN.State = ConnectionState.Closed Then
                OLEDBCONN.Open()
            End If
            Dim myReader As OleDbDataReader = myCMD.ExecuteReader()
            Do While myReader.Read()
                str = myReader.GetString(Num)
            Loop
            myReader.Close()
            OLEDBCONN.Close()
            myCMD.Dispose()
            Return str
        End Function

        Sub CloseConn()
            If OLEDBCONN.State <> ConnectionState.Closed Then OLEDBCONN.Close()
        End Sub

        Sub CloseConn(ByVal conn As OleDbConnection)
            If conn.State <> ConnectionState.Closed Then conn.Close()
        End Sub

    End Module

End Namespace

