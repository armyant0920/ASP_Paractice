Namespace FR

Public Class CSCreatTable

    '�w�q�ܼ�
    Dim dtTemp As DataTable
    Private _ArrayFixHead() As String  '�T�w���Y���W��    
    Private _ArrayVarHead() As String  '���ʪ��Y���W��
    Private _ArrayVarCol() As String   '���ʪ����������W��

    Public Sub New()
        dtTemp = New DataTable
    End Sub

    'FillTable:��J���
        Sub FillTable(ByVal sqlstr As String, ByVal sortstr As String)
            Dim i, j As Integer
            Dim flag As String
            Dim ds As New DataSet
            Dim dv As DataView

            '�]�w����}�C,�ΥH�P�_�O�_���U�@�C 
            Dim compare(_ArrayFixHead.Length) As String
            For i = 0 To compare.Length - 1
                compare(i) = ""
            Next

            '�إߪ���
            ds = db.FillDataSet(sqlstr)
            dv = ds.Tables(0).DefaultView
            dv.Sort = sortstr

            For Each row As DataRowView In dv

                '�P�_�T�w���Y�O�_����,���ܴN�s�W�C
                j = 0
                flag = "Y"
                Do Until (flag = "N") Or j = _ArrayFixHead.Length
                    If row.Item(_ArrayFixHead(j)) Is DBNull.Value Or row.Item(_ArrayFixHead(j)) Is System.DBNull.Value Then
                        If compare(j) <> "" Then
                            flag = "N"
                        End If
                    ElseIf CStr(row.Item(_ArrayFixHead(j))) <> compare(j) Then
                        flag = "N"
                    End If
                    j = j + 1
                Loop

                If flag = "N" Then
                    '�s�W�@�C
                    Dim dr As DataRow = dtTemp.NewRow
                    '�T�w����
                    For j = 0 To _ArrayFixHead.Length - 1
                        dr.Item(_ArrayFixHead(j)) = IIf(row.Item(_ArrayFixHead(j)) Is DBNull.Value, "", row.Item(_ArrayFixHead(j)))
                        compare(j) = IIf(row.Item(_ArrayFixHead(j)) Is DBNull.Value, "", row.Item(_ArrayFixHead(j))) '�x�s�ܼ�,�P�_�O�_���U�@�C
                    Next
                    '���ʪ���
                    For j = 0 To _ArrayVarHead.Length - 1
                        If dtTemp.Columns.Contains(row.Item(_ArrayVarHead(j))) Then
                            dr.Item(row.Item(_ArrayVarHead(j))) = row.Item(_ArrayVarCol(j))
                        End If
                    Next
                    dtTemp.Rows.Add(dr)
                Else
                    '���ʪ���
                    Dim dr As DataRow = dtTemp.Rows(dtTemp.Rows.Count - 1)
                    For j = 0 To _ArrayVarHead.Length - 1
                        If dtTemp.Columns.Contains(row.Item(_ArrayVarHead(j))) Then
                            dr.Item(row.Item(_ArrayVarHead(j))) = row.Item(_ArrayVarCol(j))
                        End If
                    Next
                End If
            Next

        End Sub

    'FillTable:��J���
        Sub FillTable(ByVal ds As DataSet, ByVal sortstr As String)
            Dim i, j As Integer
            Dim flag As String
            Dim dv As DataView

            '�]�w����}�C,�ΥH�P�_�O�_���U�@�C 
            Dim compare(_ArrayFixHead.Length) As String
            For i = 0 To compare.Length - 1
                compare(i) = ""
            Next

            '�إߪ���
            dv = ds.Tables(0).DefaultView
            dv.Sort = sortstr

            For Each row As DataRowView In dv

                '�P�_�T�w���Y�O�_����,���ܴN�s�W�C
                j = 0
                flag = "Y"
                Do Until (flag = "N") Or j = _ArrayFixHead.Length
                    If IIf(row.Item(_ArrayFixHead(j)) Is DBNull.Value, "", row.Item(_ArrayFixHead(j))) <> compare(j) Then
                        flag = "N"
                    End If
                    j = j + 1
                Loop

                If flag = "N" Then
                    '�s�W�@�C
                    Dim dr As DataRow = dtTemp.NewRow
                    '�T�w����
                    For j = 0 To _ArrayFixHead.Length - 1
                        dr.Item(_ArrayFixHead(j)) = IIf(row.Item(_ArrayFixHead(j)) Is DBNull.Value, "", row.Item(_ArrayFixHead(j)))
                        compare(j) = IIf(row.Item(_ArrayFixHead(j)) Is DBNull.Value, "", row.Item(_ArrayFixHead(j))) '�x�s�ܼ�,�P�_�O�_���U�@�C
                    Next
                    '���ʪ���
                    For j = 0 To _ArrayVarHead.Length - 1
                        If dtTemp.Columns.Contains(row.Item(_ArrayVarHead(j))) Then
                            dr.Item(row.Item(_ArrayVarHead(j))) = row.Item(_ArrayVarCol(j))
                        End If
                    Next
                    dtTemp.Rows.Add(dr)
                Else
                    '���ʪ���
                    Dim dr As DataRow = dtTemp.Rows(dtTemp.Rows.Count - 1)
                    For j = 0 To _ArrayVarHead.Length - 1
                        If dtTemp.Columns.Contains(row.Item(_ArrayVarHead(j))) Then
                            dr.Item(row.Item(_ArrayVarHead(j))) = row.Item(_ArrayVarCol(j))
                        End If
                    Next
                End If
            Next

        End Sub

    'FillTable:��J������
    Sub FillColumn(ByVal AddNewRow As String, ByVal sqlstr As String)
        Dim vHaveCol, vPutRow, vSameRow, vCheckRow As String
        Dim i, j, k, p, row As Integer

        'Ū�����
        Dim ds As New DataSet
        Dim dt As New DataTable
        Dim dr As DataRow
        ds = db.FillDataSet(sqlstr)
        dt = ds.Tables(0)

        For i = 0 To dt.Columns.Count - 1

            'dtTemp�O�_�w�������
            vHaveCol = "N"
            For j = 0 To dtTemp.Columns.Count - 1
                If dtTemp.Columns(j).ColumnName = dt.Columns(i).ColumnName Then
                    vHaveCol = "Y"
                End If
            Next

            'dtTemp�S�������,�h�s�W���
            If vHaveCol = "N" Then
                Dim dc As New DataColumn
                dc.ColumnName = dt.Columns(i).ColumnName
                dtTemp.Columns.Add(dc)
            End If


            '��J���
            Select Case AddNewRow

                Case "Y" '�s�W�C

                    For j = 0 To dt.Rows.Count - 1

                        If i = 0 Then
                            dr = dtTemp.NewRow
                            dr.Item(dt.Columns(i).ColumnName) = dt.Rows(j)(i)
                            dtTemp.Rows.Add(dr)
                        Else
                            dr = dtTemp.Rows(j)
                            dr.Item(dt.Columns(i).ColumnName) = dt.Rows(j)(i)
                        End If

                    Next

                Case "N" '���s�W�C,�̩T�w���Y�ۦP,�h��J�ӦC

                    '�P�_�O�_���T�w���Y,�T�w���Y�O�Ψ��ˬd��ƭn����@�C��,�ҥH����JTable
                    vPutRow = "Y"
                    For Each s As String In _ArrayFixHead
                        If dt.Columns(i).ColumnName = s Then
                            vPutRow = "N"
                        End If
                    Next

                    '���O�T�w���Y,��JTable
                    If vPutRow = "Y" Then

                        For j = 0 To dt.Rows.Count - 1
                            k = 0
                            vCheckRow = "Y"
                            Do Until (vCheckRow = "N") Or k > dtTemp.Rows.Count - 1
                                '�P�_��ƬO�_�ŦX�T�w���Y
                                p = 0
                                vSameRow = "Y"
                                Do Until (vSameRow = "N") Or p > _ArrayFixHead.Length - 1
                                    If dt.Rows(j).Item(_ArrayFixHead(p)) <> dtTemp.Rows(k).Item(_ArrayFixHead(p)) Then
                                        vSameRow = "N"
                                    End If
                                    p = p + 1
                                Loop
                                '����P�T�w���Y���e�ۦP���C
                                If vSameRow = "Y" Then
                                    row = k
                                    vCheckRow = "N"
                                End If
                                k = k + 1
                            Loop
                            '��J�P�T�w���Y���e�ۦP���C
                            dr = dtTemp.Rows(row)
                            dr.Item(dt.Columns(i).ColumnName) = dt.Rows(j)(i)
                        Next

                    End If

                Case "A" '���s�W�C,��Query���ǩ�J

                    For j = 0 To dt.Rows.Count - 1
                        dr = dtTemp.Rows(j)
                        dr.Item(dt.Columns(i).ColumnName) = dt.Rows(j)(i)
                    Next

            End Select
        Next
    End Sub

    'AddFixColumn:�إߩT�w���Y���
    Sub AddFixColumn(ByVal ParamArray ColArray() As String)
        Dim i As Int16
        ReDim _ArrayFixHead(ColArray.Length)
        _ArrayFixHead = ColArray
        For i = 0 To _ArrayFixHead.Length - 1
            Dim dc As New DataColumn
            dc.ColumnName = _ArrayFixHead(i)
            dtTemp.Columns.Add(dc)
        Next
    End Sub

    'AddVarColumn:�إ߬��ʪ��Y���
    Sub AddVarColumn(ByVal date1 As DateTime, ByVal date2 As DateTime, ByVal ParamArray ColArray() As String)
        Dim i As Int16
        While date1 <= date2
            For i = 0 To ColArray.Length - 1
                AddColumn(ColArray(i) + date1.ToString("yyyy/MM"))
            Next
            date1 = date1.AddMonths(1)
        End While
    End Sub

    'AddVarColumn:�إ߬��ʪ��Y���
    Sub AddVarColumn(ByVal sqlstr As String)
        Dim ds As New DataSet
        Dim i, j As Integer
        ds = db.FillDataSet(sqlstr)
        For i = 0 To ds.Tables(0).Rows.Count - 1
            For j = 0 To ds.Tables(0).Columns.Count - 1
                Dim dc As New DataColumn
                dc.ColumnName = ds.Tables(0).Rows(i)(j)
                dtTemp.Columns.Add(dc)
            Next
        Next
    End Sub

    'SetVarGetColName:�]�w���ʪ��Y�n��������,(PS.���ʪ��Y�P���ʪ����n��������W�٨�Ӽƶ��۹���)
    Sub SetVarGetColName(ByVal ParamArray ColArray() As String)
        ReDim _ArrayVarHead(ColArray.Length)
        _ArrayVarHead = ColArray
    End Sub

    'SetVarGetCol:�]�w���ʪ����n��������,(PS.���ʪ��Y�P���ʪ����n��������W�٨�Ӽƶ��۹���)
    Sub SetVarGetCol(ByVal ParamArray ColArray() As String)
        ReDim _ArrayVarCol(ColArray.Length)
        _ArrayVarCol = ColArray
    End Sub

    'AddColumn:�W�[���
    Sub AddColumn(ByVal vColName As String)
        Dim dc As New DataColumn
        dc.ColumnName = vColName
        dtTemp.Columns.Add(dc)
    End Sub

    'RenameColName:�]�w���W��
    Sub RenameColName(ByVal bfrCol As String, ByVal aftCol As String)
        Dim i As Int16
        For i = 0 To dtTemp.Columns.Count - 1
            If dtTemp.Columns(i).ColumnName = bfrCol Then
                dtTemp.Columns(i).ColumnName = aftCol
            End If
        Next
    End Sub

    'ReplaceColName:�m�����W��
    Sub ReplaceColName(ByVal bfrCol As String, ByVal aftCol As String)
        Dim i As Int16
        For i = 0 To dtTemp.Columns.Count - 1
            dtTemp.Columns(i).ColumnName = dtTemp.Columns(i).ColumnName.Replace(bfrCol, aftCol)
        Next
    End Sub

    'GetTable:���oTable
    Public ReadOnly Property GetTable() As DataTable
        Get
            Return dtTemp
        End Get
    End Property

End Class

End Namespace
