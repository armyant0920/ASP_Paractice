Imports System.NET


Namespace FR

Public Module PublicM
    '�NMessage�r�ꤤ������,'�Ÿ��m���A��javascript�i�H���
        Function TrimMessage(ByVal sMessage As String) As String
            Dim i As Integer
            Dim rMessage As String = ""
            For i = 1 To Len(sMessage)
                If (Asc(Mid(sMessage, i, 1)) > 0 And Asc(Mid(sMessage, i, 1)) < 32) Or Asc(Mid(sMessage, i, 1)) > 127 Then
                    rMessage = rMessage & " "  'ascii�X����0~32��128~255�m�����ť�,��javascript�i�H���`���message
                Else
                    rMessage = rMessage & Mid(sMessage, i, 1).Replace("'", "")  '��'�Ÿ����m�����ť�,��javascript�i�H���`���message
                End If
            Next
            Return rMessage
        End Function

    Function trimStr(ByVal objStr As Object) As String
        If objStr Is Nothing Then
            Return ""
        Else
            Return objStr.ToString.Trim()
        End If
    End Function

        Function trimCtlStr(ByVal objStr As Object) As String '�N�ťդίS���r���ư�
            Dim str As String
            Dim strnew As String = ""
            Dim i As Integer

            If objStr Is Nothing Then
                Return ""
            Else
                str = objStr.ToString.Trim

                For i = 0 To str.Length - 1
                    If Not (Asc(str.Substring(i, 1)) >= 0 And Asc(str.Substring(i, 1)) <= 31) Then
                        strnew = strnew + str.Substring(i, 1)
                    End If
                Next

                Return strnew
            End If
        End Function

        Function TrnaInMothFormat(ByVal objStr As Object) As String
            Dim rStr, rStr1 As String
            Dim rStrArr() As String
            If objStr Is Nothing Then
                rStr = ""
            Else
                rStr1 = objStr.ToString.Trim()
                rStrArr = rStr1.Split("/")
                If rStrArr.Length >= 2 Then '���s�զX�����T������榡
                    rStr = rStrArr(0) + "/" + rStrArr(1) + "/01"
                Else '��J������S��/�ŦX�A�L�k�զX
                    rStr = ""
                End If
            End If

            Return rStr
        End Function

    Function GetUserLevel(ByVal UserID As String) As String
        Dim sqllevel As String
        Dim dslevel As DataSet
        Dim userlevel As String

        sqllevel = "SELECT USER_LEVEL FROM FWEB_USER_LOGIN_M WHERE USER_ID ='" + UserID + "'"
        dslevel = db.FillDataSet(sqllevel, 2)
        userlevel = dslevel.Tables(0).Rows(0).Item("USER_LEVEL").ToString
        dslevel.Dispose()
        Return userlevel
    End Function

    '���SessionDataRoot�U��SessionID���|
    Public Function GetSessionDataRoot(ByVal Context As System.Web.HttpContext) As String
        'Dim path As String = "C:\Inetpub\wwwroot\FR\SessionDataRoot\" + Context.Session.SessionID + "\"
        Dim path As String = System.AppDomain.CurrentDomain.BaseDirectory.Replace("/", "\") & "SessionDataRoot\" + Context.Session.SessionID + "\"
        Dim d As New System.IO.DirectoryInfo(path)
        If (d.Exists() = False) Then
            d.Create()
        End If
        Return path
    End Function

    '���SessionDataRoot�U��SessionID���|-FOR Java Script
    Public Function GetJavaSessionDataRoot(ByVal Context As System.Web.HttpContext) As String
        Dim path As String = "SessionDataRoot/" + Context.Session.SessionID + "/"
        'Dim d As New System.IO.DirectoryInfo(path)
        'If (d.Exists() = False) Then
        '    d.Create()
        'End If
        Return path
    End Function

    '�NDataSet��Ƽg�Jxml�ɮשαNxml�ɮ׸��Ū�X��DataSet
    Public Function CacheSessionData(ByVal ConText As System.Web.HttpContext, _
                                     ByVal ds As DataSet, _
                                     ByVal xmlFileName As String, _
                                     ByVal overWrite As Boolean) As Boolean  'overWrite:true�g�Jxml,flaseŪ��xml

        '�N��Ƽg�Jxml�A�Ȧs��w��
        Dim bDataFromSQL As Boolean = False
        Dim path As String = GetSessionDataRoot(ConText) + xmlFileName + ".xml"
        Dim f As System.IO.FileInfo = New System.IO.FileInfo(path)

        If (overWrite = True) Then  '�g�Jxml
            bDataFromSQL = True
            ds.WriteXml(path)
        Else                        'xml�Ȧs�ɦs�b,�~Ū��xml
            If (f.Exists = True) Then
                bDataFromSQL = True
                ds.ReadXml(path)
            End If
        End If

        Return bDataFromSQL
    End Function

    '��o�A�Ⱦ���IP�a�}
        Function ServerIP() As String
            Dim addressList As System.Net.IPAddress() = Dns.GetHostEntry(Dns.GetHostName()).AddressList
            Dim SvrIP As IPAddress = addressList(0)
            Return SvrIP.ToString()
        End Function

    'Delete Files not created today 
    'FileType: *.xls
    Public Sub DeleteFile(ByVal Path As String, ByVal FileType As String)
        Dim intx As Integer
        Dim CreateDate As String
        Dim Files As String()
        Files = System.IO.Directory.GetFiles(Path, FileType)
        For intx = 0 To Files.Length - 1
            CreateDate = System.IO.Directory.GetCreationTime(Files(intx)).ToString("yyyy/MM/dd")
            If (CreateDate <> System.DateTime.Today.ToString("yyyy/MM/dd")) Then
                System.IO.File.Delete(Files(intx))
            End If
        Next
    End Sub

    'Kill Excel Process
    Sub KillProcess(ByVal ProcessName As String, ByVal StartTime As DateTime, ByVal EndTime As DateTime)
        Dim myProcesses As System.Diagnostics.Process()
        Dim ProcessTime As DateTime
        myProcesses = System.Diagnostics.Process.GetProcessesByName(ProcessName)
        Dim myProcess As System.Diagnostics.Process
        For Each myProcess In myProcesses
            ProcessTime = myProcess.StartTime
            If ProcessTime >= StartTime And ProcessTime < EndTime Then
                myProcess.Kill()
            End If
        Next
    End Sub
    '���SessionDataRoot�U��SessionID���|
    Public Function GetSessionDataRoot_Bond(ByVal Context As System.Web.HttpContext) As String
        'Dim path As String = "C:\Inetpub\wwwroot\FR\SessionDataRoot\" + Context.Session.SessionID + "\"
        Dim path As String = System.AppDomain.CurrentDomain.BaseDirectory.Replace("/", "\") & "SessionDataRoot\" + Context.Session.SessionID + "\"
        Dim d As New System.IO.DirectoryInfo(path)
        If (d.Exists() = False) Then
            d.Create()
        End If
        Return path
    End Function

    '���SessionDataRoot�U��SessionID���|-FOR Java Script
    Public Function GetJavaSessionDataRoot_Bond(ByVal Context As System.Web.HttpContext) As String
        Dim path As String = "SessionDataRoot/" + Context.Session.SessionID + "/"
        'Dim d As New System.IO.DirectoryInfo(path)
        'If (d.Exists() = False) Then
        '    d.Create()
        'End If
        Return path
    End Function

    '�NDataSet��Ƽg�Jxml�ɮשαNxml�ɮ׸��Ū�X��DataSet
    Public Function CacheSessionData_Bond(ByVal ConText As System.Web.HttpContext, _
                                     ByVal ds As DataSet, _
                                     ByVal xmlFileName As String, _
                                     ByVal overWrite As Boolean) As Boolean  'overWrite:true�g�Jxml,flaseŪ��xml

        '�N��Ƽg�Jxml�A�Ȧs��w��
        Dim bDataFromSQL As Boolean = False
        Dim path As String = GetSessionDataRoot(ConText) + xmlFileName + ".xml"
        Dim f As System.IO.FileInfo = New System.IO.FileInfo(path)

        If (overWrite = True) Then  '�g�Jxml
            bDataFromSQL = True
            ds.WriteXml(path)
        Else                        'xml�Ȧs�ɦs�b,�~Ū��xml
            If (f.Exists = True) Then
                bDataFromSQL = True
                ds.ReadXml(path)
            End If
        End If

        Return bDataFromSQL
    End Function

        Sub GetddlDownList(ByVal SQL As String, ByVal TempddlDown As DropDownList, ByVal StrConnect As String)
               Dim TempDS As New DataSet
               Dim success As Boolean = False
               Dim IntFlag As Integer = 1
               Try
                   Select Case StrConnect
                          Case "NCST1"
                               IntFlag = 1
                          Case "NCST2"
                               IntFlag = 2
                   End Select

                      TempDS = db.FillDataSet(SQL, IntFlag)

                      TempddlDown.Items.Clear()
                      If TempDS.Tables(0).Rows.Count > 0 Then
                          With TempddlDown
                              .DataSource = TempDS.Tables(0).DefaultView
                              .DataTextField = "NAME" ' display screen
                              .DataValueField = "ID"  'Hide 
                              .DataBind()
                              .Items.Insert(0, "")
                          End With
                      Else
                          With TempddlDown
                              .Items.Insert(0, "")
                              '.Items.Clear()
                          End With
                      End If
                      TempDS.Dispose()
               Catch ex As Exception
                   Throw ex
               Finally
                   If Not TempDS Is Nothing Then
                       TempDS.Dispose()
                   End If
               End Try
        End Sub

        Public Sub Alert(ByVal Message As String, ByRef Page As Page)

            Dim current As HttpContext = HttpContext.Current
            Dim startScript As String = ""

            'Replace problem chars in the message
            Message = Replace(Message, vbCr, " ")
            Message = Replace(Message, vbLf, " ")
            Message = Replace(Message, vbCrLf, " ")
            Message = Replace(Message, Chr(34), "*")

            startScript &= "<script language='javascript'>alert('" & Message & "');</script>"

            If (Not Page.ClientScript.IsStartupScriptRegistered("alert")) Then
                Page.ClientScript.RegisterStartupScript(GetType(Object), "alert", startScript)
            End If

        End Sub

        '�վ������m
        Public Sub Window_MoveTo(ByVal x As Double, ByVal y As Double, ByVal page As Page)


            page.ClientScript.RegisterClientScriptBlock(GetType(Object), "move", "<script defer>window.moveTo(" + x + "," + y + ");</script>")
        End Sub


        '�վ�����j�p
        Public Sub Window_ResizeTo(ByVal x As Double, ByVal y As Double, ByVal page As Page)
            If x = 0 And y = 0 Then
                page.ClientScript.RegisterClientScriptBlock(GetType(Object), "resize", "<script>window.resizeTo(screen.weight,screen.height);</script>")
            Else
                page.ClientScript.RegisterClientScriptBlock(GetType(Object), "resize", "<script>window.resizeTo(" + x + "," + y + ");</script>")
            End If


        End Sub

End Module

End Namespace
