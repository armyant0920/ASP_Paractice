Namespace FR

Public Module common
        Function showdialog(ByVal url As String, ByVal width As Integer, ByVal height As Integer) As String

            'Return String.Format("window.showModalDialog('{0}',window,'dialogWidth={1}px;dialogHeight={2}px;help:no;edge:sunken;status:yes;resizable:yes;unadorned:yes');", url, width.ToString, height.ToString)


            Return String.Format("window.open('{0}','_blank','width={1}px,height={2}px,resizable=yes,locations=yes')", url, width, height)

            'window.open('FWEB_FIND_PROD_2.aspx?type=a','_blank','width=640px,height=480px');
            'showModalDialog�ܦh�s�����w�g���䴩
            'toolbar �u��C�O�_���
            'resizable �O�_�վ�j�p
            'menubar
            'status 
            'locations �O�_��ܺ��}�C
            'status
            'left px
            'top px




        End Function
End Module

End Namespace
