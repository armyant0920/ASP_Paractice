Namespace FR

Public Class CSExportCSV

    Private _ArrayColName() As String
    Private _ArrayCol() As String
    Private _ArrayColType() As ColTypeEnum

    Public Enum ColTypeEnum
        Str = 0  'string���O
        Obj = 1  '��ӫ��O
    End Enum

    Sub New()
        InitialValue()
    End Sub

#Region "InitialValue:��l���ܼ�"
    Sub InitialValue()
        ReDim _ArrayColName(1)
        _ArrayColName(0) = ""
        ReDim _ArrayCol(1)
        _ArrayCol(0) = ""
        ReDim _ArrayColType(1)
        _ArrayColType(0) = ColTypeEnum.Obj
    End Sub
#End Region

        Function DataTableToCSV(ByVal dt As Data.DataTable, ByVal FileName As String, ByVal SavePath As String, Optional ByVal ChoseCol As Boolean = False) As Boolean
            Dim sw As System.IO.StreamWriter = Nothing
            Dim FilePath As String = "" '= SavePath + FileName
            Dim xlsrow, csvCount As Integer
            Dim vColData As String
            Dim ascii As Integer

            Try

                '�P�_USER���L�]�w��ƫ��O,�L�h�۰ʳ]�w����l���O
                If ChoseCol = True Then
                    AutoSetColType(_ArrayCol.Length)
                Else
                    AutoSetColType(dt.Columns.Count)
                End If

                xlsrow = 0    '�C��csv�ɮת��C��
                csvCount = 1  'csv�ɮת��Ӽ�,�W�L60000���h���t�@���ɮ�
                For i As Integer = 0 To dt.Rows.Count - 1

                    If xlsrow = 0 Then

                        FilePath = SavePath + FileName + "_" + csvCount.ToString + ".csv"
                        sw = New System.IO.StreamWriter(FilePath, False, System.Text.Encoding.GetEncoding("Big5"))

                        '���W��
                        For j As Integer = 0 To _ArrayColName.Length - 1
                            sw.Write(_ArrayColName(j))
                            sw.Write(",")
                        Next
                        sw.WriteLine()

                        csvCount = csvCount + 1
                    End If

                    xlsrow = xlsrow + 1

                    '��Ƥ��e
                    For j As Integer = 0 To _ArrayCol.Length - 1

                        If _ArrayColType(j) = ColTypeEnum.Str Then   '��r�榡

                            vColData = ""
                            '�N�S���r������,�H�K��Xxls�|����
                            For Each vChar As Char In dt.Rows(i)(_ArrayCol(j)).ToString.Replace(" ", "-").Replace(",", "-").ToCharArray
                                ascii = Convert.ToInt32(vChar)
                                If ascii >= 32 Then
                                    vColData = vColData + vChar
                                End If
                            Next

                            sw.Write(Chr(27) & vColData)

                        Else   '��ӫ��O

                            sw.Write(dt.Rows(i).Item(_ArrayCol(j)))

                        End If

                        sw.Write(",")
                    Next
                    sw.WriteLine()

                    '�W�L60000����ƴ��t�@���ɮ�
                    If xlsrow >= 60000 Then
                        xlsrow = 0
                        sw.Close()
                    End If
                Next

                sw.Close()

            Catch ex As Exception
                Throw ex
            End Try

            If System.IO.File.Exists(FilePath) Then
                Return True
            Else
                Return False
            End If

        End Function

#Region "SetDisplayColName:�]�w�n��ܪ����W��"
    Sub SetDisplayColName(ByVal ParamArray ColArray() As String)
        ReDim _ArrayColName(ColArray.Length)
        _ArrayColName = ColArray
    End Sub
#End Region

#Region "SetDisplayCol:�]�w�n��ܪ�������"
    Sub SetDisplayCol(ByVal ParamArray ColArray() As String)
        ReDim _ArrayCol(ColArray.Length)
        _ArrayCol = ColArray
    End Sub
#End Region

#Region "SetDisplayColType:�]�w�n��ܪ���ƫ��O"
    Sub SetDisplayColType(ByVal ParamArray ColArray() As ColTypeEnum)
        ReDim _ArrayColType(ColArray.Length)
        _ArrayColType = ColArray
    End Sub
#End Region

#Region "AutoSetColType:�۰ʳ]�w��ƫ��O"
    Private Sub AutoSetColType(ByVal ColLength As Integer)
        'USER�S���]�w��ƫ��O,��Sub�N�|�۰ʳ]�w��ƫ��A����l��ƫ��O
        Dim i As Integer
        If _ArrayColType.Length <> ColLength Then
            ReDim _ArrayColType(ColLength)
            For i = 0 To ColLength - 1
                _ArrayColType(i) = ColTypeEnum.Obj
            Next
        End If
    End Sub
#End Region

End Class

End Namespace
