﻿'Imports Microsoft.VisualBasic

'Public Class SQLInjectHelper

'    Dim Valid As Boolean


'    Function ValidData(ByVal input As String) As Boolean

'        If Regex.IsMatch(input, RegText()) Then
'            re()

'        End If

'    End Function

'    Function RegText(ByVal input As String) As Boolean
'        Dim bad = New String() {"and", "exec", "insert", "select", "delete", "update", "or", "%", "-", ";", ","}
'        Str()
'        String str_reg=".*(";
'        For (Int i=0;i<bad.length;i++){
'            }




'    End Function


'End Class
