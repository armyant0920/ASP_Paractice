Imports System.Runtime.InteropServices
Imports System.IO


Namespace FR


    Public Class CSPrintExcel
        Dim oExcel As New Excel.Application
        Dim oBooks As Excel.Workbooks
        Dim oBook As Excel.Workbook
        Dim oSheets As Excel.Sheets
        Dim oSheet As Excel.Worksheet
        Dim oCells As Excel.Range
        Private _SheetNo As Integer
        Private _ArrayColName() As String
        Private _ArrayCol() As String
        Private _ArrayColType() As ColTypeEnum

        Public Enum ColTypeEnum
            Str = 0  'string���O
            Obj = 1  '��l���O
        End Enum

        Sub New()
            InitialValue()
        End Sub


#Region "InitialValue:��l���ܼ�"
        Sub InitialValue()
            _SheetNo = 1
            ReDim _ArrayColName(1)
            _ArrayColName(0) = ""
            ReDim _ArrayCol(1)
            _ArrayCol(0) = ""
            ReDim _ArrayColType(1)
            _ArrayColType(0) = ColTypeEnum.Obj
        End Sub
#End Region

#Region "CreateExcel:�w�q�@�ӷs���u�@ï"
        Sub CreateExcel()
            oExcel = New Excel.Application

            oBooks = oExcel.Workbooks
            oBook = oBooks.Add

            oSheets = oBook.Worksheets
        End Sub
#End Region

#Region "SheetNo:���w�u�@��"
        Public Property SheetNo() As Integer
            Get
                Return _SheetNo
            End Get
            Set(ByVal value As Integer)
                _SheetNo = value
                SetActiveSheet()
            End Set
        End Property
#End Region

#Region "SetActiveSheet:�]�w�ثe�u�@��"
        Sub SetActiveSheet()
            oSheet = oSheets.Item(_SheetNo)
            oSheet.Activate()
            oCells = oSheet.Cells
        End Sub
#End Region

#Region "PutExcelData:�N��Ʃ�JExcel"

        Sub PutExcelData(ByVal dt As DataTable, ByVal row As Integer, ByVal col As Integer, Optional ByVal PrtHeadCol As Boolean = True, Optional ByVal ChoseCol As Boolean = False)
            Dim i, j As Integer
            Dim vRow, vCol As Integer

            '�P�_USER���L�]�w��ƫ��O,�L�h�۰ʳ]�w����l���O
            If ChoseCol = True Then
                AutoSetColType(_ArrayCol.Length)
            Else
                AutoSetColType(dt.Columns.Count)
            End If

            '�]�w�ثe�u�@��
            oSheet = oSheets.Item(_SheetNo)
            oSheet.Activate()
            oCells = oSheet.Cells

            '�]�w��l�C
            vRow = row

            '�L���Y-���W��
            If PrtHeadCol = True Then
                '��user��SetColName���]�w��������
                If ChoseCol = True Then
                    vCol = col
                    For j = 0 To _ArrayColName.Length - 1
                        oCells(vRow, vCol) = _ArrayColName(j)
                        vCol = vCol + 1
                    Next
                End If
                '�������
                If ChoseCol = False Then
                    vCol = col
                    For i = 0 To dt.Columns.Count - 1
                        oCells(vRow, vCol) = dt.Columns(i).ColumnName
                        vCol = vCol + 1
                    Next
                End If
                vRow = vRow + 1
            End If

            '�L����-��Ƥ��e      
            If ChoseCol = True Then
                '��user��SetCol���]�w�������� '��user��SetCol���]�w�������� 
                For i = 0 To dt.Rows.Count - 1
                    vCol = col
                    For j = 0 To _ArrayCol.Length - 1
                        SetExcelFormate(vRow, vCol, _ArrayColType(j))
                        oCells(vRow, vCol) = dt.Rows(i).Item(_ArrayCol(j))
                        vCol = vCol + 1
                    Next
                    vRow = vRow + 1
                Next
            ElseIf ChoseCol = False Then
                '�������
                For i = 0 To dt.Rows.Count - 1
                    vCol = col
                    For j = 0 To dt.Columns.Count - 1
                        SetExcelFormate(vRow, vCol, _ArrayColType(j))
                        oCells(vRow, vCol) = dt.Rows(i)(j)
                        vCol = vCol + 1
                    Next
                    vRow = vRow + 1
                Next
            End If

        End Sub
#End Region

#Region "AutoSetColType:�۰ʳ]�w��ƫ��O"
        Private Sub AutoSetColType(ByVal ColLength As Integer)
            'USER�S���]�w��ƫ��O,��Sub�N�|�۰ʳ]�w��ƫ��A����l��ƫ��O
            Dim i As Integer
            If _ArrayColType.Length <> ColLength Then
                ReDim _ArrayColType(ColLength)
                For i = 0 To ColLength - 1
                    _ArrayColType(i) = ColTypeEnum.Obj
                Next
            End If
        End Sub
#End Region

#Region "SetExcelFormate:�]�w�x�s���ƫ��O"
        Sub SetExcelFormate(ByVal row As Integer, ByVal col As Integer, ByVal vDataType As ColTypeEnum)
            Dim oRange As Excel.Range
            Dim oCellx As Excel.Range

            oRange = oSheet.Cells
            oCellx = oRange.Item(row, col)

            '�]����r�榡
            If vDataType = ColTypeEnum.Str Then
                oCellx.NumberFormatLocal = "@"
            End If

            ReleaseExcelObject(oCellx)
            ReleaseExcelObject(oRange)
        End Sub
#End Region

#Region "PutCellData:��J��ƨ���w���x�s��"
        Sub PutCellData(ByVal row As Integer, ByVal col As Integer, ByVal ColData As Object, Optional ByVal ColType As ColTypeEnum = ColTypeEnum.Obj)
            If ColType = ColTypeEnum.Str Then      '�N��ƥH��r�榡��J
                oCells(row, col) = "'" + ColData
            ElseIf ColType = ColTypeEnum.Obj Then  '�̸�ƭ�Ӯ榡��J
                oCells(row, col) = ColData
            End If
        End Sub
#End Region

#Region "SetDisplayColName:�]�w�n��ܪ����W��"
        Sub SetDisplayColName(ByVal ParamArray ColArray() As String)
            ReDim _ArrayColName(ColArray.Length)
            _ArrayColName = ColArray
        End Sub
#End Region

#Region "SetDisplayCol:�]�w�n��ܪ�������"
        Sub SetDisplayCol(ByVal ParamArray ColArray() As String)
            ReDim _ArrayCol(ColArray.Length)
            _ArrayCol = ColArray
        End Sub
#End Region

#Region "SetDisplayColType:�]�w�n��ܪ���ƫ��O"
        Sub SetDisplayColType(ByVal ParamArray ColArray() As ColTypeEnum)
            ReDim _ArrayColType(ColArray.Length)
            _ArrayColType = ColArray
        End Sub
#End Region

#Region "SaveExcel:�NExcel�s��"
        Sub SaveExcel(ByVal savepath As String)
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oBook.SaveAs(savepath)
            oBooks.Close()
        End Sub
#End Region

#Region "ReleaseExcel:����Excel�귽"
        Sub ReleaseExcel()
            Try
                oExcel.Quit()
                ReleaseExcelObject(oCells)
                ReleaseExcelObject(oSheet)
                ReleaseExcelObject(oSheets)
                ReleaseExcelObject(oBook)
                ReleaseExcelObject(oBooks)
                ReleaseExcelObject(oExcel)
            Catch ex As Exception
                Throw ex
            Finally
                GC.Collect()
            End Try
        End Sub
#End Region

#Region "ReleaseExcelObject:������XExcel�Ψ쪺����"
        Sub ReleaseExcelObject(ByVal o As Object)
            Try
                If Not o Is Nothing Then
                    Marshal.ReleaseComObject(o)
                End If
            Finally
                o = Nothing
            End Try
        End Sub
#End Region

    End Class

End Namespace
