Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math


Namespace FR

Partial Class FWEB_ONL_ONHAND
    Inherits System.Web.UI.Page
        Protected WithEvents Aspnetpager1 As Wuqi.Webdiyer.AspNetPager
    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txt_org_no.Value <> "" Then
            loadcost_name()
            Me.dd_cost_name.Value = Me.txt_cost_no.Value
        End If
        If Not Page.IsPostBack Then
            btn_state(0)
            listyd()
            sysdate()
            loadorg()
            Me.dd_org_name.Value = Me.txt_org_no.Value
            loadcost_name()
            btn1.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_PROD_2.aspx?type=a", 640, 480))
            text11.Disabled = True
        End If
    End Sub

    Sub loadorg()
        Dim sqlstr As String
        Dim TempDS As New DataSet
        Try
           sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                    " WHERE A.ORG = B.ORG AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                    " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
           TempDS = db.FillDataSet(sqlstr, 2)
           dd_org_name.DataSource = TempDS.Tables(0)
           dd_org_name.DataValueField = "�s�X"
           dd_org_name.DataTextField = "�W��"
           dd_org_name.DataBind()
           dd_org_name.Items.Insert(0, "")
        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try

    End Sub

    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then
            btnInq.Enabled = True
            Btn2_add.Enabled = True
            btn3_save.Enabled = False
            btn4_abo.Enabled = False
            btn5_excel.Enabled = False
            btn6_tran.Enabled = True
            btn7_form.Enabled = True
            btn8_excel.Enabled = True
        ElseIf intnum = 1 Then
            btnInq.Enabled = True
            Btn2_add.Enabled = True
            btn3_save.Enabled = False
            btn4_abo.Enabled = False
            btn5_excel.Enabled = True
            btn6_tran.Enabled = True
            btn7_form.Enabled = True
            btn8_excel.Enabled = False
        ElseIf intnum = 2 Then
            btnInq.Enabled = False
            Btn2_add.Enabled = False
            btn3_save.Enabled = True
            btn4_abo.Enabled = True
            btn5_excel.Enabled = False
            btn6_tran.Enabled = False
            btn7_form.Enabled = False
            btn8_excel.Enabled = False
        ElseIf intnum = 3 Then
            btnInq.Enabled = True
            Btn2_add.Enabled = True
            btn3_save.Enabled = False
            btn4_abo.Enabled = False
            btn5_excel.Enabled = True
            btn6_tran.Enabled = True
            btn7_form.Enabled = True
            btn8_excel.Enabled = True
        End If
    End Sub

    Sub listyd()
        Dim sqlstr As String
        Dim TempDS As New DataSet
        Try

           sqlstr = "SELECT DISTINCT TRANSACTION_TYPE �������O FROM FWEB_ONL_TRANSACTION_TYPE"
           TempDS = db.FillDataSet(sqlstr, 2)
           dd_list_yd.DataSource = TempDS.Tables(0)
           dd_list_yd.DataTextField = "�������O"
           dd_list_yd.DataBind()
           dd_list_yd.Items.Insert(0, "")

        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try
    End Sub
    Sub textbox_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�s�W���A  
            txt_org_no.Disabled = False
            txt_org_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_org_name.Disabled = False
            dd_org_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
            txt_cost_no.Disabled = False
            txt_cost_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_cost_name.Disabled = False
            dd_cost_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Text1.Disabled = False
            Text1.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_list_yd.Disabled = False
            dd_list_yd.Style.Add("BACKGROUND-COLOR", "lightcyan")
            text11.Disabled = False
            text11.Style.Add("BACKGROUND-COLOR", "lightcyan")
            txtBonded_now_onhand.Disabled = False
            txtBonded_now_onhand.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_select_on.Enabled = False
            dg.Columns(0).Visible = False
            dg.Columns(1).Visible = False
        ElseIf intnum = 1 Then                 '�s�説�A 
            txt_org_no.Disabled = True
            dd_org_name.Disabled = True
            txt_cost_no.Disabled = True
            '   txt_cost_no.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_cost_name.Disabled = True
            ' dd_cost_name.Style.Add("BACKGROUND-COLOR", "lightcyan")
            Text1.Disabled = True
            dd_list_yd.Disabled = True
            text11.Disabled = False
            text11.Style.Add("BACKGROUND-COLOR", "lightcyan")
            txtBonded_now_onhand.Disabled = False
            txtBonded_now_onhand.Style.Add("BACKGROUND-COLOR", "lightcyan")
            dd_select_on.Enabled = False
            dg.Columns(0).Visible = True
            dg.Columns(1).Visible = True
        Else                                   '��L���A
            txt_org_no.Disabled = False
            txt_org_no.Style.Add("BACKGROUND-COLOR", "beige")
            dd_org_name.Disabled = False
            dd_org_name.Style.Add("BACKGROUND-COLOR", "white")
            txt_cost_no.Disabled = False
            txt_cost_no.Style.Add("BACKGROUND-COLOR", "beige")
            dd_cost_name.Disabled = False
            dd_cost_name.Style.Add("BACKGROUND-COLOR", "white")
            Text1.Disabled = False
            Text1.Style.Add("BACKGROUND-COLOR", "white")
            dd_list_yd.Disabled = False
            dd_list_yd.Style.Add("BACKGROUND-COLOR", "white")
            text11.Disabled = False
            text11.Style.Add("BACKGROUND-COLOR", "white")
            txtBonded_now_onhand.Disabled = False
            txtBonded_now_onhand.Style.Add("BACKGROUND-COLOR", "white")
            dd_select_on.Enabled = True
            dg.Columns(0).Visible = True
            dg.Columns(1).Visible = True
        End If
    End Sub

    Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
        Label1.Text = "1"
        If check_data() = False Then
            Exit Sub
        End If
            Dim strsql As String = ""
        Dim longstr As String
        Dim tiaojian As String
            Dim strsql4 As String = ""
        tiaojian = " T.ORG = M.ORG AND T.COST_CENTER=M.COST_CENTER and T.PERIOD_NAME=to_date('" + edtDateFrom.Value + "','yyyy/MM/dd') and T.ORG = '" + txt_org_no.Value + "' AND T.COST_CENTER LIKE '%" + txt_cost_no.Value + "%'" & _
                   " AND T.PRODUCT_NUM LIKE '%" + Text1.Value.ToUpper.Trim + "%' and T.TRANSACTION_TYPE like '%" + dd_list_yd.Value.Trim + "%'"
        longstr = " select to_char(T.PERIOD_NAME,'yyyy/MM/dd') as PERIOD_NAME,T.ORG,t.TRANSACTION_TYPE,T.COST_CENTER,M.COST_CENTER_NAME,T.BONDED_FLAG,T.PRODUCT_NUM,t.PRODUCT_DESC,T.UOM,T.PRE_ONHAND," & _
                 " T.NOW_WASTE,T.NOW_ONHAND,T.BONDED_NOW_ONHAND,T.CHECK_ONHAND,T.REMARK,T.IMPORT_MARK,to_char(T.IMPORT_DATE,'yyyy/mm/dd') as IMPORT_DATE," & _
                 " T.IMPORT_USER,T.APPROVE_MARK,to_char(T.APPROVE_DATE,'yyyy/mm/dd') as APPROVE_DATE ," & _
                 " T.APPROVE_USER,to_char(T.MDATE,'yyyy/mm/dd') as MDATE ,T.MUSER,to_char(T.CDATE,'yyyy/mm/dd') as CDATE,T.CUSER" & _
                 " from FWEB_ONL_ONHAND T,FWEB_COST_CENTER_V M where " & tiaojian
        'viewstate("tiaojian") = tiaojian
        Dim strsql5 As String = "select count(*) from FWEB_ONL_ONHAND T,FWEB_COST_CENTER_V M where " & tiaojian
        If dd_select_on.SelectedItem.Text = "Y" Then
            strsql = longstr & " and T.CHECK_ONHAND < 0 "
            strsql4 = strsql5 & " and T.CHECK_ONHAND < 0 "
        End If
        If dd_select_on.SelectedItem.Text = "N" Then
            strsql = longstr & " and (T.CHECK_ONHAND >= 0 or t.check_onhand is null)"
            strsql4 = strsql5 & " and T.CHECK_ONHAND >= 0 "
        End If
        If dd_select_on.SelectedItem.Text = "" Then
            strsql = longstr
            strsql4 = strsql5
        End If
        viewstate("strsql4") = strsql4
        viewstate("strsql") = strsql
        dg.CurrentPageIndex = 0
        loaddata(viewstate("strsql"))
        btn_state(3)
        textbox_state(2)

    End Sub

        Sub sysdate()
            Dim ds As New DataSet
            Try
               Dim sqlstr As String
               sqlstr = "SELECT A.ORG,A.PERIOD_MOTH FROM FWEB_ONL_CALENDAR A,(SELECT T.ORG FROM FWEB_USER_ORGAU_D O, FWEB_ONL_DEPT T" & _
                    " WHERE O.USER_ID = '" + Context.User.Identity.Name + "' AND O.SYST_NO = 'FWEB' AND O.PROJ_NO = 'ONL' AND DECODE(O.ORG, 'ALL', T.ORG, O.ORG) = T.ORG " & _
                    " AND DECODE(O.COST_CENTER, 'ALL', T.COST_CENTER, O.COST_CENTER) = T.COST_CENTER AND ROWNUM = 1) B " & _
                    " WHERE A.ORG = B.ORG AND A.CLOSE_DATE IS NULL "
               ds = db.FillDataSet(sqlstr, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   txt_org_no.Value = ds.Tables(0).Rows(0).Item("ORG")
                   edtDateFrom.Value = ds.Tables(0).Rows(0).Item("PERIOD_MOTH")
               End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
        End Sub

        Sub loaddata(ByVal strsql As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            Try
               If strsql <> "" Then
                   ds = db.FillDataSet(strsql, 2)
                   dv = ds.Tables(0).DefaultView
                   dg.DataSource = dv
                   dg.DataBind()
               End If
               GetPageInfo()
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
               If Not dv Is Nothing Then
                  dv.Dispose()
               End If
               If Not ds Is Nothing Then
                  ds.Dispose()
               End If
            End Try
        End Sub

    Sub GetPageInfo()
        Dim strsql1 As String = db.GetExecuteScalar(viewstate("strsql4")).ToString
        Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
    End Sub

    Private Sub Aspnetpager1_PageChanged(ByVal src As System.Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs) Handles Aspnetpager1.PageChanged
        dg.CurrentPageIndex = 0
        dg.CurrentPageIndex = e.NewPageIndex - 1
        Aspnetpager1.CurrentPageIndex = e.NewPageIndex
        loaddata(viewstate("strsql"))
    End Sub

    Private Sub BN_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        btn_state(1)
        cleartext(0)
        'textbox_state(0)
    End Sub

    Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
            'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
        If e.CommandName = "delete" Then
            If e.Item.Cells(17).Text <> "Y" Then
                Try
                    Dim strsql As String
                    strsql = "delete from FWEB_ONL_ONHAND  T where T.PERIOD_NAME = to_date('" + e.Item.Cells(2).Text.Trim.Substring(0, 10) + "', 'yyyy-MM-dd')" & _
                             " and T.ORG = '" + e.Item.Cells(3).Text.Trim + "' and t.TRANSACTION_TYPE='" + e.Item.Cells(4).Text.Trim + "'" & _
                             " and  T.COST_CENTER = '" + e.Item.Cells(5).Text.Trim + "' and T.PRODUCT_NUM = '" + e.Item.Cells(8).Text.Trim + "'"

                    db.ExecuteSQL(strsql)
                Catch ex As Exception
                    Throw ex
                Finally
                    If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
                        dg.CurrentPageIndex -= 1
                        loaddata(viewstate("strsql"))
                    Else
                        loaddata(viewstate("strsql"))
                    End If
                End Try
                btn_state(1)
            Else
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�w�g�ߪ���,���i�R��');</script>")
                    Exit Sub
                End If

            ElseIf e.CommandName = "edit" Then
                Label2.Text = "2"
                If e.Item.Cells(17).Text <> "Y" Then
                Else
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�w�g�ߪ���,���i�ק�');</script>")
                    Exit Sub
                End If
                Dim b As Array = Split(e.Item.Cells(2).Text.Trim, " ")
                edtDateFrom.Value = b(0)
                txt_org_no.Value = e.Item.Cells(3).Text.Trim
                dd_org_name.Value = e.Item.Cells(3).Text.Trim 'e.Item.Cells(3).Text.Trim
                dd_list_yd.Value = e.Item.Cells(4).Text.Trim
                loadcost_name()
                txt_cost_no.Value = e.Item.Cells(5).Text.Trim
                dd_cost_name.Value = e.Item.Cells(5).Text.Trim 'e.Item.Cells(5).Text.Trim
                Text1.Value = e.Item.Cells(8).Text.Trim
                text11.Value = e.Item.Cells(13).Text.Trim
                txtBonded_now_onhand.Value = e.Item.Cells(14).Text.Trim
                hanshu()
                Text2.Value = Label4.Text
                Text3.Value = Label5.Text
                btn_state(2)
                textbox_state(1)
            End If
        End Sub

        Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
            btn_state(0)
            cleartext(0)
        End Sub

        Function check_data() As Boolean
            Dim inti As Int16 = 0
            If txt_org_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
                Return False
            End If
            If txt_org_no.Value <> "" Then
                'CHECK�O�_���u�W���s�L�I���t�O
                Dim strsql1 As String = "SELECT COUNT(*) FROM FWEB_ONL_DEPT where org='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���t�O�D�u�W���s�L�I���t�O�A��CHECK! �Y���s�W���L�I���t�O�A�гq���]�ȼW�[!');</script>")
                End If
                'CHECK�O�_���t�O�v��
                Dim strsql2 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                        "AND PROJ_NO = 'ONL' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���]�ȼW�[!');</script>")
                End If

                If txt_cost_no.Value <> "" Then
                    'CHECK�O�_���u�W���s�L�I����������
                    Dim strsql3 As String = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG ='" + txt_org_no.Value.Trim + "' AND COST_CENTER = '" + txt_cost_no.Value.Trim + "'"
                    If db.GetExecuteScalar(strsql3) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                    End If
                    'CHECK�O�_�����������v��
                    Dim strsql4 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                            "AND PROJ_NO = 'ONL' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "' " & _
                                            "AND DECODE(COST_CENTER,'ALL','" + txt_cost_no.Value.Trim + "',COST_CENTER)='" + txt_cost_no.Value.Trim + "' "
                    If db.GetExecuteScalar(strsql4) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                    End If
                End If
            End If
            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Sub cleartext(ByVal intstate As Int16)
            If intstate = 0 Then                     '�D�d�ߪ��A
                txt_org_no.Value = ""
                dd_org_name.SelectedIndex = -1
                txt_cost_no.Value = ""
                dd_cost_name.SelectedIndex = -1
                dd_list_yd.SelectedIndex = -1
                dd_select_on.SelectedIndex = -1
                dd_list_yd.Value = ""
                Text1.Value = ""
                text11.Value = ""
                Text2.Value = ""
                Text3.Value = ""
                txtBonded_now_onhand.Value = ""
            Else                                   '�d�ߪ��A
                'txtdate.Value = ""
                'TextBox4.Text = ""
                'Text2.Value = ""
                'Textbox1.Text = ""
                'Text3.Value = ""
                'Textbox2.Text = ""
            End If
        End Sub

        Sub load_now_waste()
            Dim strsql As String
            strsql = "select FWEB_ONL_WASTEQTY('" + txt_org_no.Value + "',to_date('" + edtDateFrom.Value + "','yyyy/MM'),'" + txt_cost_no.Value + "','" + Text1.Value + "') " & _
                    " from dual "
            If Not IsDBNull(db.GetExecuteScalar(strsql)) Then
                'TextBox4.Text = db.GetExecuteScalar(strsql)
            Else
                'TextBox4.Text = 0
            End If
        End Sub
        Private Sub Btn2_add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn2_add.Click
            If Label1.Text <> "1" Then
                Label1.Text = "2"
            End If
            Label2.Text = "1"
            btn_state(2)
            cleartext(0)
            textbox_state(0)
        End Sub

        Private Sub btn3_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3_save.Click
            Dim strsql As String
            If Label2.Text = "1" Then
                If check_data2() = False Then
                    Exit Sub
                End If
                hanshu()
                Try
                    If text11.Value = "" Then
                        text11.Value = "0"
                    End If
                    If txtBonded_now_onhand.Value = "" Then
                        txtBonded_now_onhand.Value = "0"
                    End If
                    If txt_cost_no.Value <> "" Then
                        Dim strsql2 As String = "SELECT COST_CENTER FROM FWEB_ONL_DEPT WHERE cost_center ='" + txt_cost_no.Value.Trim + "'"
                        If db.GetExecuteScalar(strsql2) = 0 Then
                            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                            Exit Sub
                        End If
                    End If
                    Label8.Text = (CDec(Label4.Text) + CDec(Label5.Text) - CDec(text11.Value.Trim)).ToString
                    strsql = String.Format(" insert into  FWEB_ONL_ONHAND (PERIOD_NAME,ORG,COST_CENTER,PRODUCT_NUM,TRANSACTION_TYPE,NOW_ONHAND,UOM,PRODUCT_DESC,PRE_ONHAND,NOW_WASTE,CDATE,CUSER,CHECK_ONHAND,BONDED_FLAG,BONDED_NOW_ONHAND ) " & _
                     " values (to_date('{0}','yyyy/MM/dd'),'{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}',sysdate,'{10}','{11}','{12}','{13}')", _
                     edtDateFrom.Value.Trim, txt_org_no.Value.Trim, txt_cost_no.Value.Trim, Text1.Value.Trim, _
                    dd_list_yd.Value.Trim, text11.Value.Trim, Label6.Text.Trim, Label10.Text.Trim, Label4.Text.Trim, Label5.Text.Trim, Context.User.Identity.Name, Label8.Text, lbl_bonded_flag.Text, txtBonded_now_onhand.Value)
                    db.ExecuteSQL(strsql)
                Catch ex As Exception
                    Throw ex
                    Exit Sub
                End Try
                If Label1.Text = "1" Then
                    loaddata(viewstate("strsql"))
                End If
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�x�s���\!');</script>")
            ElseIf Label2.Text = "2" Then
                'Dim ds As New DataSet
                'Dim P_ORG_1 As String = txt_org_no.Value.Trim
                'Dim P_MOTH_1 As String = edtDateFrom.Value.Trim
                'Dim P_TRANSACTION_TYPE_1 As String = dd_list_yd.SelectedItem.Text.Trim
                'Dim P_COST_CENTER_1 As String = txt_cost_no.Value.Trim
                'Dim P_PRODUCT_NUM_1 As String = Text1.Value.Trim
                'Dim strsql1 As String = "select FWEB_ONL_PREONHAND('" & P_ORG_1 & "',to_date('" & P_MOTH_1 & "','yyyy/MM/dd'),'" & P_TRANSACTION_TYPE_1 & "','" & P_COST_CENTER_1 & "','" & P_PRODUCT_NUM_1 & "')PREONHAND from dual"
                'ds = db.FillDataSet(strsql1)
                'If ds.Tables(0).Rows.Count <> 0 Then
                '    If Not IsDBNull(ds.Tables(0).Rows(0).Item("PREONHAND")) Then
                '        Label4.Text = ds.Tables(0).Rows(0).Item("PREONHAND")
                '    Else
                '        Label4.Text = "0"
                '    End If
                'Else
                '    Label4.Text = "0"
                'End If
                'Dim strsql2 As String = "select FWEB_ONL_WASTEQTY('" & P_ORG_1 & "',to_date('" & P_MOTH_1 & "','yyyy-MM-dd'),'" & P_TRANSACTION_TYPE_1 & "','" & P_COST_CENTER_1 & "','" & P_PRODUCT_NUM_1 & "')WASTEQTY from dual"
                'ds = db.FillDataSet(strsql2)
                'If ds.Tables(0).Rows.Count <> 0 Then
                '    If Not IsDBNull(ds.Tables(0).Rows(0).Item("WASTEQTY")) Then
                '        Label5.Text = ds.Tables(0).Rows(0).Item("WASTEQTY")
                '    Else
                '        Label5.Text = "0"
                '    End If
                'Else
                '    Label5.Text = "0"
                'End If
                hanshu()
                Dim strsql3 As String
                Try
                    Label8.Text = (CDec(Label4.Text) + CDec(Label5.Text) - CDec(text11.Value)).ToString
                    strsql3 = String.Format("update FWEB_ONL_ONHAND set PRE_ONHAND='{0}', NOW_ONHAND='{1}',NOW_WASTE='{2}',CHECK_ONHAND='{3}',MDATE=sysdate,MUSER='{4}', BONDED_NOW_ONHAND='{5}'" & _
                    " where PERIOD_NAME=to_date('{6}','yyyy/MM/dd') and org = '{7}' and TRANSACTION_TYPE='{8}' and COST_CENTER = '{9}' and PRODUCT_NUM='{10}'", _
                    Label4.Text.Trim, text11.Value.Trim, Label5.Text, Label8.Text, Context.User.Identity.Name, txtBonded_now_onhand.Value, edtDateFrom.Value.Trim, _
                    txt_org_no.Value.Trim, dd_list_yd.Value.Trim, txt_cost_no.Value.Trim, Text1.Value.Trim)
                    db.ExecuteSQL(strsql3)
                Catch ex As Exception
                    Throw ex
                    Exit Sub
                End Try
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ק令�\!');</script>")
                If Label1.Text <> "2" Then
                    loaddata(viewstate("strsql"))
                End If
            End If
            'loaddata(viewstate("strsql"))
            btn_state(0)
            textbox_state(2)
            cleartext(0)
            btn5_excel.Enabled = True
        End Sub

        Sub hanshu()
            Dim ds As New DataSet
            Dim P_ORG_1 As String = txt_org_no.Value
            Dim P_MOTH_1 As String = edtDateFrom.Value
            Dim P_TRANSACTION_TYPE_1 As String = dd_list_yd.Value
            Dim P_COST_CENTER_1 As String = txt_cost_no.Value
            Dim P_PRODUCT_NUM_1 As String = Text1.Value
            'If e.Item.Cells(10).Text = "" Then
            Try
               Dim strsql1 As String = "select FWEB_ONL_PREONHAND('" & P_ORG_1 & "',to_date('" & P_MOTH_1 & "','yyyy/MM/dd'),'" & P_TRANSACTION_TYPE_1 & "','" & P_COST_CENTER_1 & "','" & P_PRODUCT_NUM_1 & "') PREONHAND from dual"
               ds = db.FillDataSet(strsql1, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("PREONHAND")) Then
                       Label4.Text = ds.Tables(0).Rows(0).Item("PREONHAND")
                   Else
                       Label4.Text = "0"
                   End If
               Else
                   Label4.Text = "0"
               End If

               Dim strsql2 As String = "select FWEB_ONL_WASTEQTY('" & P_ORG_1 & "',to_date('" & P_MOTH_1 & "','yyyy/MM/dd'),'" & P_TRANSACTION_TYPE_1 & "','" & P_COST_CENTER_1 & "','" & P_PRODUCT_NUM_1 & "') WASTEQTY from dual"
               ds = db.FillDataSet(strsql2, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("WASTEQTY")) Then
                       Label5.Text = ds.Tables(0).Rows(0).Item("WASTEQTY")
                   Else
                       Label5.Text = "0"
                   End If
               Else
                   Label5.Text = "0"
               End If
               ' Label8.Text = (CLng(label4) + CLng(Label5.Text.Text) - CLng(text11.Value.Trim)).ToString

               Dim strsql3 As String
               strsql3 = " SELECT  DESCRIPTION ,UNIT    FROM UCCST_PRODUCT_T WHERE ORG = '00' AND PRODUCT_NUM = '" + Text1.Value + "'"
               ds = db.FillDataSet(strsql3, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("DESCRIPTION")) Then
                       Label10.Text = ds.Tables(0).Rows(0).Item("DESCRIPTION")
                   Else
                       Label10.Text = ""
                   End If
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("UNIT")) Then
                       Label6.Text = ds.Tables(0).Rows(0).Item("UNIT")
                   Else
                       Label6.Text = ""
                   End If
               Else
                   Label10.Text = ""
                   Label6.Text = ""
               End If

               Dim strsql4 As String
               strsql4 = " SELECT BONDED_FLAG FROM BGA.BONDED_MATERIAL_ITEMS_V@PROD WHERE SEGMENT1 = '" + Text1.Value + "' AND ROWNUM = 1"
               ds = db.FillDataSet(strsql4, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("BONDED_FLAG")) Then
                       lbl_bonded_flag.Text = ds.Tables(0).Rows(0).Item("BONDED_FLAG")
                   Else
                       lbl_bonded_flag.Text = ""
                   End If
               Else
                   lbl_bonded_flag.Text = ""
               End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
        End Sub '�եΨ�ƪ��L�{
        Sub loadcost_name()
            Dim sqlstr As String
            Dim TempDS As New DataSet
            Try

               sqlstr = " SELECT DISTINCT A.COST_CENTER �s�X, B.COST_CENTER_NAME �W�� FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                        " WHERE A.ORG = '" + txt_org_no.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                        " AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
                        " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) " & _
                        " ORDER BY A.COST_CENTER "
               TempDS = db.FillDataSet(sqlstr, 2)
               dd_cost_name.DataSource = TempDS.Tables(0)
               dd_cost_name.DataValueField = "�s�X"
               dd_cost_name.DataTextField = "�W��"
               dd_cost_name.DataBind()
               dd_cost_name.Items.Insert(0, "")

            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not TempDS Is Nothing Then
                 TempDS.Dispose()
              End If
            End Try

        End Sub

        Sub bt3_date()
            Dim ds As New DataSet
            Dim strsql As String
            Try
               strsql = "SELECT PRODUCT_NUM AS �Ƹ�, DESCIPTION AS �~�W�W��, UNIT AS ��� FROM UCCST_PRODUCT_T WHERE ORG = '00' AND PRODUCT_NUM = text1.Value"
               ds = db.FillDataSet(strsql, 2)
               If ds.Tables(0).Rows.Count <> 0 Then
                   If Not IsDBNull(ds.Tables(0).Rows(0).Item("�Ƹ�")) Then
                       txt_org_no.Value = ds.Tables(0).Rows(0).Item("org")
                   End If
               End If
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
        End Sub

        Function check_data2() As Boolean
            Dim ds As New DataSet
            Dim inti As Int16 = 0
            If txt_org_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
                Return False
            End If
            If edtDateFrom.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������i����!');</script>")
                Return False
            End If
            If txt_cost_no.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������ߤ��i����!');</script>")
                Return False
            End If
            If Text1.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ƹ����i����!');</script>")
                Return False
            End If
            If dd_list_yd.Value = "" Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������O���i����!');</script>")
                Return False
            End If
            If txt_org_no.Value <> "" Then
                'CHECK�O�_���u�W���s�L�I���t�O
                Dim strsql1 As String = "SELECT COUNT(*) FROM FWEB_ONL_DEPT where org='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql1) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���t�O�D�u�W���s�L�I���t�O�A��CHECK! �Y���s�W���L�I���t�O�A�гq���]�ȼW�[!');</script>")
                End If
                'CHECK�O�_���t�O�v��
                Dim strsql2 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + Context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                        "AND PROJ_NO = 'ONL' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "'"
                If db.GetExecuteScalar(strsql2) = 0 Then
                    inti = inti + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L���t�O�v���A�гq���]�ȼW�[!');</script>")
                End If

                If txt_cost_no.Value <> "" Then
                    'CHECK�O�_���u�W���s�L�I����������
                    Dim strsql3 As String = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG ='" + txt_org_no.Value.Trim + "' AND COST_CENTER = '" + txt_cost_no.Value.Trim + "'"
                    If db.GetExecuteScalar(strsql3) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���������߫D�u�W���s�L�I���������ߡA��CHECK! �Y���s�W���L�I���������ߡA�гq���]�ȼW�[!');</script>")
                    End If
                    'CHECK�O�_�����������v��
                    Dim strsql4 As String = "SELECT COUNT(*) FROM FWEB_USER_ORGAU_D WHERE USER_ID='" + Context.User.Identity.Name + "' AND SYST_NO = 'FWEB' " & _
                                            "AND PROJ_NO = 'ONL' AND DECODE(ORG,'ALL','" + txt_org_no.Value.Trim + "',ORG)='" + txt_org_no.Value.Trim + "' " & _
                                            "AND DECODE(COST_CENTER,'ALL','" + txt_cost_no.Value.Trim + "',COST_CENTER)='" + txt_cost_no.Value.Trim + "' "
                    If db.GetExecuteScalar(strsql4) = 0 Then
                        inti = inti + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�z�L�����������v���A�гq���]�ȼW�[!');</script>")
                    End If
                End If
            End If
            'CHECK�������O
            Dim nint As Int16
            Dim strsql0 As String
            strsql0 = "SELECT TRANSACTION_TYPE FROM FWEB_ONL_TRANSACTION_TYPE WHERE PRODUCT_NUM_FIRST ='" + Text1.Value.Substring(0, 1) + "'  AND ORG ='" + txt_org_no.Value + "'  AND COST_CENTER = '" + txt_cost_no.Value + "' AND ORG <> 'ALL' AND COST_CENTER <> 'ALL'"
            ds = db.FillDataSet(strsql0, 2)
            If ds.Tables(0).Rows.Count <> 0 Then
                If ds.Tables(0).Rows(0).Item("TRANSACTION_TYPE") = dd_list_yd.Value Then
                    nint = nint + 1
                End If
            End If
            Dim strsql20 As String
            strsql20 = "SELECT TRANSACTION_TYPE FROM FWEB_ONL_TRANSACTION_TYPE WHERE PRODUCT_NUM_FIRST = '" + Text1.Value.Substring(0, 1) + "'  AND ORG= 'ALL' AND COST_CENTER= 'ALL' "
            ds = db.FillDataSet(strsql20, 2)
            If ds.Tables(0).Rows.Count <> 0 Then
                If ds.Tables(0).Rows(0).Item("TRANSACTION_TYPE") = dd_list_yd.Value Then
                    nint = nint + 1
                End If
            End If
            If nint = 0 Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O,��������,�Ƹ��Ĥ@���ҹ������������O���~,�Э��s��J!');</script>")
            End If
            'CHECK��ƬO�_�s�b
            Dim strsql30 As String = " select * from FWEB_ONL_ONHAND where PERIOD_NAME=to_date('" + edtDateFrom.Value + "','yyyy-MM-dd') and org='" + txt_org_no.Value.Trim + "' and  COST_CENTER = '" + txt_cost_no.Value + "'" & _
                   " AND PRODUCT_NUM = '" + Text1.Value + "' and TRANSACTION_TYPE = '" + dd_list_yd.Value + "'"
            If db.GetExecuteScalar(strsql30) > 0 Then
                inti = inti + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��Ƥw�s�b�A�L�k�s�W');</script>")
            End If
            If text11.Value = "" And Label2.Text <> "1" Then
                text11.Value = "0"
            End If

            If Not ds Is Nothing Then
               ds.Dispose()
            End If

            If inti > 0 Then
                Return False
            Else
                Return True
            End If
        End Function

    Private Sub btn5_excel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5_excel.Click
        Response.Write("<script>window.open(' " + EXPORT_EXCEL() + " ')</script>")
    End Sub

    Function EXPORT_EXCEL() As String       '(ByVal source, ByVal e)
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim ds As New DataSet
        Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_ONHAND_EXCEL.xls"
        Dim savepath As String = PublicM.GetSessionDataRoot(context) + "ONL_ONHAND_EXCEL.xls" 'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(context) + "ONL_ONHAND_EXCEL.xls" 'JavaScript�}��xls���|,�n�Psavepath�P
        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)
            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells
            '��R���
            ds = db.FillDataSet(ViewState("strsql"), 2)

            Dim x, y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "PERIOD_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("PERIOD_NAME").ToString.Substring(0, 10)
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("ORG").ToString
                            j = j + 1
                        Next
                    Case "TRANSACTION_TYPE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 4) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 5) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER_NAME").ToString
                            j = j + 1
                        Next
                    Case "BONDED_FLAG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 6) = "'" + ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_NUM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 7) = "'" + ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_DESC"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                            j = j + 1
                        Next
                    Case "UOM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString
                            j = j + 1
                        Next
                    Case "PRE_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "NOW_WASTE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString
                            j = j + 1
                        Next
                    Case "NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "BONDED_NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "CHECK_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("CHECK_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "REMARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 15) = ds.Tables(0).Rows(x).Item("REMARK").ToString
                            j = j + 1
                        Next
                    Case "IMPORT_MARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 16) = ds.Tables(0).Rows(x).Item("IMPORT_MARK").ToString
                            j = j + 1
                        Next
                    Case "IMPORT_DATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 17) = ds.Tables(0).Rows(x).Item("IMPORT_DATE").ToString
                            j = j + 1
                        Next
                    Case "IMPORT_USER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 18) = "'" + ds.Tables(0).Rows(x).Item("IMPORT_USER").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_MARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 19) = ds.Tables(0).Rows(x).Item("APPROVE_MARK").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_DATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 20) = ds.Tables(0).Rows(x).Item("APPROVE_DATE").ToString
                            j = j + 1
                        Next
                    Case "APPROVE_USER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 21) = "'" + ds.Tables(0).Rows(x).Item("APPROVE_USER").ToString
                            j = j + 1
                        Next
                    Case "MDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            If Not IsDBNull(ds.Tables(0).Rows(x).Item("MDATE")) Then
                                oCells(j + 2, 22) = ds.Tables(0).Rows(x).Item("MDATE").ToString
                            Else
                                oCells(j + 2, 22) = ""
                            End If
                            j = j + 1
                        Next
                    Case "MUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 23) = "'" + ds.Tables(0).Rows(x).Item("MUSER").ToString
                            j = j + 1
                        Next
                    Case "CDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            If Not IsDBNull(ds.Tables(0).Rows(x).Item("CDATE")) Then
                                oCells(j + 2, 24) = "'" + ds.Tables(0).Rows(x).Item("CDATE").ToString
                            Else
                                oCells(j + 2, 24) = ""
                            End If
                            j = j + 1
                        Next
                    Case "CUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 25) = "'" + ds.Tables(0).Rows(x).Item("CUSER").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            ' oExcel.DisplayAlerts = True

            Return JSsavepath
        Catch ex As Exception
            Throw ex
        Finally
            ' oExcel.Application.Quit()
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If


            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If

            If Not ds Is Nothing Then
               ds.Dispose()
            End If

            'GC.Collect()

        End Try
        '  GC.Collect()
    End Function

    Private Sub btn7_form_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn7_form.Click
        '���ɮ榡
        Response.Write("<script>window.open('ONL_Template/ONL_ONHAND_SPEC.xls ')</script>")
    End Sub

    Private Sub btn4_abo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4_abo.Click
        'btn_state(0)
        textbox_state(2)
        cleartext(0)
        btn_state(3)
    End Sub

    Private Sub btn6_tran_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn6_tran.Click
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "open", "<script language='JavaScript'>window.open('FWEB_FIND_INPUT.aspx','','height=180,width=430') </script>")
        btn8_excel.Enabled = True
    End Sub

    Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
        dg.CurrentPageIndex = e.NewPageIndex
        loaddata(viewstate("strsql"))
    End Sub
    Private Sub btn8_excel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn8_excel.Click
        Response.Write("<script>window.open(' " + EXPORT_EXCEL2() + " ')</script>")
    End Sub
    Function EXPORT_EXCEL2() As String       '(ByVal source, ByVal e)
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim ds As New DataSet
        Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_ONHAND_ERROR.xls"
        Dim savepath As String = PublicM.GetSessionDataRoot(context) + "ONL_ONHAND_ERROR.xls" 'xls�s����|,�n�PJSsavepath�P
        Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(context) + "ONL_ONHAND_ERROR.xls" 'JavaScript�}��xls���|,�n�Psavepath�P
        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)

            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells

            '��R���
            Dim sqlstr As String
            sqlstr = "select * from FWEB_ONL_TRANSFER_ERROR where MUSER='" + context.User.Identity.Name + "' and FUNC_NO='ONL_ONHAND'"
            ds = db.FillDataSet(sqlstr, 2)

            Dim x, y As Integer
            Dim i As Integer = ds.Tables(0).Rows.Count
            Dim j As Int16 = 0
            For y = 0 To ds.Tables(0).Columns.Count - 1
                Select Case ds.Tables(0).Columns(y).ColumnName
                    Case "REASON"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("REASON").ToString
                            j = j + 1
                        Next
                    Case "PERIOD_NAME"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 2) = "'" + ds.Tables(0).Rows(x).Item("PERIOD_NAME").ToString.Substring(0, 10)
                            j = j + 1
                        Next
                    Case "ORG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("ORG").ToString
                            j = j + 1
                        Next
                    Case "TRANSACTION_TYPE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 4) = ds.Tables(0).Rows(x).Item("TRANSACTION_TYPE").ToString
                            j = j + 1
                        Next
                    Case "COST_CENTER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 5) = "'" + ds.Tables(0).Rows(x).Item("COST_CENTER").ToString
                            j = j + 1
                        Next
                    Case "BONDED_FLAG"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 6) = "'" + ds.Tables(0).Rows(x).Item("BONDED_FLAG").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_NUM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                            j = j + 1
                        Next
                    Case "PRODUCT_DESC"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("PRODUCT_DESC").ToString
                            j = j + 1
                        Next
                    Case "UOM"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("UOM").ToString
                            j = j + 1
                        Next
                    Case "PRE_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PRE_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "NOW_WASTE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("NOW_WASTE").ToString
                            j = j + 1
                        Next
                    Case "NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("NOW_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "BONDED_NOW_ONHAND"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("BONDED_NOW_ONHAND").ToString
                            j = j + 1
                        Next
                    Case "REMARK"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("REMARK").ToString
                            j = j + 1
                        Next
                    Case "MDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            If Not IsDBNull(ds.Tables(0).Rows(x).Item("MDATE")) Then
                                oCells(j + 2, 15) = "'" + ds.Tables(0).Rows(x).Item("MDATE").ToString.Substring(0, 10)
                            Else
                                oCells(j + 2, 15) = ""
                            End If
                            j = j + 1
                        Next
                    Case "MUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 16) = "'" & ds.Tables(0).Rows(x).Item("MUSER").ToString
                            j = j + 1
                        Next
                    Case "CDATE"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            If Not IsDBNull(ds.Tables(0).Rows(x).Item("CDATE")) Then
                                oCells(j + 2, 17) = "'" + ds.Tables(0).Rows(x).Item("CDATE").ToString.Substring(0, 10)
                            Else
                                oCells(j + 2, 17) = ""
                            End If
                            j = j + 1
                        Next
                    Case "CUSER"
                        j = 0
                        For x = 0 To ds.Tables(0).Rows.Count - 1
                            oCells(j + 2, 18) = "'" + ds.Tables(0).Rows(x).Item("CUSER").ToString
                            j = j + 1
                        Next
                End Select
            Next

            '-------------------------------------------------------------------------
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If

            oSheet.SaveAs(savepath)
            oBook.Close()

            ' oExcel.DisplayAlerts = True

            Return JSsavepath
        Catch ex As Exception
            Throw ex
        Finally
            ' oExcel.Application.Quit()
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If


            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If

            If Not ds Is Nothing Then
               ds.Dispose()
            End If
            'GC.Collect()

        End Try
        '  GC.Collect()
    End Function

    '    Private Sub dd_list_yd_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dd_list_yd.SelectedIndexChanged
    '        If edtDateFrom.Value <> "" Then
    '            If txt_org_no.Value <> "" Then
    '                If txt_cost_no.Value <> "" Then
    '                    If Text1.Value <> "" Then
    '                        If dd_list_yd.SelectedItem.Text <> "" Then
    '                            If Label2.Text = "1" Then
    '                                If check_data2() = False Then
    '                                    Exit Sub
    '                                Else
    '                                    hanshu()
    '                                    Text2.Value = Label4.Text
    '                                    Text3.Value = Label5.Text
    '                                End If
    '                            End If
    '                        End If
    '                    End If
    '                End If
    '            End If
    '        End If
    '    End Sub

End Class

End Namespace
