'Imports System.Web.UI.WebControls
Imports Microsoft.Web.UI.WebControls

Namespace FR

    Partial Class FWEB_MENU_SELECT
        Inherits System.Web.UI.Page

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not Page.IsPostBack Then
                'bindtree(tv.Nodes)
                Dim userid As String
                userid = context.User.Identity.Name
                bindtree2(userid)
            End If
        End Sub

        Sub bindtree(ByVal Nds As TreeNodeCollection)
            Dim strsql As String
            strsql = "select  distinct syst_no,syst_name from fweb_system"
            Dim ds As DataSet = db.FillDataSet(strsql)
            Dim dv As DataView = ds.Tables(0).DefaultView
            'dv.RowFilter = "HiDepID=" + depid
            Dim tn As TreeNode
            Dim strID As String
            Dim dr As DataRowView
            For Each dr In dv
                strID = dr("syst_no").ToString()
                If (strID <> "") Then
                    tn = New TreeNode
                    tn.ID = dr("syst_no").ToString()
                    tn.Text = dr("syst_name").ToString()
                    Nds.Add(tn)
                    'bindtree(Nds(Nds.Count - 1).Nodes, strID)
                End If
            Next
        End Sub

        Sub bindtree2(ByVal userid As String)
            Dim Nds As TreeNodeCollection
            Nds = tv.Nodes
            Dim strsql As String, user_level As String
            strsql = "select user_level from fweb_user_login_m where user_id='" + userid + "'"
            user_level = db.GetExecuteScalar(strsql)

            If user_level = "S" Then
                SuperTree(userid)
            Else
                NormalTree(userid)
            End If

        End Sub

#Region "SuperTree:�B�zSuperUser��Tree"
        Sub SuperTree(ByVal userid As String)
            Dim Nds As TreeNodeCollection
            Dim tn As TreeNode
            '�����T�h�Υ|�h��node num
            Dim node_step1 As Integer
            Dim node_step2 As Integer
            Dim node_step3 As Integer

            '�ثe�u�B�z�T�h�Υ|�h
            Dim ds1 As New DataSet
            Dim ds2 As New DataSet
            Dim ds3 As New DataSet
            Dim ds4 As New DataSet

            Dim ds1_init, ds1_cnt As Integer
            Dim ds2_init, ds2_cnt As Integer
            Dim ds3_init, ds3_cnt As Integer
            Dim ds4_init, ds4_cnt As Integer

            Dim ds1_Sql As String
            Dim ds2_Sql As String
            Dim ds3_Sql As String
            Dim ds4_Sql As String

            Nds = tv.Nodes

            '�ثe�u�B�z�T�h�Υ|�h

            '�B�z�Ĥ@�h
            ds1_Sql = "SELECT DISTINCT SYST_NO,SYST_NAME,SYST_SEQ " & _
                      "  FROM FWEB_SYSTEM " & _
                      " ORDER BY SYST_SEQ "

            ds1 = db.FillDataSet(ds1_Sql)
            ds1_cnt = ds1.Tables(0).Rows.Count

            For ds1_init = 0 To ds1_cnt - 1

                tn = New TreeNode
                tn.ID = ds1.Tables(0).Rows(ds1_init).Item("SYST_NO")
                tn.Text = ds1.Tables(0).Rows(ds1_init).Item("SYST_NAME")
                Nds.Add(tn)
                node_step1 = Decimal.ToInt32(ds1.Tables(0).Rows(ds1_init).Item("SYST_SEQ")) - 1

                '�B�z�ĤG�h
                ds2_Sql = "SELECT DISTINCT PROJ_NO, PROJ_NAME, PROJ_SEQ " & _
                          "  FROM FWEB_SYSTEM " & _
                          " WHERE SYST_NO='" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                          " ORDER BY PROJ_SEQ"

                ds2 = db.FillDataSet(ds2_Sql)
                ds2_cnt = ds2.Tables(0).Rows.Count

                For ds2_init = 0 To ds2_cnt - 1

                    tn = New TreeNode
                    tn.ID = ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO")
                    tn.Text = ds2.Tables(0).Rows(ds2_init).Item("PROJ_NAME")
                    Nds(node_step1).Nodes.Add(tn)
                    node_step2 = Decimal.ToInt32(ds2.Tables(0).Rows(ds2_init).Item("PROJ_SEQ")) - 1

                    '�B�z�ĤT�h
                    ds3_Sql = "SELECT DISTINCT MFUN_NO, MFUN_NAME, MFUN_SEQ " & _
                              "  FROM FWEB_SYSTEM  " & _
                              " WHERE SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                              "   AND PROJ_NO = '" + ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO") + "' " & _
                              "   AND MFUN_NO IS NOT NULL" & _
                              " ORDER BY MFUN_SEQ"

                    ds3 = db.FillDataSet(ds3_Sql)
                    ds3_cnt = ds3.Tables(0).Rows.Count

                    If ds3_cnt > 0 Then  '���\��s�ժ��A�i�ĥ|�h

                        For ds3_init = 0 To ds3_cnt - 1

                            tn = New TreeNode
                            tn.ID = ds3.Tables(0).Rows(ds3_init).Item("MFUN_NO")
                            tn.Text = ds3.Tables(0).Rows(ds3_init).Item("MFUN_NAME")
                            Nds(node_step1).Nodes(node_step2).Nodes.Add(tn)
                            node_step3 = Decimal.ToInt32(ds3.Tables(0).Rows(ds3_init).Item("MFUN_SEQ")) - 1

                            '�B�z�ĥ|�h
                            ds4_Sql = "SELECT DISTINCT FUNC_NO, FUNC_NAME, FUNC_PATH, FUNC_SEQ " & _
                                      "  FROM FWEB_SYSTEM " & _
                                      " WHERE SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                                      "   AND PROJ_NO ='" + ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO") + "' " & _
                                      "   AND MFUN_NO = '" + ds3.Tables(0).Rows(ds3_init).Item("MFUN_NO") + "' " & _
                                      " ORDER BY FUNC_SEQ "

                            ds4 = db.FillDataSet(ds4_Sql)
                            ds4_cnt = ds4.Tables(0).Rows.Count

                            For ds4_init = 0 To ds4_cnt - 1
                                tn = New TreeNode
                                tn.ID = ds4.Tables(0).Rows(ds4_init).Item("FUNC_NO")
                                tn.Text = ds4.Tables(0).Rows(ds4_init).Item("FUNC_NAME")
                                tn.NavigateUrl = ds4.Tables(0).Rows(ds4_init).Item("FUNC_PATH")
                                tn.Target = "MENU_R"
                                Nds(node_step1).Nodes(node_step2).Nodes(node_step3).Nodes.Add(tn)
                            Next

                        Next

                    Else  '�L�\��s�ժ��A�i�ĤT�h


                        '�B�z�ĤT�h
                        ds3_Sql = "SELECT DISTINCT FUNC_NO, FUNC_NAME, FUNC_PATH, FUNC_SEQ " & _
                                  "  FROM FWEB_SYSTEM " & _
                                  " WHERE SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                                  "   AND PROJ_NO ='" + ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO") + "' " & _
                                  " ORDER BY FUNC_SEQ "

                        ds3 = db.FillDataSet(ds3_Sql)
                        ds3_cnt = ds3.Tables(0).Rows.Count
                        For ds3_init = 0 To ds3_cnt - 1
                            tn = New TreeNode
                            tn.ID = ds3.Tables(0).Rows(ds3_init).Item("FUNC_NO")
                            tn.Text = ds3.Tables(0).Rows(ds3_init).Item("FUNC_NAME")
                            tn.NavigateUrl = ds3.Tables(0).Rows(ds3_init).Item("FUNC_PATH")
                            tn.Target = "MENU_R"
                            Nds(node_step1).Nodes(node_step2).Nodes.Add(tn)
                        Next

                    End If

                Next

            Next

        End Sub
#End Region

#Region "NormalTree:�B�z�@��User��Tree"
        Sub NormalTree(ByVal userid As String)
            Dim Nds As TreeNodeCollection
            Dim tn As TreeNode
            '�����T�h�Υ|�h��node num
            Dim node_step1 As Integer
            Dim node_step2 As Integer
            Dim node_step3 As Integer

            '�ثe�u�B�z�T�h�Υ|�h
            Dim ds1 As New DataSet
            Dim ds2 As New DataSet
            Dim ds3 As New DataSet
            Dim ds4 As New DataSet

            Dim ds1_init, ds1_cnt As Integer
            Dim ds2_init, ds2_cnt As Integer
            Dim ds3_init, ds3_cnt As Integer
            Dim ds4_init, ds4_cnt As Integer

            Dim ds1_Sql As String
            Dim ds2_Sql As String
            Dim ds3_Sql As String
            Dim ds4_Sql As String

            Nds = tv.Nodes

            '�ثe�u�B�z�T�h�Υ|�h

            '�B�z�Ĥ@�h
            ds1_Sql = "SELECT DISTINCT S.SYST_NO, S.SYST_NAME, S.SYST_SEQ " & _
                      "  FROM FWEB_USER_LOGIN_D D, FWEB_SYSTEM S " & _
                      " WHERE D.USER_ID ='" + userid + "' " & _
                      "   AND D.SYST_NO = S.SYST_NO " & _
                      " ORDER BY S.SYST_SEQ "

            ds1 = db.FillDataSet(ds1_Sql)
            ds1_cnt = ds1.Tables(0).Rows.Count

            For ds1_init = 0 To ds1_cnt - 1

                tn = New TreeNode
                tn.ID = ds1.Tables(0).Rows(ds1_init).Item("SYST_NO")
                tn.Text = ds1.Tables(0).Rows(ds1_init).Item("SYST_NAME")
                Nds.Add(tn)
                node_step1 = ds1_init

                '�B�z�ĤG�h
                ds2_Sql = "SELECT DISTINCT S.PROJ_NO, S.PROJ_NAME, S.PROJ_SEQ " & _
                          "  FROM FWEB_USER_LOGIN_D D, FWEB_SYSTEM S " & _
                          " WHERE D.USER_ID = '" + userid + "' " & _
                          "   AND D.SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                          "   AND D.SYST_NO = S.SYST_NO " & _
                          "   AND D.PROJ_NO = S.PROJ_NO " & _
                          " ORDER BY S.PROJ_SEQ "

                ds2 = db.FillDataSet(ds2_Sql)
                ds2_cnt = ds2.Tables(0).Rows.Count

                For ds2_init = 0 To ds2_cnt - 1

                    tn = New TreeNode
                    tn.ID = ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO")
                    tn.Text = ds2.Tables(0).Rows(ds2_init).Item("PROJ_NAME")
                    Nds(node_step1).Nodes.Add(tn)
                    node_step2 = ds2_init

                    '�B�z�ĤT�h
                    ds3_Sql = "SELECT DISTINCT S.MFUN_NO, S.MFUN_NAME, S.MFUN_SEQ " & _
                              "  FROM FWEB_USER_LOGIN_D D, FWEB_SYSTEM S" & _
                              " WHERE D.USER_ID = '" + userid + "' " & _
                              "   AND D.SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                              "   AND D.PROJ_NO = '" + ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO") + "' " & _
                              "   AND D.SYST_NO = S.SYST_NO " & _
                              "   AND D.PROJ_NO = S.PROJ_NO " & _
                              "   AND D.FUNC_NO = S.FUNC_NO " & _
                              "   AND S.MFUN_NO IS NOT NULL" & _
                              " ORDER BY S.MFUN_SEQ"

                    ds3 = db.FillDataSet(ds3_Sql)
                    ds3_cnt = ds3.Tables(0).Rows.Count

                    If ds3_cnt > 0 Then  '���\��s�ժ��A�i�ĥ|�h

                        For ds3_init = 0 To ds3_cnt - 1

                            tn = New TreeNode
                            tn.ID = ds3.Tables(0).Rows(ds3_init).Item("MFUN_NO")
                            tn.Text = ds3.Tables(0).Rows(ds3_init).Item("MFUN_NAME")
                            Nds(node_step1).Nodes(node_step2).Nodes.Add(tn)
                            node_step3 = ds3_init

                            '�B�z�ĥ|�h
                            ds4_Sql = "SELECT DISTINCT S.FUNC_NO, S.FUNC_NAME, S.FUNC_PATH, S.FUNC_SEQ " & _
                                      "  FROM FWEB_USER_LOGIN_D D, FWEB_SYSTEM S " & _
                                      " WHERE D.USER_ID = '" + userid + "' " & _
                                      "   AND D.SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                                      "   AND D.PROJ_NO = '" + ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO") + "' " & _
                                      "   AND S.MFUN_NO = '" + ds3.Tables(0).Rows(ds3_init).Item("MFUN_NO") + "' " & _
                                      "   AND D.SYST_NO = S.SYST_NO " & _
                                      "   AND D.PROJ_NO = S.PROJ_NO " & _
                                      "   AND D.FUNC_NO = S.FUNC_NO " & _
                                      " ORDER BY S.FUNC_SEQ "

                            ds4 = db.FillDataSet(ds4_Sql)
                            ds4_cnt = ds4.Tables(0).Rows.Count

                            For ds4_init = 0 To ds4_cnt - 1
                                tn = New TreeNode
                                tn.ID = ds4.Tables(0).Rows(ds4_init).Item("FUNC_NO")  '"RPT1"
                                tn.Text = ds4.Tables(0).Rows(ds4_init).Item("FUNC_NAME")  '"�쪫�ƯӥΩ��Ӫ�-�������"
                                tn.NavigateUrl = ds4.Tables(0).Rows(ds4_init).Item("FUNC_PATH") '"FWEB_WIN_RPT1.ASPX"
                                tn.Target = "MENU_R"
                                Nds(node_step1).Nodes(node_step2).Nodes(node_step3).Nodes.Add(tn)
                            Next

                        Next

                    Else  '�L�\��s�ժ��A�i�ĤT�h

                        '�B�z�ĤT�h
                        ds3_Sql = "SELECT S.FUNC_NO, S.FUNC_NAME, S.FUNC_PATH, S.FUNC_SEQ " & _
                                  "  FROM FWEB_USER_LOGIN_D D, FWEB_SYSTEM S " & _
                                  " WHERE D.USER_ID = '" + userid + "' " & _
                                  "   AND D.SYST_NO = '" + ds1.Tables(0).Rows(ds1_init).Item("SYST_NO") + "' " & _
                                  "   AND D.PROJ_NO = '" + ds2.Tables(0).Rows(ds2_init).Item("PROJ_NO") + "' " & _
                                  "   AND D.SYST_NO = S.SYST_NO " & _
                                  "   AND D.PROJ_NO = S.PROJ_NO " & _
                                  "   AND D.FUNC_NO = S.FUNC_NO " & _
                                  " ORDER BY S.FUNC_SEQ "

                        ds3 = db.FillDataSet(ds3_Sql)
                        ds3_cnt = ds3.Tables(0).Rows.Count

                        For ds3_init = 0 To ds3_cnt - 1
                            tn = New TreeNode
                            tn.ID = ds3.Tables(0).Rows(ds3_init).Item("FUNC_NO")
                            tn.Text = ds3.Tables(0).Rows(ds3_init).Item("FUNC_NAME")
                            tn.NavigateUrl = ds3.Tables(0).Rows(ds3_init).Item("FUNC_PATH")
                            tn.Target = "MENU_R"
                            Nds(node_step1).Nodes(node_step2).Nodes.Add(tn)
                        Next

                    End If


                Next

            Next

        End Sub
#End Region

        Function check(ByVal str As String, ByVal strname As String, ByVal userid As String) As Boolean
            Dim strsql As String
            strsql = "select count(*) from fweb_user_login_d where " + str + "='" + strname + "' and user_id='" + userid + "'"
            If db.GetExecuteScalar(strsql) > 0 Then
                Return True
            Else
                Return False
            End If

        End Function

        Function check_proj_no(ByVal str As String, ByVal strname As String, ByVal userid As String) As Boolean
            Dim strsql As String
            strsql = "select count(*) from fweb_user_login_d where proj_no ='" + strname + "' and user_id='" + userid + "'"
            If db.GetExecuteScalar(strsql) > 0 Then
                Return True
            Else
                Return False
            End If

        End Function

        Function check_syst_no(ByVal str As String, ByVal strname As String, ByVal userid As String) As Boolean
            Dim strsql As String
            strsql = "select count(*) from fweb_user_login_d where " + str + "='" + strname + "' and user_id='" + userid + "'"
            If db.GetExecuteScalar(strsql) > 0 Then
                Return True
            Else
                Return False
            End If

        End Function

        Function check_func_no(ByVal str As String, ByVal strname As String, ByVal userid As String) As Boolean
            Dim strsql As String
            strsql = "select count(*) from fweb_user_login_d where " + str + "='" + strname + "' and user_id='" + userid + "'"
            If db.GetExecuteScalar(strsql) > 0 Then
                Return True
            Else
                Return False
            End If
        End Function

    End Class

End Namespace


