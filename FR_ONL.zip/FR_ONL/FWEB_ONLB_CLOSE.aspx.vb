Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Math


Namespace FR

Partial Class FWEB_ONLB_CLOSE
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Dim erp_cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("erp_conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txt_org_no.Value <> "" Then

            'Me.dd_cost_name.Value = Me.txt_cost_no.Value
        End If
        If Not Page.IsPostBack Then
            sysdate()
            loadorg_name()
            Me.dd_org_name.Value = Me.txt_org_no.Value


            btn_state(0)
        End If
    End Sub

    Sub loadorg_name()
        Dim sqlstr As String
        sqlstr = " SELECT DISTINCT A.ORG �s�X,B.ORG_NAME �W�� FROM FWEB_ONLB_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                 " WHERE A.ORG = B.ORG AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                 " AND C.PROJ_NO = 'ONLB' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ORDER BY A.ORG "
        dd_org_name.DataSource = db.FillDataSet(sqlstr)
        dd_org_name.DataValueField = "�s�X"
        dd_org_name.DataTextField = "�W��"
        dd_org_name.DataBind()
        dd_org_name.Items.Insert(0, "")
    End Sub


    Private Sub btnInq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInq.Click
        'If check_data() = False Then
        '    Exit Sub
        'End If

        If Me.txt_org_no.Value = "" Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert1", "<script defer>alert('�п�����b�t�O');</script>")
                Exit Sub
                'ElseIf File1.PostedFile.FileName.Substring(File1.PostedFile.FileName.LastIndexOf(".")).ToLower() <> ".xls" Then
                '    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(),"alert2", "<script defer>alert('�п��Excel�ɮ�');</script>")
            '    Exit Sub
        Else
        End If

        Dim Sdate As DateTime = Date.Parse(Me.Text1.Value.ToString)
        'Me.Text1.Value = Sdate.ToString("yyyy/MM") + "/01"

        Dim strsql As String
        Dim class1 As String = " SELECT ORG, TRUNC(PERIOD_MOTH) AS PERIOD_MOTH, PERIOD_NAME, START_DATE, END_DATE, CLOSE_DATE, EDAY, USER_ID FROM FWEB_ONLB_CALENDAR T"
        '20120702
        'Dim class2 As String = " WHERE T.PERIOD_MOTH = TO_DATE('" + Text1.Value.Trim + "','yyyy/MM/dd') AND T.ORG= '" + txt_org_no.Value.Trim + "' AND T.CLOSE_DATE IS NULL "
        Dim class2 As String = " WHERE T.START_DATE = TO_DATE('" + Text1.Value.Trim + "','yyyy/MM/dd')  " & vbNewLine & _
                               " AND T.ORG= '" + txt_org_no.Value.Trim + "' AND T.CLOSE_DATE IS NULL "


        viewstate("class2") = class2

        strsql = class1 & class2
        viewstate("strsql") = strsql
        Me.dg.CurrentPageIndex = 0
        loaddata(viewstate("strsql"))
        btn_state(1)
        End Sub

        Sub btn_state(ByVal intnum As Int16)
            If intnum = 0 Then
                btnInq.Enabled = True
                Btnout.Enabled = False

            ElseIf intnum = 1 Then
                Btnout.Enabled = True

            ElseIf intnum = 2 Then
                btnInq.Enabled = True
                Btnout.Enabled = False

            End If
        End Sub

        Sub InitB()
            Me.txt_org_no.Value = ""
            Me.dd_org_name.Value = ""
            Me.Text1.Value = ""
        End Sub


        Sub loaddata(ByVal strsql As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            ds = db.FillDataSet(strsql)
            dv = ds.Tables(0).DefaultView
            dg.DataSource = dv
            dg.DataBind()
            GetPageInfo()
        End Sub

    Sub GetPageInfo()
        Dim strsql As String
        strsql = " select count(*) from  FWEB_ONLB_CALENDAR T " & viewstate("class2")
        Dim strsql1 As String = db.GetExecuteScalar(strsql).ToString
        Label9.Text = "�@<font face=verdana >" + strsql1 + "</font>���O��<font face=verdana >"
    End Sub


        Sub sysdate()
            Dim sqlstr As String
            sqlstr = "SELECT A.ORG,A.PERIOD_MOTH,A.START_DATE FROM FWEB_ONLB_CALENDAR A,(SELECT T.ORG FROM FWEB_USER_ORGAU_D O, FWEB_ONLB_DEPT T" & _
                 " WHERE O.USER_ID = '" + Context.User.Identity.Name + "' AND O.SYST_NO = 'FWEB' AND O.PROJ_NO = 'ONLB' AND DECODE(O.ORG, 'ALL', T.ORG, O.ORG) = T.ORG " & _
                 " AND DECODE(O.COST_CENTER, 'ALL', T.COST_CENTER, O.COST_CENTER) = T.COST_CENTER AND ROWNUM = 1) B" & _
                 " WHERE A.ORG = B.ORG AND A.CLOSE_DATE IS NULL"
            Dim ds As New DataSet
            ds = db.FillDataSet(sqlstr)
            If ds.Tables(0).Rows.Count <> 0 Then
                txt_org_no.Value = ds.Tables(0).Rows(0).Item("ORG")
                Text1.Value = ds.Tables(0).Rows(0).Item("START_DATE") '20120702
                'Text1.Value = ds.Tables(0).Rows(0).Item("PERIOD_MOTH")
            End If
        End Sub

    Private Sub Btnout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnout.Click
        Dim vResult As Boolean = True
        Dim P_PERIOD_NAME, P_ORG As String
        Try

            'strsql = " update FWEB_ONLB_CALENDAR T set CLOSE_DATE = SYSDATE " & _
            ' " where t.PERIOD_NAME=to_date('" + edtDateFrom.Value.Trim + "','yyyy/MM/dd') and T.ORG= '" + txt_org_no.Value.Trim + "'" & _
            ' " and A.CLOSE_DATE IS NULL "
            'strsql2 = viewstate("strsql3")
            'db.ExecuteSQL(strsql2)

            vResult = ExecSP(P_PERIOD_NAME, P_ORG)
                InitB()
        Catch ex As Exception
            Throw ex
        End Try

        If vResult = True Then
            '�ˬd�O�_�����`
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('���b���\!');</script>")
                dg.CurrentPageIndex = 0
                loaddata(viewstate("strsql"))
                btn_state(0)
            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "", "<script>alert('���b����')</script>")

            End If

        End Sub



        Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
            dg.CurrentPageIndex = e.NewPageIndex
            loaddata(viewstate("strsql"))
        End Sub

        Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
            'If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            '    CType(e.Item.Cells(0).FindControl("btnpao"), LinkButton).Attributes.Add("onclick", "return confirm('�T�w�N������Ʃߪ���?');")
            'End If
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
                'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
                'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
                e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
                e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
            End If
        End Sub

        'Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
        '    If e.CommandName = "TRUNOUT" Then
        '        Try
        '            Dim strsql4 As String
        '            strsql4 = "update FWEB_ONLB_ONHAND  set IMPORT_DATE=sysdate,IMPORT_MARK='Y',IMPORT_USER='" + context.User.Identity.Name + "'" & _
        '                       " where PERIOD_NAME=to_date('" + e.Item.Cells(1).Text + "','yyyy/MM/dd') and ORG='" + e.Item.Cells(2).Text + "'" & _
        '                       " and TRANSACTION_TYPE='" + e.Item.Cells(3).Text + "' and COST_CENTER='" + e.Item.Cells(4).Text + "' and PRODUCT_NUM='" + e.Item.Cells(7).Text + "'"
        '            db.ExecuteSQL(strsql4)
        '        Catch ex As Exception
        '            Throw ex
        '        Finally
        '            If (dg.Items.Count = 1 And dg.CurrentPageIndex > 0) Then
        '                dg.CurrentPageIndex -= 1
        '                loaddata(viewstate("strsql"))
        '            Else
        '                loaddata(viewstate("strsql"))
        '            End If
        '        End Try
        '        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(),"msg", "<script defer>alert('�ߪ��ަ��\!');</script>")
        '    End If
        'End Sub

    Function ExecSP(ByVal P_PERIOD_NAME As String, ByVal P_ORG As String) As Boolean
        Dim cmd As New OleDbCommand
        Dim vResult As Boolean = True

            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_ONLB_CLOSE_SP"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn

                    cmd.Parameters.Add(New OleDbParameter("P_ORG", OleDbType.VarChar, 5))
                    cmd.Parameters.Add(New OleDbParameter("P_PERIOD_NAME", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_USER_ID", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_MESSAGE", OleDbType.VarChar, 100)).Direction = ParameterDirection.Output

                    cmd.Parameters("P_ORG").Value = txt_org_no.Value 'P_ORG  '"64" '
                    cmd.Parameters("P_PERIOD_NAME").Value = Text1.Value '"OCT-11" 'P_PERIOD_NAME
                    cmd.Parameters("P_USER_ID").Value = Context.User.Identity.Name
                    cmd.Parameters("P_MESSAGE").Value = ""

                    cmd.ExecuteNonQuery()
                    vResult = True

                Catch ex As Exception
                    vResult = False

                Finally
                    cn.Close()
                End Try
            End If

        Return vResult
    End Function
End Class
End Namespace
