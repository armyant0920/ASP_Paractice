Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices


Namespace FR

Partial Class FWEB_FIX_MAINTAIN
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtAccount.Text = context.User.Identity.Name
        If Not Page.IsPostBack Then
           Init_Data()
           GetPeriod()
           UpdateDropDownList()
           Lbl_ActionFlag.Text = "QUERY"
        End If
    End Sub

    Sub GetPeriod()
        '����
        'txtPeriod_Name.Text = Format(Today, "yyyy/MM")
        Dim SQL As String
        Dim DSTemp As DataSet
        SQL = " SELECT TO_CHAR(START_DATE,'YYYY/MM/DD') AS Period_Name " & vbNewLine & _
              " FROM UCCST_CALENDAR_T WHERE MTL_CLOSE IS NULL "
        DSTemp = db.FillDataSet(SQL, 2)
        If DSTemp.Tables(0).Rows.Count > 0 Then
            txtPeriod_Name.Text = DSTemp.Tables(0).Rows(0).Item("Period_Name").ToString.Substring(0, 7)
            'txtPeriod_Name.Text = "2013/03/01"
        End If
    End Sub

    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
        '�d��
        GridMain.DataSource = Nothing
        GridMain.DataBind()

        Lbl_ActionFlag.Text = "QUERY"
        SetQueryViewState()
        Me.GridMain.CurrentPageIndex = 0
        Load_Data(viewstate("sqltxt"))
    End Sub

        Sub Load_Data(ByVal sqlcmd As String)
            Dim DSTemp As New DataSet

            Try
                DSTemp = db.FillDataSet(sqlcmd, 2)

                If DSTemp.Tables(0).Rows.Count > 0 Then
                    GridMain.DataSource = DSTemp.Tables(0)
                    GridMain.DataBind()

                    btnSave.Enabled = True
                Else
                    GridMain.DataSource = Nothing
                    GridMain.DataBind()
                    Alert("�d�L���.", Me)
                End If
                DSTemp.Dispose()
            Catch ex As Exception
                Alert(ex.Message, Me)
            Finally
                If Not DSTemp Is Nothing Then
                   DSTemp.Dispose()
                End If
            End Try
        End Sub

    Sub SetQueryViewState()
        '�d��Query��JViewState�A�H�K�H�ɥi���sQuery
        Dim StrSQL As String = ""
        'StrSQL = "SELECT * " & vbNewLine & _
        '      "FROM FWEB_FIX_MAINTAIN_T FM " & vbNewLine & _
        '      "WHERE FM.WASTE_ORG = '" & txtOrg.Text.ToString.Trim & "' " & vbNewLine & _
        '      "AND PERIOD_NAME =to_date('" & txtPeriod_Name.Text.ToString & "/01" & "','yyyy/mm/dd') " & vbNewLine
        'If Not ddlModify.SelectedItem.Text.ToString.Equals("") Then
        '   StrSQL &= IIf(ddlModify.SelectedItem.Text.ToString.Equals("Y"), " AND NVL(FORECAST_CAPACITY,'0')!=0 " & vbNewLine, " AND NVL(FORECAST_CAPACITY,'0')=0 " & vbNewLine)
        'End If
        'StrSQL &= "ORDER BY PRODUCT_NUM "
        StrSQL = "SELECT TO_CHAR(FM.PERIOD_NAME,'YYYY/MM') AS PERIOD_NAME,FM.PRODUCT_NUM,FM.WASTE_ORG " & vbNewLine & _
                 ",FM.FG_PRODUCT_NUM,FM.FG_PRODUCT_NUM1,FM.FG_PRODUCT_NUM2,FM.FG_PRODUCT_NUM3,FM.FG_PRODUCT_NUM4,FM.FG_PRODUCT_NUM5,FM.FG_PRODUCT_NUM6" & vbNewLine & _
                 ",FM.FORECAST_CAPACITY,FM.PHASE_VALUE,FM.UNIT,FM.TOOLING_STATUS,FM.VENDER_NAME,FIRST_SUIT " & vbNewLine & _
                 "FROM FWEB_FIX_MAINTAIN_T FM " & vbNewLine & _
                 ",( " & vbNewLine & _
                 "  SELECT ORG FROM FWEB_USER_ORGAU_D " & vbNewLine & _
                 "  WHERE SYST_NO='FWEB' AND PROJ_NO='FIX' " & vbNewLine & _
                 "  AND USER_ID ='" & Context.User.Identity.Name & "'" & vbNewLine & _
                 " )A" & vbNewLine & _
                 "WHERE FM.PERIOD_NAME =to_date('" & txtPeriod_Name.Text.ToString & "/01','yyyy/mm/dd') " & vbNewLine
        StrSQL &= IIf(txtOrg.Text.ToString.Trim.Equals(""), "", "AND FM.WASTE_ORG = '" & txtOrg.Text.ToString.Trim & "' " & vbNewLine)
        If Not ddlModify.SelectedItem.Text.ToString.Equals("") Then
           StrSQL &= IIf(ddlModify.SelectedItem.Text.ToString.Equals("Y"), " AND NVL(FORECAST_CAPACITY,'0')!=0 " & vbNewLine, " AND NVL(FORECAST_CAPACITY,'0')=0 " & vbNewLine)
        End If
        StrSQL &= "AND FM.WASTE_ORG=DECODE(A.ORG,'ALL',FM.WASTE_ORG,A.ORG)" & vbNewLine & _
                  "ORDER BY PRODUCT_NUM"

        Dim sqltxt As String = StrSQL

        viewstate("sqltxt") = sqltxt

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        '����
        Lbl_ActionFlag.Text = "QUERY"
        Init_Data()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim StrSQL As String = ""
        Dim StrMessage As String = ""
        Try
           Dim IntCheck As Integer = 0
           For i As Integer = 0 To GridMain.Items.Count - 1
              If CType(GridMain.Items(i).FindControl("ChkSelect"), WebControls.CheckBox).Checked = True Then
                 If CType(GridMain.Items(i).FindControl("txtFG_Product_Num"), WebControls.TextBox).Text.ToString.Equals("") Then
                    Alert("�п�J" & GridMain.Items(i).Cells(2).Text.ToString.Trim & "�����~�Ƹ�", Me)
                    Exit Sub
                 End If


                 StrSQL = "Update FWEB_FIX_MAINTAIN_T set " & vbNewLine & _
                          "FG_Product_Num='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",FG_Product_Num1='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num1"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",FG_Product_Num2='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num2"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",FG_Product_Num3='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num3"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",FG_Product_Num4='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num4"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",FG_Product_Num5='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num5"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",FG_Product_Num6='" & CType(GridMain.Items(i).FindControl("txtFG_Product_Num6"), WebControls.TextBox).Text.ToString & "' " & vbNewLine & _
                          ",Forecast_Capacity=NVL('" & CType(GridMain.Items(i).FindControl("txtForecast_Capacity"), WebControls.TextBox).Text.ToString & "',0) " & vbNewLine & _
                          ",Phase_Value=NVL('" & CType(GridMain.Items(i).FindControl("txtPhase_Value"), WebControls.TextBox).Text.ToString & "',0)  " & vbNewLine & _
                          ",FIRST_SUIT='" & CType(GridMain.Items(i).FindControl("txtFirst_Suit"), WebControls.TextBox).Text.ToString.Trim.ToUpper & "'  " & vbNewLine & _
                          ",MUSER='" & txtAccount.Text.Trim & "'" & vbNewLine & _
                          ",MDATE=SYSDATE "
                 StrSQL += " Where Period_Name=to_date('" & txtPeriod_Name.Text.Trim & "/01','yyyy/mm/dd') " & vbNewLine & _
                           " and Waste_Org='" & txtOrg.Text.ToString.Trim & "'" & vbNewLine & _
                           " and Product_Num='" & GridMain.Items(i).Cells(2).Text.ToString.Trim & "' " & vbNewLine

                 db.ExecuteSQL(StrSQL)

                 StrMessage += IIf(StrMessage.Equals(""), GridMain.Items(i).Cells(2).Text.ToString.Trim, "," & GridMain.Items(i).Cells(2).Text.ToString.Trim)

                 IntCheck += 1

              End If
           Next

           If IntCheck < 1 Then
              Alert("�п�ܩһݧ�s�Ƹ�!", Me)
              Exit Sub
           Else
              Alert("�Ƹ�:" & StrMessage & "�x�s����!", Me)
           End If


        Catch ex As Exception
            Alert(ex.Message, Me)
            Exit Sub
        End Try
        Lbl_ActionFlag.Text = "QUERY"
        Load_Data(viewstate("sqltxt"))
    End Sub

    Private Sub dg_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        'DataGridView���C�@��Record��Delete�]�wLinkButton
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btnDELETE"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        'DataGridView���C�@��Record�]�wcurrentcolor
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub dg_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        If e.CommandName = "DELETE" Then     '�R��            
            Dim sqlcmd As String
            sqlcmd = "DELETE FROM FWEB_ONL_PROD WHERE PROD_RULE = '" + e.Item.Cells(1).Text.Trim + "' AND ORG ='" + e.Item.Cells(3).Text.Trim + "' " & _
                     "AND COST_CENTER = '" + e.Item.Cells(4).Text.Trim + "' AND INCLUDE = '" + e.Item.Cells(6).Text.Trim + "' AND PRODUCT_NUM = '" + e.Item.Cells(7).Text.Trim + "'"
            Try
                db.ExecuteSQL(sqlcmd)
            Catch ex As Exception
                Throw ex
            Finally
                Lbl_ActionFlag.Text = "QUERY"
                Load_Data(viewstate("sqltxt"))
            End Try
        End If
    End Sub

    Function Check_Data() As Boolean
        'Check
        Dim ErrCount As Int16 = 0

        '�t�O���i����
        If ErrCount = 0 And txtOrg.Text.ToString.Equals("") Then
            ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
        End If

        'Err
        If ErrCount > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Sub SetDisplay()

        If Lbl_ActionFlag.Text = "ADD" Then    '�s�W

        ElseIf Lbl_ActionFlag.Text = "QUERY" Then '�s��
            '���s���A
            btnSave.Enabled = True
            btnCancel.Enabled = True
            '����
            txtPeriod_Name.BackColor = ColorTranslator.FromHtml("#E0FFFF")
            '�t�O
            txtOrg.Enabled = False
            txtOrg.Text = ""
            txtOrg.BackColor = ColorTranslator.FromHtml("#E0FFFF")
        End If
    End Sub

    Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
        '��Excel
        Response.Write("<script>window.open(' " + EXPORT_EXCEL() + " ')</script>")
    End Sub

        Function EXPORT_EXCEL() As String
            Dim SQL As String = ""
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim ds As New DataSet
            Dim sTemplate As String = Server.MapPath("~") & "\FIX_template\FIX_REPORT.xls"
            Dim savepath As String = PublicM.GetSessionDataRoot(Context) + "FIX_REPORT.xls" 'xls�s����|,�n�PJSsavepath�P
            Dim JSsavepath As String = PublicM.GetJavaSessionDataRoot(Context) + "FIX_REPORT.xls" 'JavaScript�}��xls���|,�n�Psavepath�P

            Try
                '�w�q�@�ӷs���u�@ï
                oBooks = oExcel.Workbooks
                oBooks.Open(sTemplate)
                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                '��R���
                SQL = "SELECT DECODE(FM.PRODUCT_NUM,'','����JWEB','�w��JWEB') AS STATUS " & vbNewLine & _
                      ",A.PERIOD AS PERIOD_ERP,A.WASTE_ORG AS WASTE_ORG_ERP,A.PRODUCT_NUM AS PRODUCT_NUM_ERP " & vbNewLine & _
                      ",FM.* " & vbNewLine & _
                      "FROM " & vbNewLine & _
                      "(" & vbNewLine & _
                      "   SELECT DISTINCT O.ORG_ID,O.MO,TO_CHAR(TRX_DATE,'YYYY/MM') AS PERIOD " & vbNewLine & _
                      "   ,INV.ITEM_NAME AS PRODUCT_NUM,INV.COST_ORG_CODE AS WASTE_ORG " & vbNewLine & _
                      "   ,DECODE(O.MO,'P',SUBSTR(INV.ITEM_DESC,5,10),SUBSTR(INV.ITEM_DESC,5,8)) AS FG_PRODUCT_NUM " & vbNewLine & _
                      "   ,INV.ITEM_DESC " & vbNewLine & _
                      "   FROM MISAPPS.WMINV_TRX_V@PROD INV " & vbNewLine & _
                      "   ,UCCST_ORG_T O " & vbNewLine & _
                      "   WHERE O.ORG=INV.ORG_CODE " & vbNewLine & _
                      "   AND SUBSTR(INV.ITEM_NAME,1,2)='OF' " & vbNewLine & _
                      "   AND INV.COST_ORG_CODE=NVL('" & txtOrg.Text.ToString.Trim & "',INV.COST_ORG_CODE) " & vbNewLine & _
                      "   AND INV.TRANSACTION_TYPE_ID='106' " & vbNewLine & _
                      "   AND INV.TRX_DATE BETWEEN to_date('" & txtPeriod_Name.Text.Trim & "/01','yyyy/mm/dd') AND LAST_DAY(to_date('" & txtPeriod_Name.Text.Trim & "/01','yyyy/mm/dd') )+0.99999 " & vbNewLine & _
                      ") A " & vbNewLine & _
                      ",(SELECT TO_CHAR(T.PERIOD_NAME,'YYYY/MM') AS PERIOD,T.* " & vbNewLine & _
                      "  FROM FWEB_FIX_MAINTAIN_T T " & vbNewLine & _
                      "  WHERE T.PERIOD_NAME=to_date('" & txtPeriod_Name.Text.Trim & "/01','yyyy/mm/dd') " & vbNewLine & _
                      "  AND T.WASTE_ORG=NVL('" & txtOrg.Text.ToString.Trim & "',T.WASTE_ORG) " & vbNewLine & _
                      ") FM " & vbNewLine & _
                      "WHERE A.PERIOD=FM.PERIOD(+) AND A.WASTE_ORG=FM.WASTE_ORG(+) AND A.PRODUCT_NUM=FM.PRODUCT_NUM(+)"


                ds = db.FillDataSet(SQL, 2)
                Dim x, y As Integer
                Dim i As Integer = ds.Tables(0).Rows.Count
                Dim j As Int16 = 0
                For y = 0 To ds.Tables(0).Columns.Count - 1
                    Select Case ds.Tables(0).Columns(y).ColumnName
                        Case "STATUS"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 1) = ds.Tables(0).Rows(x).Item("STATUS").ToString
                                j = j + 1
                            Next
                        Case "PERIOD_ERP"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 2) = ds.Tables(0).Rows(x).Item("PERIOD_ERP").ToString
                                j = j + 1
                            Next
                        Case "WASTE_ORG_ERP"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 3) = ds.Tables(0).Rows(x).Item("WASTE_ORG_ERP").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM_ERP"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 4) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM_ERP").ToString
                                j = j + 1
                            Next
                        Case "PERIOD"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 5) = "'" + ds.Tables(0).Rows(x).Item("PERIOD").ToString
                                j = j + 1
                            Next
                        Case "WASTE_ORG"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 6) = ds.Tables(0).Rows(x).Item("WASTE_ORG").ToString
                                j = j + 1
                            Next
                        Case "PRODUCT_NUM"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 7) = ds.Tables(0).Rows(x).Item("PRODUCT_NUM").ToString
                                j = j + 1
                            Next
                        Case "FG_PRODUCT_NUM"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 8) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM").ToString
                                j = j + 1
                            Next
                        Case "FORECAST_CAPACITY" '�зǲ���
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 9) = ds.Tables(0).Rows(x).Item("FORECAST_CAPACITY").ToString
                                j = j + 1
                            Next
                        Case "PHASE_VALUE" '����
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 10) = ds.Tables(0).Rows(x).Item("PHASE_VALUE").ToString
                                j = j + 1
                            Next
                        Case "UNIT" '���
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 11) = ds.Tables(0).Rows(x).Item("UNIT").ToString
                                j = j + 1
                            Next
                        Case "TOOLING_STATUS" '�v�㦬�O����
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 12) = ds.Tables(0).Rows(x).Item("TOOLING_STATUS").ToString
                                j = j + 1
                            Next
                        Case "FIRST_SUIT" '�M��
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 13) = ds.Tables(0).Rows(x).Item("FIRST_SUIT").ToString
                                j = j + 1
                            Next
                        Case "FG_PRODUCT_NUM1"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 14) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM1").ToString
                                j = j + 1
                            Next
                        Case "FG_PRODUCT_NUM2"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 15) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM2").ToString
                                j = j + 1
                            Next
                        Case "FG_PRODUCT_NUM3"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 16) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM3").ToString
                                j = j + 1
                            Next
                       Case "FG_PRODUCT_NUM4"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 17) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM4").ToString
                                j = j + 1
                            Next
                       Case "FG_PRODUCT_NUM5"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 18) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM5").ToString
                                j = j + 1
                            Next
                       Case "FG_PRODUCT_NUM6"
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 19) = ds.Tables(0).Rows(x).Item("FG_PRODUCT_NUM6").ToString
                                j = j + 1
                            Next
                        Case "VENDER_NAME" '������
                            j = 0
                            For x = 0 To ds.Tables(0).Rows.Count - 1
                                oCells(j + 2, 20) = ds.Tables(0).Rows(x).Item("VENDER_NAME").ToString
                                j = j + 1
                            Next
                    End Select
                Next

                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                Return JSsavepath
            Catch ex As Exception
                Throw ex
            Finally
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If


                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If

                If Not ds Is Nothing Then
                   ds.Dispose()
                End If

                GC.Collect()

            End Try
        End Function

    Private Sub btnImport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnImport.Click
        Try

           If Not txtOrg.Text.Trim.Equals("") Then
              btnImport.Attributes.Add("onclick", "javascript:return confirm('Do you want to Import data?');")

              ExecSP()
           End If
        Catch ex As Exception
        Finally
        End Try
    End Sub

    Sub ExecSP()
        Dim StrMessage As String = ""
        '����StoreProcedure
        Dim cmd As New OleDbCommand
            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_FIX_MAINTAIN_IMPORT_SP"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn
                    cmd.Parameters.Add(New OleDbParameter("P_PERIOD_NAME", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_WASTE_ORG", OleDbType.VarChar, 15))
                    cmd.Parameters.Add(New OleDbParameter("P_USER_ID", OleDbType.VarChar, 15))
                    cmd.Parameters.Add(New OleDbParameter("P_MESSAGE", OleDbType.VarChar, 4000))
                    cmd.Parameters("P_MESSAGE").Direction = ParameterDirection.Output

                    cmd.Parameters("P_PERIOD_NAME").Value = txtPeriod_Name.Text.ToString.Trim & "/01"
                    cmd.Parameters("P_WASTE_ORG").Value = txtOrg.Text.ToString.Trim
                    cmd.Parameters("P_USER_ID").Value = Context.User.Identity.Name
                    cmd.Parameters("P_MESSAGE").Value = ""
                    cmd.ExecuteNonQuery()

                    StrMessage = cmd.Parameters("P_MESSAGE").Value.ToString
                    If StrMessage.Equals("") Then
                        Alert("�����J����!", Me)
                    Else
                        Alert(StrMessage, Me)
                    End If

                Catch ex As Exception
                    Alert(ex.Message, Me)
                Finally
                    cn.Close()
                End Try
            End If
    End Sub

        Sub loaddata(ByVal strsql As String)
            Dim DSTemp As New DataSet
            Dim DVTemp As New DataView
            DSTemp = db.FillDataSet(strsql, 2)
            DVTemp = DSTemp.Tables(0).DefaultView
            GridMain.DataSource = DVTemp
            GridMain.DataBind()
        End Sub

    Private Sub UpdateDropDownList()
        Dim SQL As String = ""
        Try
            '       " SELECT 'ALL' AS ORG, 'ALL' AS ORG_NAME FROM DUAL UNION ALL  " & vbNewLine & _
            SQL = " SELECT ORG AS ID,ORG_NAME AS NAME " & vbNewLine & _
                  " FROM (" & vbNewLine & _
                  " SELECT DISTINCT A.ORG AS ORG,B.ORG_NAME AS ORG_NAME FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                  " WHERE A.ORG = B.ORG AND C.USER_ID = '" + context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                  " AND C.PROJ_NO = 'FIX' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ) T ORDER BY T.ORG "
            GetddlDownList(SQL, ddlOrg, "NCST2")

        ddlModify.Items.Clear()
        ddlModify.Items.Insert(0, "")
        ddlModify.Items.Insert(1, "Y")
        ddlModify.Items.Insert(2, "N")

        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally

        End Try
    End Sub

    Private Sub GridMain_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles GridMain.PageIndexChanged
        '����
        GridMain.CurrentPageIndex = e.NewPageIndex

        Load_Data(viewstate("sqltxt"))
    End Sub

    Private Sub ddlOrg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlOrg.SelectedIndexChanged
        txtOrg.Text = ddlOrg.SelectedValue.ToString
    End Sub

    Private Sub Init_Data()
       ddlOrg.SelectedIndex = -1
       txtOrg.Text = ""
       btnSave.Enabled = False
       GridMain.DataSource = Nothing
       GridMain.DataBind()
    End Sub
End Class

End Namespace
