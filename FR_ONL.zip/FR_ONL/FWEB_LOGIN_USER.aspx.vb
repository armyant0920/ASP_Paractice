Namespace FR

Partial Class FWEB_LOGIN_USER
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '  btn1.Attributes.Add("onclick", "return " + common.showdialog("FWEB_FIND_USER.aspx?type=a", 640, 480))

        If Not Page.IsPostBack Then
            viewstate("strquery") = "select user_id,user_name,password,e_mail,user_level,muser,to_char(MDATE,'yyyy/MM/dd') as MDATE from FWEB_USER_LOGIN_M order by user_id"
            bind_data()
            btn_state(0)
            Text3.Disabled = False
        End If
            btn1.Attributes.Add("onclick", "var st=window.showModalDialog('FWEB_FIND_USER.aspx',window,'dialogTop=160px;dialogWidth=640px;dialogHeight=480px;help:no;status:no');if(st!=undefined){document.all('TXT_ORG_NO').value=st;document.getElementById('btn1').click();} else {return false;}")
    End Sub
    Private Sub btn1_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.ServerClick
        Dim struserid As String
        struserid = Trim(TXT_ORG_NO.Text)
        binduser(struserid)
        bind_dg(struserid)
    End Sub
    Sub binduser(ByVal struserid As String)
        Dim strsql As String
        strsql = "select user_id,user_name,password,e_mail,user_level,muser from FWEB_USER_LOGIN_M where user_id='" + struserid + "' order by user_id"
        Dim ds As DataSet
        ds = db.FillDataSet(strsql)
        TXT_ORG_NO.Text = ds.Tables(0).Rows(0).Item("user_id")
        TXT_COST_CENTER.Text = ds.Tables(0).Rows(0).Item("user_name")
        Text1.Value = ds.Tables(0).Rows(0).Item("password")
        Text2.Value = ds.Tables(0).Rows(0).Item("e_mail")
        DropDownList1.SelectedValue = ds.Tables(0).Rows(0).Item("user_level")
        If Not IsDBNull(ds.Tables(0).Rows(0).Item("muser")) Then
            Text3.Value = ds.Tables(0).Rows(0).Item("muser")
        Else
            Text3.Value = ""
        End If
        Text3.Disabled = True
    End Sub
    Function GetPageInfo(ByRef p As Wuqi.Webdiyer.AspNetPager) As String
        Return String.Format _
        ("��<font color=red><b>{0}</b></font>��&nbsp&nbsp�@<font color=blue><b>{1}</b></font>��<font color=blue><b>{2}</b></font>��", p.CurrentPageIndex.ToString, p.PageCount.ToString, p.RecordCount.ToString)
    End Function

    Private Sub AspNetPager1_PageChanged(ByVal src As System.Object, ByVal e As Wuqi.Webdiyer.PageChangedEventArgs) Handles AspNetPager1.PageChanged
        DataGrid1.EditItemIndex = -1
        DataGrid1.CurrentPageIndex = 0
        DataGrid1.CurrentPageIndex = e.NewPageIndex - 1
        AspNetPager1.CurrentPageIndex = e.NewPageIndex
        bind_data()
    End Sub
    Sub bind_data()
        With db.FillDataSet(viewstate("strquery")).Tables(0)
            DataGrid1.DataSource = .DefaultView
            DataGrid1.DataBind()
            DataGrid1.Height = Unit.Pixel(1)
            AspNetPager1.RecordCount = .Rows.Count
            AspNetPager1.CustomInfoText = GetPageInfo(AspNetPager1)
        End With
    End Sub
    Sub btn_state(ByVal intnum As Int16)
        If intnum = 0 Then                     '�D�s�説�A
            BN_QUR.Enabled = True
            BN_ADD.Enabled = True
            BN_SAV.Enabled = False
            BN_CAN.Enabled = False
        Else                                   '�s�説�A
            BN_QUR.Enabled = False
            BN_ADD.Enabled = False
            BN_SAV.Enabled = True
            BN_CAN.Enabled = True

        End If
    End Sub

    Private Sub BN_QUR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_QUR.Click
        btn_state(0)
        Dim struserid As String, strname As String
        strname = Trim(TXT_COST_CENTER.Text)
        struserid = Trim(TXT_ORG_NO.Text)
        bind_dg_query(struserid, strname)
    End Sub

    Private Sub BN_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_ADD.Click
        btn_state(1)
        btn1.Disabled = True
        TXT_ORG_NO.Text = ""
        TXT_COST_CENTER.Text = ""
        Text1.Value = ""
        Text2.Value = ""
        DropDownList1.SelectedValue = "U"
        Text3.Disabled = True
        Text3.Value = context.User.Identity.Name
        DataGrid1.Columns(0).Visible = False
        DataGrid1.Columns(1).Visible = False
    End Sub

    Private Sub BN_SAV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_SAV.Click
        Dim strsql As String
        label()
        If check_text() = False Then
            Exit Sub
        End If

        If TXT_ORG_NO.ReadOnly = True Then
                strsql = String.Format("update FWEB_USER_LOGIN_M set user_name='{0}',password='{1}',e_mail='{2}',user_level='{3}',muser='{4}',mdate=sysdate where user_id='{5}'", Trim(TXT_COST_CENTER.Text), Trim(Text1.Value), Trim(Text2.Value), Trim(DropDownList1.SelectedValue), Trim(Text3.Value), Trim(TXT_ORG_NO.Text))
        Else
            If check_data() = False Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�ӨϥΪ̥N�X�w�s�b!');</script>")
                Exit Sub
            End If
                strsql = String.Format("insert into  FWEB_USER_LOGIN_M(user_id,USER_NAME,PASSWORD,E_MAIL,USER_LEVEL,MUSER,MDATE) values('{0}','{1}','{2}','{3}','{4}','{5}',sysdate)", Trim(TXT_ORG_NO.Text), Trim(TXT_COST_CENTER.Text), Trim(Text1.Value), Trim(Text2.Value), Trim(DropDownList1.SelectedValue), Trim(Text3.Value))
        End If
        db.ExecuteSQL(strsql)
        TXT_ORG_NO.Text = ""
        TXT_COST_CENTER.Text = ""
        Text1.Value = ""
        Text2.Value = ""
        DropDownList1.SelectedValue = "U"
        Text3.Value = ""
        label()
        btn_state(0)
        btn1.Disabled = False
        TXT_ORG_NO.Enabled = True
        TXT_ORG_NO.ReadOnly = False
        DataGrid1.Columns(0).Visible = True
        DataGrid1.Columns(1).Visible = True
        viewstate("strquery") = "select user_id,user_name,password,e_mail,user_level,muser,to_char(MDATE,'yyyy/MM/dd HH24:mi:ss') as MDATE from FWEB_USER_LOGIN_M"
        bind_data()
        Text3.Disabled = False
    End Sub

    Private Sub BN_CAN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BN_CAN.Click
        cancel()
        viewstate("strquery") = "select user_id,user_name,password,e_mail,user_level,muser,to_char(MDATE,'yyyy/MM/dd HH24:mi:ss') as MDATE from FWEB_USER_LOGIN_M order by user_id"
        bind_data()
    End Sub
    Private Sub DataGrid1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btndelete"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��" & e.Item.Cells(3).Text & "��?');")
        End If
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            'e.Item.Attributes("onclick") = "javascript:setedtstate();txtcompanyid.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';txtcompanyname.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';txtcompanyjie.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';txtoa.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';txtoa2.value='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';txtoa3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';txtcreator.value='" + Server.HtmlDecode(e.Item.Cells(8).Text).Trim + "';txtcdt.value='" + Server.HtmlDecode(e.Item.Cells(9).Text).Trim + "';txtreviser.value='" + Server.HtmlDecode(e.Item.Cells(10).Text).Trim + "';txtudt.value='" + Server.HtmlDecode(e.Item.Cells(11).Text).Trim + "';"
            'e.Item.Attributes("onclick") = "javascript:TXT_ORG_NO.value='" + Server.HtmlDecode(e.Item.Cells(2).Text).Trim + "';TXT_COST_CENTER.value='" + Server.HtmlDecode(e.Item.Cells(3).Text).Trim + "';Text1.value='" + Server.HtmlDecode(e.Item.Cells(4).Text).Trim + "';Text2.value='" + Server.HtmlDecode(e.Item.Cells(5).Text).Trim + "';DropDownList1.selectvalue='" + Server.HtmlDecode(e.Item.Cells(6).Text).Trim + "';Text3.value='" + Server.HtmlDecode(e.Item.Cells(7).Text).Trim + "';"
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub DataGrid1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.ItemCommand
        If e.CommandName = "delete" Then
            Dim str As String = "delete from FWEB_USER_LOGIN_M where USER_ID='" + e.Item.Cells(2).Text + "'"
            Try

                db.ExecuteSQL(str)
            Catch ex As Exception
                Throw ex

            Finally
                cancel()
                viewstate("strquery") = "select user_id,user_name,password,e_mail,user_level,muser,to_char(MDATE,'yyyy/MM/dd') as MDATE from FWEB_USER_LOGIN_M order by user_id"
                bind_data()
            End Try
        Else
            binduser(e.Item.Cells(2).Text)
            TXT_ORG_NO.Enabled = False
            TXT_ORG_NO.ReadOnly = True
            btn1.Disabled = True
            btn_state(1)
            DataGrid1.Columns(0).Visible = False
            DataGrid1.Columns(1).Visible = False
            Text3.Disabled = True
        End If
    End Sub
    Sub bind_dg(ByVal struserid As String)
        Dim strsql As String
        strsql = "select user_id,user_name,password,e_mail,user_level,muser,to_char(MDATE,'yyyy/MM/dd') as MDATE from FWEB_USER_LOGIN_M where user_id='" + struserid + "' order by user_id"
        viewstate("strquery") = strsql
        bind_data()
    End Sub
    Sub bind_dg_query(ByVal struserid As String, ByVal username As String)
        Dim strsql As String
        strsql = "select user_id,user_name,password,e_mail,user_level,muser,to_char(MDATE,'yyyy/MM/dd') as MDATE from FWEB_USER_LOGIN_M where user_id like '%" + struserid + "%' and user_name like '%" + username + "%' order by user_id"
        viewstate("strquery") = strsql
        bind_data()
    End Sub
    Function check_text() As Boolean
        If Trim(TXT_ORG_NO.Text) = "" Then
            Label7.Visible = True
        End If
        If Trim(TXT_COST_CENTER.Text) = "" Then
            Label10.Visible = True
        End If
        If Trim(Text1.Value) = "" Then
            Label9.Visible = True
        End If
        If Trim(Text2.Value) = "" Then
            Label11.Visible = True
        End If
        If Label7.Visible = True Or Label9.Visible = True Or Label10.Visible = True Or Label11.Visible = True Then
            Return False
        Else
            Return True
        End If
    End Function
    Sub label()
        Label7.Visible = False
        Label9.Visible = False
        Label10.Visible = False
        Label11.Visible = False
    End Sub
    Sub cancel()
        btn_state(0)
        label()
        DataGrid1.Columns(0).Visible = True
        DataGrid1.Columns(1).Visible = True
        TXT_ORG_NO.Enabled = True
        TXT_ORG_NO.ReadOnly = False
        TXT_ORG_NO.Text = ""
        TXT_COST_CENTER.Text = ""
        Text1.Value = ""
        Text2.Value = ""
        DropDownList1.SelectedValue = "U"
        Text3.Value = ""
        btn1.Disabled = False
        Text3.Disabled = False
    End Sub
    Function check_data() As Boolean
        Dim strsql As String
        strsql = "select count(*) from FWEB_USER_LOGIN_M where user_id='" + Trim(TXT_ORG_NO.Text) + "'"
        If db.GetExecuteScalar(strsql) > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

End Class

End Namespace
