Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices


Namespace FR

Partial Class FWEB_ONL_PROD
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            Load_Org()
            Me.cmb_org_name.Value = Me.txt_org.Value
            Load_Cost()
            Lbl_ActionFlag.Text = "QUERY"
                'SetDisplay()
        ElseIf txt_org.Value <> "" Then
            Load_Cost()
            Me.cmb_cost_name.Value = Me.txt_cost_center.Value
        End If
    End Sub

    Sub Load_Org()
        '�t�O
        Dim sqlcmd As String
        Dim TempDS As New DataSet
        Try

           sqlcmd = " SELECT * FROM (SELECT 'ALL' AS ORG, 'ALL' AS ORG_NAME FROM DUAL UNION ALL " & _
                    " SELECT DISTINCT A.ORG AS ORG,B.ORG_NAME AS ORG_NAME FROM FWEB_ONL_DEPT A, UCCST_ORG_T B, FWEB_USER_ORGAU_D C " & _
                    " WHERE A.ORG = B.ORG AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' " & _
                    " AND C.PROJ_NO = 'ONL' AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) ) T ORDER BY T.ORG "
           TempDS = db.FillDataSet(sqlcmd, 2)
           cmb_org_name.DataSource = TempDS.Tables(0)
           cmb_org_name.DataValueField = "ORG"
           cmb_org_name.DataTextField = "ORG_NAME"
           cmb_org_name.DataBind()
           cmb_org_name.Items.Insert(0, "")

        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try

    End Sub

    Sub Load_Cost()
        '��������
        Dim sqlcmd As String
        Dim TempDS As New DataSet
        Try

           sqlcmd = " SELECT * FROM (SELECT 'ALL' AS COST_CENTER, 'ALL' AS COST_NAME FROM DUAL UNION ALL " & _
                    " SELECT DISTINCT A.COST_CENTER AS COST_CENTER, B.COST_CENTER_NAME AS COST_NAME FROM FWEB_ONL_DEPT A, FWEB_COST_CENTER_V B, FWEB_USER_ORGAU_D C " & _
                    " WHERE A.ORG = '" + txt_org.Value.Trim + "' AND A.ORG = B.ORG AND A.COST_CENTER = B.COST_CENTER " & _
                    " AND C.USER_ID = '" + Context.User.Identity.Name + "' AND C.SYST_NO = 'FWEB' AND C.PROJ_NO = 'ONL' " & _
                    " AND A.ORG = DECODE(C.ORG,'ALL',A.ORG,C.ORG) AND A.COST_CENTER = DECODE(C.COST_CENTER,'ALL',A.COST_CENTER,C.COST_CENTER) ) T " & _
                    " ORDER BY T.COST_CENTER "
           TempDS = db.FillDataSet(sqlcmd, 2)
           cmb_cost_name.DataSource = TempDS.Tables(0)
           cmb_cost_name.DataValueField = "COST_CENTER"
           cmb_cost_name.DataTextField = "COST_NAME"
           cmb_cost_name.DataBind()
           cmb_cost_name.Items.Insert(0, "")

        Catch ex As Exception
            Alert(ex.ToString, Me)
        Finally
          If Not TempDS Is Nothing Then
             TempDS.Dispose()
          End If
        End Try

    End Sub

    Private Sub btnQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuery.Click
        '�d��
            Lbl_ActionFlag.Text = "QUERY"
            SetQueryViewState()
            Me.dg.CurrentPageIndex = 0
            SetDisplay()
            Load_Data(ViewState("sqltxt"))

    End Sub

        Sub Load_Data(ByVal sqlcmd As String)
            Dim ds As New DataSet
            Dim dv As New DataView
            Try
               ds = db.FillDataSet(sqlcmd, 2)
               dv = ds.Tables(0).DefaultView
               dg.DataSource = dv
               dg.DataBind()
               GetPageInfo()
            Catch ex As Exception
                Alert(ex.ToString, Me)
            Finally
              If Not dv Is Nothing Then
                 dv.Dispose()
              End If
              If Not ds Is Nothing Then
                 ds.Dispose()
              End If
            End Try
        End Sub

    Sub SetQueryViewState()
        '�d��Query��JViewState�A�H�K�H�ɥi���sQuery
            Dim sqltxt1 As String = "SELECT A.PROD_RULE,DECODE(A.PROD_RULE,'A','�Ƹ����X','F','�Ƹ��Ĥ@�X') AS PROD_RULE_NAME, A.ORG, A.COST_CENTER, B.COST_CENTER_NAME, A.INCLUDE, A.PRODUCT_NUM, A.CDATE, A.CUSER, A.COST_FLAG,A.GOLD_FLAG "
            'Kevin 2022/03/30 �����լ�����true���ɭԲեX�Ӫ��r��᭱�|�h�@�ӳ�޸�,�u�n���t�X�L�ջy�k
            Dim cost_flag_sql As String
            Dim gold_flag_sql As String
            Dim org_flag As String
            Dim center_flag As String

            org_flag = If((txt_org.Value.Trim = "ALL" Or txt_org.Value.Trim = ""),
                        "AND A.ORG like '%' ",
                        "AND�@A.ORG ='" + txt_org.Value.Trim + "'")
            center_flag = If((txt_cost_center.Value.Trim = "ALL" Or txt_cost_center.Value.Trim = ""),
                        "AND A.COST_CENTER like '%' ",
                        "AND�@A.COST_CENTER ='" + txt_cost_center.Value.Trim + "'")


            cost_flag_sql = If(dd_costflag.SelectedValue = "ALL",
                               "AND '1'='1",
                               "AND A.COST_FLAG ='" + dd_costflag.SelectedValue) + "'"

            gold_flag_sql = If(dd_goldflag.SelectedValue = "ALL",
                               "AND '1'='1",
                               "AND A.GOLD_FLAG ='" + dd_goldflag.SelectedValue) + "'"
          





            '2022-05-09 Kevin_A 
            Dim sqltxt2 As String = "FROM FWEB_ONL_PROD A " & vbNewLine & _
                                    ", (SELECT 'ALL' AS ORG, 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM DUAL " & vbNewLine & _
                                    " UNION  SELECT DISTINCT DECODE('" + txt_org.Value.Trim + "','',ORG,'ALL',ORG,'" + txt_org.Value.Trim + "') AS ORG, 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM UCCST_ORG_T " & vbNewLine & _
                                    " UNION ALL SELECT DISTINCT ORG AS ORG, COST_CENTER AS COST_CENTER, COST_CENTER_NAME AS COST_CENTER_NAME FROM FWEB_COST_CENTER_V) B " & _
                                    "WHERE A.PROD_RULE LIKE DECODE('" + dd_prod_rule.SelectedValue + "','ALL','%','" + dd_prod_rule.SelectedValue + "') " & _
                                    "" + org_flag + " " & _
                                    "" + center_flag + " " & _
                                    "AND A.COST_CENTER = B.COST_CENTER AND A.ORG = B.ORG " & _
                                    "AND A.INCLUDE LIKE DECODE('" + dd_include.SelectedValue + "','ALL','%','" + dd_include.SelectedValue + "') " & _
                                    "AND A.PRODUCT_NUM LIKE '" + txt_product_num.Value.Trim + "'||'%' " & _
                                    "" + cost_flag_sql + " " & _
                                    "" + gold_flag_sql + " " & _
                                    " ORDER BY A.PROD_RULE, A.ORG, A.COST_CENTER, A.INCLUDE, A.PRODUCT_NUM "


                'Dim sqltxt2 As String = "FROM FWEB_ONL_PROD A " & vbNewLine & _
                '                        ", (SELECT 'ALL' AS ORG, 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM DUAL " & vbNewLine & _
                '                        " UNION ALL SELECT '" + txt_org.Value.Trim + "' AS ORG, 'ALL' AS COST_CENTER, 'ALL' AS COST_CENTER_NAME FROM DUAL " & vbNewLine & _
                '                        " UNION ALL SELECT DISTINCT ORG AS ORG, COST_CENTER AS COST_CENTER, COST_CENTER_NAME AS COST_CENTER_NAME FROM FWEB_COST_CENTER_V) B " & _
                '                        "WHERE A.PROD_RULE LIKE DECODE('" + dd_prod_rule.SelectedValue + "','ALL','%','" + dd_prod_rule.SelectedValue + "') " & _
                '                        "AND A.ORG LIKE '" + txt_org.Value.Trim + "'||'%' " & _
                '                        "AND A.COST_CENTER LIKE '" + txt_cost_center.Value.Trim + "'||'%' " & _
                '                        "AND A.COST_CENTER = B.COST_CENTER AND A.ORG = B.ORG " & _
                '                        "AND A.INCLUDE LIKE DECODE('" + dd_include.SelectedValue + "','ALL','%','" + dd_include.SelectedValue + "') " & _
                '                        "AND A.PRODUCT_NUM LIKE '" + txt_product_num.Value.Trim + "'||'%' " & _
                '                        "ORDER BY A.PROD_RULE, A.ORG, A.COST_CENTER, A.INCLUDE, A.PRODUCT_NUM "
            Dim sqltxt As String = sqltxt1 & sqltxt2
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>console.log('sql=" + sqltxt + "');</script>")
            System.Diagnostics.Debug.WriteLine("sqltxt1:" + sqltxt1)
            System.Diagnostics.Debug.WriteLine("sqltxt2:" + sqltxt2)
            System.Diagnostics.Debug.WriteLine("sqltxt:" + sqltxt)
                ViewState("sqltxt") = sqltxt
                ViewState("sqltxt1") = sqltxt1
                ViewState("sqltxt2") = sqltxt2
        End Sub

    Sub GetPageInfo()
        '�`�p����
        Dim sqlcmd As String = "SELECT COUNT(*) "
        Dim RecordCount As String = db.GetExecuteScalar(sqlcmd & viewstate("sqltxt2")).ToString
        Label9.Text = "�@<font face=verdana >" + RecordCount + "</font>���O��<font face=verdana >"
    End Sub

    Private Sub dg_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dg.PageIndexChanged
        '����
        dg.CurrentPageIndex = e.NewPageIndex
        Load_Data(viewstate("sqltxt"))
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        '�s�W
        Lbl_ActionFlag.Text = "ADD"
        SetDisplay()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        '����
        Lbl_ActionFlag.Text = "QUERY"
        SetDisplay()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        '�x�s
            Dim sqlcmd As String = ""
        Try
            If Lbl_ActionFlag.Text = "ADD" Then
                If Check_Data() = False Then
                    Exit Sub
                End If
                    sqlcmd = String.Format("INSERT INTO FWEB_ONL_PROD (PROD_RULE,ORG,COST_CENTER,INCLUDE,PRODUCT_NUM,CDATE,CUSER,COST_FLAG,GOLD_FLAG) " & _
                                       "VALUES('{0}','{1}','{2}','{3}','{4}',SYSDATE,'{5}','{6}','{7}') ", _
                                       dd_prod_rule.SelectedValue, txt_org.Value.Trim, txt_cost_center.Value.Trim, dd_include.SelectedValue, txt_product_num.Value.Trim.ToUpper, Context.User.Identity.Name, dd_costflag.SelectedValue, dd_goldflag.SelectedValue)
                If viewstate("sqltxt") = "" Then
                    SetQueryViewState()
                End If
            End If
            db.ExecuteSQL(sqlcmd)
        Catch ex As Exception
            Throw ex
            Exit Sub
        End Try
            Lbl_ActionFlag.Text = "SAVE"
            SetDisplay()
            Load_Data(ViewState("sqltxt"))
    End Sub

    Private Sub dg_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dg.ItemDataBound
        'DataGridView���C�@��Record��Delete�]�wLinkButton
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            CType(e.Item.Cells(1).FindControl("btnDELETE"), LinkButton).Attributes.Add("onclick", "return confirm('�T�{�R��������ƶ�?');")
        End If
        'DataGridView���C�@��Record�]�wcurrentcolor
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
            e.Item.Attributes.Add("onmouseover", "currentcolor=this.style.backgroundColor;this.style.backgroundColor='#eaeaea'")
            e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor")
        End If
    End Sub

    Private Sub dg_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dg.ItemCommand
        If e.CommandName = "DELETE" Then     '�R��            
            Dim sqlcmd As String
            sqlcmd = "DELETE FROM FWEB_ONL_PROD WHERE PROD_RULE = '" + e.Item.Cells(1).Text.Trim + "' AND ORG ='" + e.Item.Cells(3).Text.Trim + "' " & _
                     "AND COST_CENTER = '" + e.Item.Cells(4).Text.Trim + "' AND INCLUDE = '" + e.Item.Cells(6).Text.Trim + "' AND PRODUCT_NUM = '" + e.Item.Cells(7).Text.Trim + "'"
            Try
                db.ExecuteSQL(sqlcmd)
            Catch ex As Exception
                Throw ex
            Finally
                Lbl_ActionFlag.Text = "QUERY"
                Load_Data(viewstate("sqltxt"))
            End Try
        End If
    End Sub

    Function Check_Data() As Boolean
        'Check
        Dim ErrCount As Int16 = 0
        Dim sqlcmd As String
        '�Ƹ��W�h�г]�Ƹ��Ĥ@�X/�Ƹ����X
        If ErrCount = 0 And dd_prod_rule.SelectedValue = "ALL" Then
            ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ƹ��W�h�г]�Ƹ��Ĥ@�X/�Ƹ����X!');</script>")
            End If
            '�t�O���i����
            If ErrCount = 0 And txt_org.Value = "" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���i����!');</script>")
            End If
            '�������ߤ��i����
            If ErrCount = 0 And txt_cost_center.Value = "" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������ߤ��i����!');</script>")
            End If
            '�г]�w���Y/�ư�N
            If ErrCount = 0 And dd_include.SelectedValue = "ALL" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�г]�w���Y/�ư�N !');</script>")
            End If
            '�i�쪫�Ʀ���MTL
            If ErrCount = 0 And dd_costflag.SelectedValue = "ALL" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�г]�w�O�_���iMTL �OY/�_N !');</script>")
            End If
            '�Ƹ����i����
            If ErrCount = 0 And txt_product_num.Value = "" Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�Ƹ����i����!');</script>")
            End If
            '�Ƹ��Ĥ@�X�����׬�1
            If ErrCount = 0 And dd_prod_rule.SelectedValue = "F" And Len(txt_product_num.Value) > 1 Then
                ErrCount = ErrCount + 1
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�п�J�Ƹ��Ĥ@�X!');</script>")
            End If
            '�O�_���u�W���s�i�L�I�t�O
            If (ErrCount = 0) And txt_org.Value <> "" Then
                sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG = DECODE('" + txt_org.Value.Trim + "','ALL',ORG,'" + txt_org.Value.Trim + "')"
                If db.GetExecuteScalar(sqlcmd) = 0 Then
                    ErrCount = ErrCount + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�t�O���~�A�Э��s��J (���O�u�W���s�i�L�I�t�O) !');</script>")
                End If
            End If
            '�O�_���u�W���s�i�L�I��������
            If (ErrCount = 0) And txt_cost_center.Value <> "" Then
                sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_DEPT WHERE ORG = DECODE('" + txt_org.Value.Trim + "','ALL',ORG,'" + txt_org.Value.Trim + "') AND COST_CENTER = DECODE('" + txt_cost_center.Value.Trim + "','ALL',COST_CENTER,'" + txt_cost_center.Value.Trim + "')"
                If db.GetExecuteScalar(sqlcmd) = 0 Then
                    ErrCount = ErrCount + 1
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�������߿��~�A�Э��s��J (���O�u�W���s�i�L�I��������)!');</script>")
                End If
            End If
            '��Ƥw�s�b (�Ƹ��W�h+�t�O+��������+�Ƹ� ���ߤ@��)
            If (ErrCount = 0) And Lbl_ActionFlag.Text = "ADD" Then
                Try
                    sqlcmd = "SELECT COUNT(*) FROM FWEB_ONL_PROD WHERE PROD_RULE = '" + dd_prod_rule.SelectedValue + "' AND ORG = '" + txt_org.Value.Trim + "' " & _
                             "AND COST_CENTER = '" + txt_cost_center.Value.Trim + "' AND PRODUCT_NUM = '" + txt_product_num.Value.ToUpper.Trim + "'"
                    If db.GetExecuteScalar(sqlcmd) > 0 Then
                        ErrCount = ErrCount + 1
                        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('������Ƥw�s�b!');</script>")
                    End If
                Catch ex As Exception
                    Throw ex
                End Try
            End If
        'Err
        If ErrCount > 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Sub SetDisplay()

            If Lbl_ActionFlag.Text = "ADD" Then    '�s�W

                '���s���A
                btnSave.Enabled = True
                btnCancel.Enabled = True
                '�Ƹ��W�h
                dd_prod_rule.Enabled = True
                dd_prod_rule.SelectedValue = "F"
                dd_prod_rule.BackColor = ColorTranslator.FromHtml("#E0FFFF")
                '�t�O
                txt_org.Disabled = False
                txt_org.Value = ""
                Load_Org()
                txt_org.Style.Add("BACKGROUND-COLOR", "#E0FFFF")
                cmb_org_name.Style.Add("BACKGROUND-COLOR", "#E0FFFF")
                '��������
                txt_cost_center.Disabled = False
                txt_cost_center.Value = ""
                Load_Cost()
                txt_cost_center.Style.Add("BACKGROUND-COLOR", "#E0FFFF")
                cmb_cost_name.Style.Add("BACKGROUND-COLOR", "#E0FFFF")
                '���Y / �ư�N
                dd_include.Enabled = True
                dd_include.SelectedValue = "N"
                dd_include.BackColor = ColorTranslator.FromHtml("#E0FFFF")
                '�iMTL �OY / �_N
                dd_costflag.Enabled = True
                dd_costflag.SelectedValue = "N"
                dd_costflag.BackColor = ColorTranslator.FromHtml("#E0FFFF")
                '���Q�Ƹ�
                dd_goldflag.Enabled = True
                dd_goldflag.SelectedValue = "N"
                dd_goldflag.BackColor = ColorTranslator.FromHtml("#E0FFFF")
                dd_goldflag.Items(0).Enabled = False
                '�Ƹ�
                txt_product_num.Disabled = False
                'txt_product_num.Value = ""
                txt_product_num.Style.Add("BACKGROUND-COLOR", "#E0FFFF")


            ElseIf Lbl_ActionFlag.Text = "QUERY" Then '�s��

                '���s���A
                btnSave.Enabled = False

                btnCancel.Enabled = False
                '�Ƹ��W�h
                dd_prod_rule.Enabled = True

                'dd_prod_rule.SelectedIndex = -1

                dd_prod_rule.BackColor = ColorTranslator.FromHtml("#FFFFFF")

                '�t�O
                txt_org.Disabled = False

                'txt_org.Value = ""
                'Load_Org()
                txt_org.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                cmb_org_name.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                '��������
                txt_cost_center.Disabled = False
                'txt_cost_center.Value = ""
                'Load_Cost()
                txt_cost_center.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                cmb_cost_name.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                '���Y / �ư�N
                dd_include.Enabled = True
                'dd_include.SelectedIndex = -1
                dd_include.BackColor = ColorTranslator.FromHtml("#FFFFFF")
                '�iMTL �OY / �_N
                dd_costflag.Enabled = True
                'dd_costflag.SelectedIndex = -1
                dd_costflag.BackColor = ColorTranslator.FromHtml("#FFFFFF")

                '���Q�Ƹ�
                dd_goldflag.Enabled = True
                dd_goldflag.Items(0).Enabled = True
                'dd_goldflag.SelectedIndex = -1
                dd_goldflag.BackColor = ColorTranslator.FromHtml("#FFFFFF")
                '�Ƹ�
                txt_product_num.Disabled = False
                'txt_product_num.Value = ""
                txt_product_num.Style.Add("BACKGROUND-COLOR", "#FFFFFF")


            ElseIf Lbl_ActionFlag.Text = "SAVE" Then '�s�ɫ�n��ȲM��

                '���s���A
                btnSave.Enabled = False

                btnCancel.Enabled = False
                '�Ƹ��W�h
                dd_prod_rule.Enabled = True

                dd_prod_rule.SelectedIndex = -1

                dd_prod_rule.BackColor = ColorTranslator.FromHtml("#FFFFFF")

                '�t�O
                txt_org.Disabled = False

                txt_org.Value = ""
                Load_Org()
                txt_org.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                cmb_org_name.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                '��������
                txt_cost_center.Disabled = False
                txt_cost_center.Value = ""
                Load_Cost()
                txt_cost_center.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                cmb_cost_name.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
                '���Y / �ư�N
                dd_include.Enabled = True
                dd_include.SelectedIndex = -1
                dd_include.BackColor = ColorTranslator.FromHtml("#FFFFFF")
                '�iMTL �OY / �_N
                dd_costflag.Enabled = True
                dd_costflag.SelectedIndex = -1
                dd_costflag.BackColor = ColorTranslator.FromHtml("#FFFFFF")

                '���Q�Ƹ�
                dd_goldflag.Enabled = True
                dd_goldflag.Items(0).Enabled = True
                dd_goldflag.SelectedIndex = -1
                dd_goldflag.BackColor = ColorTranslator.FromHtml("#FFFFFF")
                '�Ƹ�
                txt_product_num.Disabled = False
                txt_product_num.Value = ""
                txt_product_num.Style.Add("BACKGROUND-COLOR", "#FFFFFF")
            End If
        End Sub
        Private Sub btnExcel_import_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel_import.Click
            '�פJExcel
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "open", "<script language='JavaScript'>window.open('FWEB_ONL_PROD_EXCELIN.aspx','','height=screen.height,width=screen.width') </script>")
            'Response.Write("<script>window.open('ONL/" + IMPORT_EXCEL() + ".xls')</script>")
        End Sub


        Private Sub btnExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcel.Click
            '��Excel
            Response.Write("<script>window.open('ONL/" + EXPORT_EXCEL() + ".xls')</script>")
        End Sub


        Function EXPORT_EXCEL() As String
            Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
            Dim ds As New DataSet
            Dim sTemplate As String = Server.MapPath("~") & "\ONL_Template\ONL_PROD.xls"
            Dim fileNameTmp As String = "ONL_PROD" + context.User.Identity.Name
            Dim savepath As String = Server.MapPath("~") & "\ONL\" + fileNameTmp + ".xls"

            Try
                '�w�q�@�ӷs���u�@ï
                oBooks = oExcel.Workbooks
                oBooks.Open(sTemplate)
                oBook = oBooks.Item(1)

                oSheets = oBook.Worksheets
                oSheet = oSheets.Item(1)
                oCells = oSheet.Cells

                '��R���
                ds = db.FillDataSet(ViewState("sqltxt"), 2)
                Dim y As Integer
                Dim i As Integer = ds.Tables(0).Rows.Count
                Dim j As Int16 = 0
                For y = 0 To ds.Tables(0).Columns.Count - 1
                    Select Case ds.Tables(0).Columns(y).ColumnName
                        Case "PROD_RULE_NAME"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 1) = ds.Tables(0).Rows(i).Item("PROD_RULE_NAME").ToString
                                j = j + 1
                            Next
                        Case "ORG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 2) = ds.Tables(0).Rows(i).Item("ORG").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 3) = ds.Tables(0).Rows(i).Item("COST_CENTER").ToString
                                j = j + 1
                            Next
                        Case "COST_CENTER_NAME"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 4) = ds.Tables(0).Rows(i).Item("COST_CENTER_NAME").ToString
                                j = j + 1
                            Next
                        Case "INCLUDE"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 5) = ds.Tables(0).Rows(i).Item("INCLUDE").ToString
                                j = j + 1
                            Next
                        Case "COST_FLAG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 6) = ds.Tables(0).Rows(i).Item("COST_FLAG").ToString
                                j = j + 1
                            Next

                        Case "GOLD_FLAG"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 7) = ds.Tables(0).Rows(i).Item("GOLD_FLAG").ToString
                                j = j + 1
                            Next

                        Case "PRODUCT_NUM"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 8) = ds.Tables(0).Rows(i).Item("PRODUCT_NUM").ToString
                                j = j + 1
                            Next
                        Case "CDATE"
                            j = 0
                            For i = 0 To i - 1
                                If Not IsDBNull(ds.Tables(0).Rows(i).Item("CDATE")) Then
                                    oCells(j + 2, 9) = "'" + ds.Tables(0).Rows(i).Item("CDATE").ToString
                                Else
                                    oCells(j + 2, 9) = ""
                                End If
                                j = j + 1
                            Next
                        Case "CUSER"
                            j = 0
                            For i = 0 To i - 1
                                oCells(j + 2, 10) = "'" + ds.Tables(0).Rows(i).Item("CUSER").ToString
                                j = j + 1
                            Next
                    End Select
                Next

                '-------------------------------------------------------------------------
                If File.Exists(savepath) Then
                    File.Delete(savepath)
                End If

                oSheet.SaveAs(savepath)
                oBook.Close()

                Return fileNameTmp
            Catch ex As Exception
                Throw ex
            Finally
                oExcel.Quit()
                If Not oExcel Is Nothing Then
                    Marshal.ReleaseComObject(oExcel)
                    oExcel = Nothing
                End If


                If Not oCells Is Nothing Then
                    Marshal.ReleaseComObject(oCells)
                    oCells = Nothing
                End If
                If Not oSheet Is Nothing Then
                    Marshal.ReleaseComObject(oSheet)
                    oSheet = Nothing
                End If
                If Not oSheets Is Nothing Then
                    Marshal.ReleaseComObject(oSheets)
                    oSheets = Nothing
                End If
                If Not oBook Is Nothing Then
                    Marshal.ReleaseComObject(oBook)
                    oBook = Nothing
                End If
                If Not oBooks Is Nothing Then
                    Marshal.ReleaseComObject(oBooks)
                    oBooks = Nothing
                End If

                If Not ds Is Nothing Then
                    ds.Dispose()
                End If

                'GC.Collect()

            End Try
        End Function

        Protected Sub dd_costflag_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dd_costflag.SelectedIndexChanged

        End Sub
    End Class

End Namespace
