Imports Excel
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Data
Imports System.Data.OleDb
Imports System.Math


Namespace FR


Partial Class FWEB_FIND_INPUT
    Inherits System.Web.UI.Page

    Dim cn As OleDbConnection = New OleDbConnection(ConfigurationSettings.AppSettings("conn"))
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�b�o�̩�m�ϥΪ̵{���X�H��l�ƺ���
        If Not Page.IsPostBack Then
            Button1.Attributes.Add("onclick", "return loading();")
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "close", "<script language='JavaScript'>window.close('FWEB_FIND_INPUT.aspx') </script>")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim fileP As System.Web.UI.HtmlControls.HtmlInputFile              
        fileP = Me.FindControl("File1")
        If fileP.Value <> "" Then
                Dim a As Array
                a = Split(Path.GetFileName(fileP.Value), ".")
            If a(1) <> "xls" Then
                    Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�W�Ǥ��榡����!');</script>")
                    Exit Sub
                End If
                Dim sTemplate As String = PublicM.GetSessionDataRoot(Context) + "ONL_ONHAND_UPLOAD.xls"
                System.Diagnostics.Debug.WriteLine("sTemplate:" + sTemplate)
                fileP.PostedFile.SaveAs(sTemplate)
                TansferData(sTemplate)
            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�п�ܤW�Ǫ����!');</script>")
                Exit Sub
            End If
        End Sub

        Sub TansferData(ByVal filePath As String)
            Dim i As Int32
            Dim V_PERIOD_NAME, V_ORG, V_TRANSACTION_TYPE, V_COST_CENTER, V_PRODUCT_NUM, V_PRODUCT_DESC, V_UOM, V_PRE_ONHAND, V_NOW_WASTE, V_NOW_ONHAND, V_BONDED_NOW_ONHAND, V_COST_FLAG As String
            Dim DS As New DataSet
            Dim ExcelData As String = LoadExcel(filePath)
            Dim SQLClear, SQLError As String

            GC.Collect()

            If File.Exists(filePath) Then
                File.Delete(filePath)
            End If

            DS = ReadExcel(ExcelData)
            If File.Exists(ExcelData) Then
                File.Delete(ExcelData)
            End If


            '�R��FWEB_ONL_TRANSFER_ERROR���
            SQLClear = "DELETE FROM FWEB_ONL_TRANSFER_ERROR WHERE FUNC_NO ='ONL_ONHAND' AND MUSER = '" + context.User.Identity.Name + "'"
            Try
                db.ExecuteSQL(SQLClear)
            Catch ex As Exception
                Throw ex
            End Try

            If Not IsDBNull(DS.Tables(0).Rows(0).Item("ORG")) Then
            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�W�Ǫ���Ƭ���,�Э��s�W��!');</script>")
                Exit Sub
            End If

            '����StoreProcedure: �s�W��FWEB_ONL_TRANSFER_TMP, FWEB_ONL_ONHAND, CHECK ERROR
            For i = 0 To DS.Tables(0).Rows.Count - 1
                Try
                    With DS.Tables(0).Rows(i)
                        If Not IsDBNull(.Item("PERIOD_NAME")) Then
                            V_PERIOD_NAME = IIf(TypeOf .Item("PERIOD_NAME") Is DBNull, "", .Item("PERIOD_NAME"))
                            V_ORG = IIf(TypeOf .Item("ORG") Is DBNull, "", .Item("ORG"))
                            V_TRANSACTION_TYPE = IIf(TypeOf .Item("TRANSACTION_TYPE") Is DBNull, "", .Item("TRANSACTION_TYPE"))
                            V_COST_CENTER = IIf(TypeOf .Item("COST_CENTER") Is DBNull, "", .Item("COST_CENTER"))
                            V_PRODUCT_NUM = IIf(TypeOf .Item("PRODUCT_NUM") Is DBNull, "", .Item("PRODUCT_NUM"))
                            System.Diagnostics.Debug.WriteLine("PRODUCT_NUM:" + V_PRODUCT_NUM)
                            V_PRODUCT_DESC = IIf(TypeOf .Item("PRODUCT_DESC") Is DBNull, "", .Item("PRODUCT_DESC"))
                            V_UOM = IIf(TypeOf .Item("UOM") Is DBNull, "", .Item("UOM"))
                            V_PRE_ONHAND = IIf(TypeOf .Item("PRE_ONHAND") Is DBNull, 0, .Item("PRE_ONHAND"))
                            V_NOW_WASTE = IIf(TypeOf .Item("NOW_WASTE") Is DBNull, 0, .Item("NOW_WASTE"))
                            System.Diagnostics.Debug.WriteLine("NOW_WASTE:" + V_NOW_WASTE)
                            V_NOW_ONHAND = IIf(TypeOf .Item("NOW_ONHAND") Is DBNull, 0, .Item("NOW_ONHAND"))
                            V_BONDED_NOW_ONHAND = IIf(TypeOf .Item("BONDED_NOW_ONHAND") Is DBNull, 0, .Item("BONDED_NOW_ONHAND"))
                            V_COST_FLAG = IIf(TypeOf .Item("COST_FLAG") Is DBNull, 0, .Item("COST_FLAG"))
                            '����StoreProcedure 
                            ExecSP(V_PERIOD_NAME, V_ORG, V_TRANSACTION_TYPE, V_COST_CENTER, V_PRODUCT_NUM, V_PRODUCT_DESC, V_UOM, V_PRE_ONHAND, V_NOW_WASTE, V_NOW_ONHAND, V_BONDED_NOW_ONHAND, V_COST_FLAG)
                        Else
                            Exit For
                        End If
                    End With
                Catch ex As Exception
                    Throw ex
                End Try
            Next

            '�ˬd�O�_�����`
            SQLError = "SELECT COUNT(*) FROM FWEB_ONL_TRANSFER_ERROR WHERE FUNC_NO ='ONL_ONHAND' AND MUSER = '" + context.User.Identity.Name + "'"
            If db.GetExecuteScalar(SQLError) = 0 Then
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('�W�Ǧ��\!');</script>")
            Else
                Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "msg", "<script defer>alert('��J�����`�A�Ьd�ݲ��`����!');</script>")
            End If
        End Sub
        Sub ExecSP(ByVal P_PERIOD_NAME As String, ByVal P_ORG As String, ByVal P_TRANSACTION_TYPE As String, ByVal P_COST_CENTER As String, ByVal P_PRODUCT_NUM As String, ByVal P_PRODUCT_DESC As String, ByVal P_UOM As String, ByVal P_PRE_ONHAND As String, ByVal P_NOW_WASTE As String, ByVal P_NOW_ONHAND As String, ByVal P_BONDED_NOW_ONHAND As String, ByVal P_COST_FLAG As String)
            '����StoreProcedure
            Dim cmd As New OleDbCommand
            If cn.State = ConnectionState.Open Then
                cn.Close()
            Else
                Try
                    cn.Open()
                    cmd.CommandText = "FWEB_ONL_TRANSFER_SP"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = cn

                    cmd.Parameters.Add(New OleDbParameter("P_FUNC_NO", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_PERIOD_NAME", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_ORG", OleDbType.VarChar, 3))
                    cmd.Parameters.Add(New OleDbParameter("P_TRANSACTION_TYPE", OleDbType.VarChar, 6))
                    cmd.Parameters.Add(New OleDbParameter("P_COST_CENTER", OleDbType.VarChar, 20))
                    cmd.Parameters.Add(New OleDbParameter("P_PRODUCT_NUM", OleDbType.VarChar, 40))
                    cmd.Parameters.Add(New OleDbParameter("P_PRODUCT_DESC", OleDbType.VarChar, 240))
                    cmd.Parameters.Add(New OleDbParameter("P_UOM", OleDbType.VarChar, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_PRE_ONHAND", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_NOW_WASTE", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_NOW_ONHAND", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_BONDED_NOW_ONHAND", OleDbType.Decimal))
                    cmd.Parameters.Add(New OleDbParameter("P_REMARK", OleDbType.VarChar, 200))
                    cmd.Parameters.Add(New OleDbParameter("P_COST_FLAG", OleDbType.VarChar, 1))
                    cmd.Parameters.Add(New OleDbParameter("P_MDATE", OleDbType.Date, 10))
                    cmd.Parameters.Add(New OleDbParameter("P_MUSER", OleDbType.VarChar, 10))

                    cmd.Parameters("P_FUNC_NO").Value = "ONL_ONHAND"
                    cmd.Parameters("P_PERIOD_NAME").Value = P_PERIOD_NAME
                    cmd.Parameters("P_ORG").Value = P_ORG
                    cmd.Parameters("P_TRANSACTION_TYPE").Value = P_TRANSACTION_TYPE
                    cmd.Parameters("P_COST_CENTER").Value = P_COST_CENTER
                    cmd.Parameters("P_PRODUCT_NUM").Value = P_PRODUCT_NUM
                    cmd.Parameters("P_PRODUCT_DESC").Value = P_PRODUCT_DESC
                    cmd.Parameters("P_UOM").Value = P_UOM
                    cmd.Parameters("P_PRE_ONHAND").Value = P_PRE_ONHAND
                    cmd.Parameters("P_NOW_WASTE").Value = P_NOW_WASTE
                    cmd.Parameters("P_NOW_ONHAND").Value = P_NOW_ONHAND
                    cmd.Parameters("P_BONDED_NOW_ONHAND").Value = P_BONDED_NOW_ONHAND
                    cmd.Parameters("P_REMARK").Value = ""
                    'cmd.Parameters("P_COST_FLAG").Value = P_COST_FLAG
                    cmd.Parameters("P_COST_FLAG").Value = ""
                    cmd.Parameters("P_MDATE").Value = Now
                    cmd.Parameters("P_MUSER").Value = Context.User.Identity.Name
                    cmd.ExecuteNonQuery()
                Catch ex As Exception
                    ' Throw ex
                    Response.Write("<script>alert('" & ex.Message.Replace("'", "-") & "')</script>")
                Finally
                    cn.Close()
                End Try
            End If
        End Sub
    Function ReadExcel(ByVal savepath As String) As DataSet
        If Not File.Exists(savepath) Then
            Exit Function
        End If
        Dim DA As System.Data.DataSet
        Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
        Dim MyConnection As System.Data.OleDb.OleDbConnection
        MyConnection = New System.Data.OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + savepath + ";Extended Properties=Excel 8.0;")
        MyCommand = New System.Data.OleDb.OleDbDataAdapter("select * from [Sheet1$]", MyConnection)
        DA = New System.Data.DataSet
        MyCommand.Fill(DA)
        MyConnection.Close()

            DA.Tables(0).Columns(0).ColumnName = "PERIOD_NAME"
            DA.Tables(0).Columns(1).ColumnName = "ORG"
            DA.Tables(0).Columns(2).ColumnName = "TRANSACTION_TYPE"
            DA.Tables(0).Columns(3).ColumnName = "COST_CENTER"
            DA.Tables(0).Columns(5).ColumnName = "BONDED_FLAG"
            DA.Tables(0).Columns(6).ColumnName = "PRODUCT_NUM"
            DA.Tables(0).Columns(7).ColumnName = "PRODUCT_DESC"
            DA.Tables(0).Columns(8).ColumnName = "UOM"
            DA.Tables(0).Columns(9).ColumnName = "PRE_ONHAND"
            DA.Tables(0).Columns(10).ColumnName = "NOW_WASTE"
            DA.Tables(0).Columns(11).ColumnName = "NOW_ONHAND"
            DA.Tables(0).Columns(12).ColumnName = "BONDED_NOW_ONHAND"
            DA.Tables(0).Columns(23).ColumnName = "COST_FLAG"
        Return DA
    End Function
   
    Function LoadExcel(ByVal filePath As String) As String
        Dim oExcel As New Excel.Application
            Dim oBooks As Excel.Workbooks = Nothing
            Dim oBook As Excel.Workbook = Nothing
            Dim oSheets As Excel.Sheets = Nothing
            Dim oSheet As Excel.Worksheet = Nothing
            Dim oCells As Excel.Range = Nothing
        Dim sTemplate As String = filePath
        Dim savepath As String

        savepath = PublicM.GetSessionDataRoot(context) + "ONL_ONHAND_SAVEAS.xls"
        Try
            '�w�q�@�ӷs���u�@ï
            oBooks = oExcel.Workbooks
            oBooks.Open(sTemplate)
            oBook = oBooks.Item(1)
            oSheets = oBook.Worksheets
            oSheet = oSheets.Item(1)
            oCells = oSheet.Cells
            oSheet.Name = "Sheet1"
            If File.Exists(savepath) Then
                File.Delete(savepath)
            End If
            oSheet.SaveAs(savepath)
            oBook.Close()
        Catch ex As Exception
            Throw ex
        Finally
            oExcel.Quit()
            If Not oExcel Is Nothing Then
                Marshal.ReleaseComObject(oExcel)
                oExcel = Nothing
            End If

            If Not oCells Is Nothing Then
                Marshal.ReleaseComObject(oCells)
                oCells = Nothing
            End If
            If Not oSheet Is Nothing Then
                Marshal.ReleaseComObject(oSheet)
                oSheet = Nothing
            End If
            If Not oSheets Is Nothing Then
                Marshal.ReleaseComObject(oSheets)
                oSheets = Nothing
            End If
            If Not oBook Is Nothing Then
                Marshal.ReleaseComObject(oBook)
                oBook = Nothing
            End If
            If Not oBooks Is Nothing Then
                Marshal.ReleaseComObject(oBooks)
                oBooks = Nothing
            End If
            GC.Collect()
        End Try
        GC.Collect()
        Return savepath
    End Function


End Class

End Namespace
