﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class TForm:Form


    {
        public TForm() {

            InitializeComponent();
            
        }

        private void InitializeComponent() {
            this.SuspendLayout();
            // 
            // TForm
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "TForm";
            this.Load += new System.EventHandler(this.TForm_Load);
            this.ResumeLayout(false);
            this.Init();

        }

        private static string log_path = @"C:\temp\B2B_Log\B2B_log_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + @".txt";

        private static string log_dir = @"C:\temp\B2B_Log";

        public void Init() {

            MessageBox.Show("hash code="+this.GetHashCode().ToString());
        
        }

        private void TForm_Load(object sender, EventArgs e)
        {

        }

        /*private void initLog() {

            if (!Directory.Exists(log_dir))
            {
                Console.WriteLine(log_dir + " 不存在,創建資料夾");
                Directory.CreateDirectory(log_dir);
            }
        
        }*/

        /*public void writeLog() {

           
        
            
            
        
        }*/


    }
}
