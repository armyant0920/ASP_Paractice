﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;



namespace WindowsFormsApplication1
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]

       
        static void Main()
        {
            string file_path=@"C:\temp\init.txt";
            string content = "";
            
            if (File.Exists(file_path)) {
               
                StreamReader sr = new StreamReader(file_path);
                content += sr.ReadToEnd();
              
            }

            if (content.Length > 0)
            {

                MessageBox.Show("content=" + content);

            }
            else {
                                             
                openForm();
                            
            }
         
        }

        /*記得靜態類下的所有成員都必須是靜態,所以要加static*/

        static void openForm() {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            MessageBox.Show(System.Configuration.ConfigurationManager.AppSettings["conn"].ToString());

            string test = Console.ReadLine();
            Console.WriteLine("test=" + test);

            Application.Run(new Form1());
        
        
        
        }
    }
}
