﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinSCP;

namespace WindowsFormsApplication1
{
    public static class WinSCP_Tool
    {

        
        public static string error_msg;
        public static string remote_path;
        public static string host_name;
        public static string user_name;
        public static string password;
        public static string ssh_key;

        


        #region winscp_upload

        public static bool winscp_upload(string local_path)
        {
            error_msg = "";
            SessionOptions sessionOptions = new SessionOptions
            
            {
                Protocol = Protocol.Sftp,
                HostName = "10.13.16.78",
                UserName = "modmgr",
                Password = "modmgr",
                SshHostKeyFingerprint = "ssh-rsa 2048 20LI32FwpCHZyC6UkflD6cZ6eMzz5FxTDj+KE1b4ti8=",
                

            };
            string remote_path = @"/d01/MOD/ap/apps/apps_st/appl/inv/12.0.0/reports/";
            //string remote_path = @"/unimicron_TEST/";

            using (Session session = new Session())
            {
                // 連接

                try
                {

                    session.Open(sessionOptions);

                    // Upload files
                    TransferOptions transferOptions = new TransferOptions();
                    transferOptions.TransferMode = TransferMode.Binary;

                    TransferOperationResult transferResult;
                    transferResult =
                        session.PutFiles(local_path, remote_path, false, transferOptions);

                    // Throw on any error
                    transferResult.Check();


                    // Print results
                    foreach (TransferEventArgs transfer in transferResult.Transfers)
                    {
                        Console.WriteLine("Upload of {0} succeeded", transfer.FileName);
                    }
                    //check IsSuccess

                    return transferResult.IsSuccess;


                }
                catch (Exception e)
                {
                    Console.WriteLine("winscp upload occur exception:" + e.ToString());
                    error_msg += "winscp upload occur exception:" + e.ToString();
                    
                    
                    return false;




                }

            }
        }
        #endregion

        public static bool winscp_download(string local_path)
        {
            error_msg = "";
            SessionOptions sessionOptions = new SessionOptions

            {
                Protocol = Protocol.Sftp,
                HostName = "10.13.16.78",
                UserName = "modmgr",
                Password = "modmgr",
                SshHostKeyFingerprint = "ssh-rsa 2048 20LI32FwpCHZyC6UkflD6cZ6eMzz5FxTDj+KE1b4ti8=",


            };
            string remote_path = @"/d01/MOD/ap/apps/apps_st/appl/inv/12.0.0/reports/";
            //string remote_path = @"/unimicron_TEST/";

            using (Session session = new Session())
            {
                // 連接

                try
                {

                    session.Open(sessionOptions);

                    // Upload files
                    TransferOptions transferOptions = new TransferOptions();
                    transferOptions.TransferMode = TransferMode.Binary;

                    TransferOperationResult transferResult;
                    transferResult =
                        session.PutFiles(local_path, remote_path, false, transferOptions);

                    // Throw on any error
                    transferResult.Check();


                    // Print results
                    foreach (TransferEventArgs transfer in transferResult.Transfers)
                    {
                        Console.WriteLine("Upload of {0} succeeded", transfer.FileName);
                    }
                    //check IsSuccess

                    return transferResult.IsSuccess;


                }
                catch (Exception e)
                {
                    Console.WriteLine("winscp upload occur exception:" + e.ToString());
                    error_msg += "winscp upload occur exception:" + e.ToString();


                    return false;




                }

            }
        }
        

    }
}
