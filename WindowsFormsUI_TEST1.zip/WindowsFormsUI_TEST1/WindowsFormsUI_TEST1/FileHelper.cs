﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace WindowsFormsApplication1
{
    public static class FileHelper
    {

        public static string convertToBase64(string path) {
            try
            {
                string s = "";
                FileStream fs = new FileStream(path, FileMode.Open);
                byte[] bt = new byte[fs.Length];
                fs.Read(bt, 0, bt.Length);
                fs.Close();

                return Convert.ToBase64String(bt);
            }
            catch (Exception e) {

                Console.WriteLine("convert occur exception:"+e.ToString());
                return "";
            }

        
        }


        public static string ConvertFromBase64(string s){

            return Convert.FromBase64String(s).ToString();
            
        }
    }
}
