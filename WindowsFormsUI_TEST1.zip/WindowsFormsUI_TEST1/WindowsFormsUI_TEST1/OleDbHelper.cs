﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;

namespace WindowsFormsApplication1
{
    public class OleDbHelper

    {

        OleDbConnection conn = new OleDbConnection(System.Configuration.ConfigurationManager.AppSettings["conn"].ToString());


       /* public DataTable ExecuteQuery(string sql) {

            DataTable dt = new DataTable();

            using(Oracle)

            return dt;
        
        }*/




    }
}
