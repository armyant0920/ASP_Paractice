﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace WindowsFormsApplication1
{
    class AQI
    {

        public string SiteName { set; get; }
        public string County { set; get; }
        public string Status { set; get; }
         
        public string _PM{get;set;} 
        [JsonProperty(PropertyName = "PM2.5")]
        public string PM{     
             set{_PM=value;}
             get{return _PM;}
         }
       

           
    }
}
