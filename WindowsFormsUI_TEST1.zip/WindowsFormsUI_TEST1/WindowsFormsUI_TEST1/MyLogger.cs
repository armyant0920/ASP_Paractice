﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace WindowsFormsApplication1
{
    class MyLogger
    {
         
         private MyLogger(){}   
        private static MyLogger instance;


         /*public static MyLogger getInstance(){
            get{
                lock(lock){}
                if(instance==null){
                
                    instance=new MyLogger();
                }
                return instance;
            
            }
         
         }*/
        //DateTime date = new DateTime(DateTime.Now());
       /* public void writeLog(){




            string log_path=@"C:\temp\B2B_Log\B2B_log_"+System.DateTime.Now.ToString("yyyyMMdd_HHmmss")+@".txt";
       
            
            string log_dir=@"C:\temp\B2B_Log";
            if (!Directory.Exists(log_dir)) {
                Console.WriteLine(log_dir + " 不存在,創建資料夾");
                Directory.CreateDirectory(log_dir);
            }
            




            using System.IO;(StreamWriter wr = new StreamWriter(log_dir+@"\B2B_log"+date+@".txt")) {
            Console.SetOut(wr);
            Console.WriteLine("date:" + date);
            System.Diagnostics.Debug.WriteLine("date:" + date);              
            
            ArrayList list = new ArrayList();

            DataTable dt = query();

            string result = convertToXML(dt);
            System.Diagnostics.Debug.WriteLine("XML=\n"+result);
            Console.WriteLine("XML=\n" + result);
            //string path = @"C:\temp\"+date+@".xml"

            string path = @"X:\SFTP\B2B_TEST\B2B_upload_data\" + date + @".xml";
            //string path =@"\\utcsyCISfs01\CIS\SFTP\B2B_upload_data\"+date+@".xml";
            Console.WriteLine("outputfile:"+outputFile(path, result));
            //System.Diagnostics.Debug.WriteLine("outputfile:"+outputFile(path, result)); 

            if (winscp(path))
            {
                //如果winscp上傳成功,執行update sql

                System.Diagnostics.Debug.WriteLine("upload winscp success!");
                Console.WriteLine("upload winscp success!");

                int count = update();

                Console.WriteLine("end");
                //Console.ReadKey();
                System.Diagnostics.Debug.WriteLine("end");

            }
            else { 
                //如果上傳失敗,執行提示處理
                Console.WriteLine("upload winscp fail!");
                 System.Diagnostics.Debug.WriteLine("upload winscp fail!");
                       
            }


            }
      
        
        }*/
         
    

    }
}
