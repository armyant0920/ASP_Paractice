﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;

namespace WindowsFormsApplication1
{
    public partial class Form1 : TForm
    {

        public static Form current_form;

        public Form1()
        {
            InitializeComponent();
            //
            setEvent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void button1_Click(object sender, EventArgs e)
        {
            setCurrentForm(new Form2());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            setCurrentForm(new Form3());
        }
        private void setCurrentForm(Form form)
        {

            if (current_form != null)
            {
                current_form.Close();


            }
            current_form = form;
            current_form.ShowDialog();




        }

        private void m2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void m11ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // MessageBox.Show(sender.ToString());
        }


        private void setEvent()
        {

            /*foreach(ToolStripMenuItem item in this.toolStripMenuItem1.DropDownItems){
                item.Click += new EventHandler(menuitemClick);
            
            }*/
            foreach (ToolStripMenuItem menuitem in this.menu1ToolStripMenuItem.DropDownItems)
            {




                menuitem.Click += new EventHandler(menuitemClick);


            }

        }

        private void menuitemClick(object sender, EventArgs e)
        {
            MessageBox.Show("click item=" + sender.ToString());

        }

        private void exportExcel(string path)
        {

            Excel.Application t_excel = null;
            Excel.Worksheet t_sheet = null;
            Excel.Range t_cells = null;


            try
            {
                t_excel = new Excel.Application();
                t_excel.Workbooks.Add();
                t_excel.Caption = "EXCEL_OUTPUT";
                t_excel.Workbooks[1].Worksheets[1].Name = "test";

                //Excel.Workbook t_excel_book= t_excel.Workbooks.Add();           
                //Excel.Worksheet t_sheet = t_excel_book.Sheets[1];
                t_sheet = t_excel.Workbooks[1].Worksheets[1];


                //t_sheet = t_excel.Workbooks[1].Worksheets[1];
                t_sheet.Name = "測試sheet";
                t_cells = t_sheet.Cells;

                t_cells[1][1] = DateTime.Now.ToString("yyyy-MM-dd HHmmss");
                for (int i = 2; i < 11; i++)
                {

                    for (int j = 1; j < 10; j++)
                    {

                        t_cells[i][j] = i.ToString() + @"*" + j.ToString() + @"=" + (i * j).ToString();
                    }


                }

                t_cells.Columns.AutoFit();
                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                t_sheet.SaveAs(path);
                t_excel.Visible = true;
                MessageBox.Show("export success");

            }
            catch (Exception e)
            {

                Console.WriteLine("error=" + e.Message);
                MessageBox.Show("export fail:" + e.Message);
                t_excel.Workbooks[1].Close(false, null, null);
                t_excel.Quit();


            }
            finally
            {


            }

        }

        private void btn_excel_Click(object sender, EventArgs e)
        {
            exportExcel(@"C:\Users\A3504\Desktop\test.xls");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string json = WebService.getTest();

            //Console.WriteLine("web response"+WebService.getTest());
            JsonReader jr = new JsonTextReader(new StringReader(json));
            DataTable dt = new DataTable();

            dt.Columns.Add("Site_Name", typeof(string));
            dt.Columns.Add("County", typeof(string));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("PM", typeof(string));


            List<AQI> list = JsonConvert.DeserializeObject<List<AQI>>(json);

            foreach(AQI aqi in list){
                Console.WriteLine("AQI={0},{1},{2},{3}", aqi.County, aqi.SiteName, aqi.Status,aqi.PM);
                dt.Rows.Add(aqi.County, aqi.SiteName, aqi.Status,aqi.PM);
            }
            ExcelTool excel = new ExcelTool();
            if (excel.exportExcel(@"D:\D_temp\TEST\WindowsFormsUI_TEST1\WindowsFormsUI_TEST1\document\json.xlsx", dt))
            {
                MessageBox.Show("轉出json成功");
            }
            else {
                MessageBox.Show("轉出json失敗");
            
            };
            /*while (jr.Read())
            {

                
                dt.Rows.Add("料號全碼", "07", "3141", "Y", "Y", "Y", "C73060001", "")
                Console.WriteLine(jr.TokenType + "\t\t" + jr.ValueType + "\t\t" + jr.Value + "\r\n");

            }*/
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //測試轉base64
            string base64_string = "";
            base64_string = FileHelper.convertToBase64(@"C:\temp\SA_212_ADD.XLS");


            Console.WriteLine("-----");
            Console.WriteLine("test base64=" + base64_string);
            /*foreach(byte b in bytes){

       temp += b;
   }*/

            byte[] bytes = Convert.FromBase64String(base64_string);
            //byte[] bytes = System.Text.Encoding.Default.GetBytes(base64_string);
            using (var fs = new FileStream(@"C:\temp\SA_212_test.XLS", FileMode.OpenOrCreate, FileAccess.Write))
            {
                fs.Write(bytes, 0, bytes.Length);
                fs.Flush();
                //fs.Close(); 
                //Console.WriteLine("from base64=" + Convert.FromBase64String(base64_string).ToString());
            }






        }

        private void button5_Click(object sender, EventArgs e)
        {


            string file_path = @"C:\temp\init.txt";
            if (WinSCP_Tool.winscp_upload(file_path))
            {
                MessageBox.Show("success");

            }
            else
            {
                MessageBox.Show("error:" + WinSCP_Tool.error_msg);

            };



        }


    }
}
