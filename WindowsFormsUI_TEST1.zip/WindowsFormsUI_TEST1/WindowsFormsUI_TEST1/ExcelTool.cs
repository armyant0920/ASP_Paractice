﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;

namespace WindowsFormsApplication1
{
    class ExcelTool
    {
        Excel.Application t_excel = null;
        Excel.Worksheet t_sheet = null;
        Excel.Range t_cells = null;

        public ExcelTool() {
            initExcel();
        
        
        }
            
           
           


            public void initExcel() {

                t_excel = new Excel.Application();
                t_excel.Workbooks.Add();
                //t_excel.Caption = "EXCEL_OUTPUT";
                t_excel.Workbooks[1].Worksheets[1].Name = "test";

                //Excel.Workbook t_excel_book= t_excel.Workbooks.Add();           
                //Excel.Worksheet t_sheet = t_excel_book.Sheets[1];
                t_sheet = t_excel.Workbooks[1].Worksheets[1];


                //t_sheet = t_excel.Workbooks[1].Worksheets[1];
                t_sheet.Name = "測試sheet";
                t_cells = t_sheet.Cells;
                      
            }

            public  bool exportExcel(string path, DataTable dt) {

                bool success = false;
                Console.WriteLine("\n資料數:{0}", dt.Rows.Count);

                try {
                    for (int i = 0; i < dt.Columns.Count; i++) {
                        t_cells[i + 1][1] = dt.Columns[i].Caption;
                    
                    }
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            for (int j = 0; j < dt.Columns.Count; j++)
                            {
                                t_cells[j + 1][i + 2] = dt.Rows[i][j];


                            }

                            //t_cells[i + 1][2] = dt.Rows[i].ItemArray[1];
                            //t_cells[i + 1][3] = dt.Rows[i].ItemArray[2];


                        }
                       
                        /*foreach (DataRow dr in dt.Rows){
                        
                        }*/

                      t_cells.Columns.AutoFit();
                      if (File.Exists(path)){
                          File.Delete(path);
                      }

                        t_sheet.SaveAs(path);

                        t_excel.Visible = false;
                        t_excel.Quit();
                        success = true;
                    
                    }

                catch(Exception e) {
                    
                    success = false;
                    Console.WriteLine("fail export from datatable,exception={0}", e.ToString());
                    
                }
                return success;
            }

            public  bool exportExcel(string path ){
                bool success = false;
              
                try
                {

                    t_cells[1][1] = DateTime.Now.ToString("yyyy-MM-dd HHmmss");
                    for (int i = 2; i < 11; i++)
                    {

                        for (int j = 1; j < 10; j++)
                        {

                            t_cells[i][j] = i.ToString() + @"*" + j.ToString() + @"=" + (i * j).ToString();
                        }


                    }

                    t_cells.Columns.AutoFit();
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }

                    t_sheet.SaveAs(path);
                  
                    t_excel.Visible = true;
                    success = true;
                    


                }
                catch (Exception e){
                    
                    Console.WriteLine("error=" + e.Message);
                    
                    t_excel.Workbooks[1].Close(false, null, null);
                    t_excel.Quit();
                    success = false;
                   

                }

                return success;

            
            }
         
    }
}
