﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Collections.Specialized;
using System.IO;
using Newtonsoft.Json;



namespace WindowsFormsApplication1
{
    class WebService
    {
        
        
        public static string getTest() { 
        string url = @"http://opendata2.epa.gov.tw/AQI.json";

        //WebRequest request = (HttpWebRequest)WebRequest.Create(url);
        //request.Method = "get";
        //request.ContentType = "application/x-www-form-urlencoded";
        /*using (var stream = request.GetRequestStream())
        {
            stream.Write(, 0, data.Length);
        }*/

        //var response = (HttpWebResponse)request.GetResponse();

        //Console.WriteLine(response.ToString());


            //

        


        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        request.Proxy = null;
        request.KeepAlive = false;
        request.Method = "GET";
        request.ContentType = "application/json; charset=UTF-8";
        request.AutomaticDecompression = DecompressionMethods.GZip;

        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream myResponseStream = response.GetResponseStream();
        StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
        string retString = myStreamReader.ReadToEnd();

        myStreamReader.Close();
        myResponseStream.Close();

        if (response != null)
        {
            response.Close();
        }
        if (request != null)
        {
            request.Abort();
        }

        return retString;

        }

        
        
        



    }
}
